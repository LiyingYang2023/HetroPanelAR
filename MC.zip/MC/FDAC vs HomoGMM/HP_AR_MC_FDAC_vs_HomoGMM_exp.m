clear all;
rep = 2000;

% sample sizes
Nlist = [100 1000 5000];
Tlist = [4 6 10];
Nmax = max(Nlist); Tmax = max(Tlist);

% parameter values for initial processes
init_list = 1;
m0_list = [100, 3, 1]; % M_i of initial processes

% parameter values for uniform distributed phi_i = mu_phi + v_i, v_i ~ IIDU[-0.5,0.5]
mu_phi_list = [0.5, 0.4, 0.5]; va = 1;
alist = [0, 0.5, 0.5];

cvs = [0.6;0.2]; % coefficients for generating GARCH(1,1) effects in errors

%% Compute estimates
GAU = 1; GAR = 0; va = 1; init = 1; b = 1; kappa = 2; 
for m0 = m0_list
    for cid = 1:3
        mu_phi = mu_phi_list(cid);
    a = alist(cid);
    % set seed
    rng(123987654);

  for r = 1:rep
        ve = 0.5+0.5*chi2rnd(1,Nmax,1); % cross sectional heteroskedastic variance    
        para = GenRandomParaU(Nmax,mu_phi,a,va); % (mu_n',phi_n')'
        data(:,:,r) = GenRandomY(Nmax,Tmax,init,m0,para,ve,b,kappa,cvs,GAU,GAR);
  end

   for Tid = 1:length(Tlist)
        T = Tlist(Tid);
    for Nid = 1:length(Nlist)
        N = Nlist(Nid);
        s = (Tid-1)*length(Nlist)+Nid;
    
    if T==4    
    for r = 1:rep
    % get a panel with the respective sample size
    panel=data(1:N,1:T,r); % N*T panel
    
    % MM 
    [thetahat,se_GMM_hp] = GMM_hp_ar1(panel);
    m1_rep_MM(((s-1)*3+1):((s-1)*3+2),r,cid)=[thetahat(1);se_GMM_hp(1)];
    m1_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,cid)=[thetahat(2);se_GMM_hp(2)];

    % AH, FDLS, AAH
    [phihat, se] = AHestim(panel);
    m1_rep_AH(((s-1)*3+1):((s-1)*3+2),r,cid) = [phihat;se]; 
    [phihat_1, se_1] = FDLSestm(panel);
    m1_rep_FDLS(((s-1)*3+1):((s-1)*3+2),r,cid) = [phihat_1;se_1]; 
    [phihat_2, se_2, KAH_2] = AAHestim(panel);
    m1_rep_AAH(((s-1)*3+1):((s-1)*3+3),r,cid) = [phihat_2;se_2;KAH_2];  

    T1 = T-1;
    K=0;
    % AB, BB
    [ coef_GMM_DIF1, coef_GMM_DIF2, coef_GMM_SYS1, coef_GMM_SYS2, var_GMM_DIF1, var_GMM_DIF2, var_GMM_SYS1, var_GMM_SYS2] = GMMestimator_ar1(panel.', T1, N );

    GMM_DIF1_2step = cat(3, coef_GMM_DIF1(:,2), sqrt( diag( var_GMM_DIF1(:,:,2) ) ), sqrt( diag( var_GMM_DIF1(:,:,3) ) ) );
    GMM_SYS1_2step = cat(3, coef_GMM_SYS1(:,2), sqrt( diag( var_GMM_SYS1(:,:,2) ) ), sqrt( diag( var_GMM_SYS1(:,:,3) ) ) );
    m1_rep_AB(((s-1)*3+1):((s-1)*3+3),r,cid) = reshape(squeeze(GMM_DIF1_2step)',(K+1)*3,1);
    m1_rep_BB(((s-1)*3+1):((s-1)*3+3),r,cid) = reshape(squeeze(GMM_SYS1_2step)',(K+1)*3,1);

    clear thetahat se* var_GMM_hp phihat* KAH* GMM* 
    end
    end

    if T==5 
    for r = 1:rep
    % get a panel with the respective sample size
    panel=data(1:N,1:T,r); % N*T panel
    
    % MM 
    [thetahat,se_GMM_hp,var_GMM_hp,sev] = GMM_hp_ar1(panel);
    m1_rep_MM(((s-1)*3+1):((s-1)*3+2),r,cid)=[thetahat(1);se_GMM_hp(1)];
    m1_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,cid)=[thetahat(2);se_GMM_hp(2)];
    m2_rep_MM(((s-1)*3+1):((s-1)*3+2),r,cid)=[thetahat(3);se_GMM_hp(3)];
    m2_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,cid)=[thetahat(4);se_GMM_hp(4)];
    % variance
    var_rep_MM(((s-1)*3+1):((s-1)*3+2),r,cid)=[var_GMM_hp(1);sev(1)];
    var_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,cid)=[var_GMM_hp(2);sev(2)];

    % AH, FDLS, AAH
    [phihat, se] = AHestim(panel);
    m1_rep_AH(((s-1)*3+1):((s-1)*3+2),r,cid) = [phihat;se]; 
    [phihat_1, se_1] = FDLSestm(panel);
    m1_rep_FDLS(((s-1)*3+1):((s-1)*3+2),r,cid) = [phihat_1;se_1]; 
    [phihat_2, se_2, KAH_2] = AAHestim(panel);
    m1_rep_AAH(((s-1)*3+1):((s-1)*3+3),r,cid) = [phihat_2;se_2;KAH_2];  
    
    T1 = T-1;
    K=0;
    % AB, BB
    [ coef_GMM_DIF1, coef_GMM_DIF2, coef_GMM_SYS1, coef_GMM_SYS2, var_GMM_DIF1, var_GMM_DIF2, var_GMM_SYS1, var_GMM_SYS2] = GMMestimator_ar1(panel.', T1, N );

    GMM_DIF1_2step = cat(3, coef_GMM_DIF1(:,2), sqrt( diag( var_GMM_DIF1(:,:,2) ) ), sqrt( diag( var_GMM_DIF1(:,:,3) ) ) );
    GMM_SYS1_2step = cat(3, coef_GMM_SYS1(:,2), sqrt( diag( var_GMM_SYS1(:,:,2) ) ), sqrt( diag( var_GMM_SYS1(:,:,3) ) ) );
    m1_rep_AB(((s-1)*3+1):((s-1)*3+3),r,cid) = reshape(squeeze(GMM_DIF1_2step)',(K+1)*3,1);
    m1_rep_BB(((s-1)*3+1):((s-1)*3+3),r,cid) = reshape(squeeze(GMM_SYS1_2step)',(K+1)*3,1);

    clear thetahat se* var_GMM_hp phihat* KAH* GMM* 
    end
    end

    if T>5 
    for r = 1:rep
    % get a panel with the respective sample size
    panel=data(1:N,1:T,r); % N*T panel
    
    % MM 
    [thetahat,se_GMM_hp,var_GMM_hp,sev] = GMM_hp_ar1(panel);
    m1_rep_MM(((s-1)*3+1):((s-1)*3+2),r,cid)=[thetahat(1);se_GMM_hp(1)];
    m1_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,cid)=[thetahat(2);se_GMM_hp(2)];
    m2_rep_MM(((s-1)*3+1):((s-1)*3+2),r,cid)=[thetahat(3);se_GMM_hp(3)];
    m2_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,cid)=[thetahat(4);se_GMM_hp(4)];
    % variance
    var_rep_MM(((s-1)*3+1):((s-1)*3+2),r,cid)=[var_GMM_hp(1);sev(1)];
    var_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,cid)=[var_GMM_hp(2);sev(2)];
    % 3rd
    m3_rep_MM(((s-1)*3+1):((s-1)*3+2),r,cid)=[thetahat(5);se_GMM_hp(5)];
    m3_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,cid)=[thetahat(6);se_GMM_hp(6)];

    % AH, FDLS, AAH
    [phihat, se] = AHestim(panel);
    m1_rep_AH(((s-1)*3+1):((s-1)*3+2),r,cid) = [phihat;se]; 
    [phihat_1, se_1] = FDLSestm(panel);
    m1_rep_FDLS(((s-1)*3+1):((s-1)*3+2),r,cid) = [phihat_1;se_1]; 
    [phihat_2, se_2, KAH_2] = AAHestim(panel);
    m1_rep_AAH(((s-1)*3+1):((s-1)*3+3),r,cid) = [phihat_2;se_2;KAH_2];  

    T1 = T-1;
    K=0;
    % AB, BB
    [ coef_GMM_DIF1, coef_GMM_DIF2, coef_GMM_SYS1, coef_GMM_SYS2, var_GMM_DIF1, var_GMM_DIF2, var_GMM_SYS1, var_GMM_SYS2] = GMMestimator_ar1_v2(panel.', T1, N );

    GMM_DIF1_2step = cat(3, coef_GMM_DIF1(:,2), sqrt( diag( var_GMM_DIF1(:,:,2) ) ), sqrt( diag( var_GMM_DIF1(:,:,3) ) ) );
    GMM_SYS1_2step = cat(3, coef_GMM_SYS1(:,2), sqrt( diag( var_GMM_SYS1(:,:,2) ) ), sqrt( diag( var_GMM_SYS1(:,:,3) ) ) );
    m1_rep_AB(((s-1)*3+1):((s-1)*3+3),r,cid) = reshape(squeeze(GMM_DIF1_2step)',(K+1)*3,1);
    m1_rep_BB(((s-1)*3+1):((s-1)*3+3),r,cid) = reshape(squeeze(GMM_SYS1_2step)',(K+1)*3,1);

    clear thetahat se* var_GMM_hp phihat* KAH* GMM* 
    end
    end
    end
   end

    clear panel para ve data Tid Nid
    fn = strcat('exp_u_c',num2str(cid),"_i",num2str(init),"_m",num2str(m0),"_",num2str(GAU),num2str(GAR),'.mat');
    save(fn);
    end
end


