function [panel] = GenRandomY(N,T,init,m0,para,ve,b,kappa,cvs,GAU,GAR)

Tm = T+m0+1;

y = zeros(N,Tm); 
u = zeros(N,Tm); 
e = zeros(N,Tm); 

% random coefficients
mu_n = para(:,1);
phi_n = para(:,2);
ym = mu_n + kappa.*normrnd(repmat(b,N,1),sqrt(ve),N,1);

% coefficients for GARCH effects
cvs_n = repmat(cvs.',N,1); 

% initial processes
 if init == 1
     mn = repmat(m0,N,1);
 end
 Mn = 1 + zeros(N,Tm); 
 for i = 1:N
    Mn(i,1:(m0+1-mn(i))) = 0;
 end 


% error processes
if GAU==1
    e(:,1:Tm) = normrnd(0,1,N,Tm);
else 
    e(:,1:Tm) = 1/2*(chi2rnd(2,N,Tm)-2);
end
if GAR==0 
    h = repmat(sqrt(ve),1,Tm);
    u(:,2:Tm) = Mn(:,2:Tm).*(h(:,2:Tm).*e(:,2:Tm));
else
    h = zeros(N,Tm);
    h(:,1) = sqrt(ve); 
    for t = 2:Tm
        h(:,t) = (1- Mn(:,t)).*sqrt(ve) + Mn(:,t).*sqrt(ve-ve.*sum(cvs)+cvs_n(:,1).*h(:,t-1).^2+cvs_n(:,2).*((h(:,t-1).*e(:,t-1)).^2));
        u(:,t) = Mn(:,t).*(h(:,t).*e(:,t));    
    end
end

% generate panel data from t=-M_i+1,-M_i+2...,-1,0,1,...,T
y(:,1) = ym;
for t=2:Tm
    y(:,t)= (1-Mn(:,t)).* ym + Mn(:,t).*(mu_n.*(1-phi_n)+phi_n.*y(:,t-1)+u(:,t));
end

panel=y(:,(m0+1+1):(m0+1+T)); % n*T matrix

end




