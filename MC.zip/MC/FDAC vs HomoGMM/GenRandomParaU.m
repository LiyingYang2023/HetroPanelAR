function [para] = GenRandomParaU(N,mu_phi,a,va)
    phi_n = mu_phi + unifrnd(-a,a,N,1);
    mu_n = phi_n + normrnd(0,sqrt(va),N,1);
    para = [mu_n, phi_n];
end