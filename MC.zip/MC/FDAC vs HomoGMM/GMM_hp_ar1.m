function [thetahat,se,var,sev]=GMM_hp_ar1(Y)

%% input data

Y = Y.'; %Y is (T+1) x n matrix
dy = Y(2:end,:)-Y(1:end-1,:);
[T,n] = size(dy);

%% (G)MM estimators of heterogeneous AR(1) models
pmm = [1*(T-2>0),2*(T-3>0),3*(T-3>0)];
pm = max(pmm); % number of moments identified

% sample moments of \Delta y_{it}\Delta y_{i,t-h} with different h
dydyi1 = zeros(pm+2,n); % sample moments h=0,1,...,lagdyy
dydyi2 = zeros(3,n); % h=0,1,2 
dydyi3 = zeros(4,n); % h=0,1,2,3 
dydyi4 = zeros(5,n); % h=0,1,2,3,4 

hi1 = zeros(T-2,n); % 1st moment 
gi1 = zeros(T-2,n); 
hi2 = zeros(T-3,n); % 2nd moment
gi2 = zeros(T-3,n); 
hi3 = zeros(T-4,n); % 3rd moment
gi3 = zeros(T-4,n); 

for i =  1:n
    % sample moments of dydy(h) for MM estimators: dydyi1, dydyi2, dydyi3, dydyi4, 
    % sample moments for GMM estimators: hi1, gi1, hi2, gi2, hi3, gi3
    for ll = 0:(pm+1)
      dydyi1((ll+1),i) = mean(dy((ll+1):T,i).*dy(1:(T-ll),i)); % average over T-h 
    end   
    if pmm(1)==1
        dydyi2(:,i) = [dy(3:T,i).'*dy(3:T,i); dy(3:T,i).'*dy(2:(T-1),i); dy(3:T,i).'*dy(1:(T-2),i)]./(T-2);
        hi1(:,i) = dy(3:T,i).^(2) + dy(3:T,i).*dy(2:(T-1),i); % (T-2) vector
        gi1(:,i) = dy(3:T,i).^(2) + 2.*dy(3:T,i).*dy(2:(T-1),i) + dy(3:T,i).*dy(1:(T-2),i); 
    end
    if pmm(2)==2
        dydyi3(:,i) = [dy(4:T,i).'*dy(4:T,i); dy(4:T,i).'*dy(3:(T-1),i); dy(4:T,i).'*dy(2:(T-2),i); dy(4:T,i).'*dy(1:(T-3),i)]./(T-3);
        hi2(:,i) = dy(4:T,i).^(2) + dy(4:T,i).*dy(3:(T-1),i); % (T-3) vector
        gi2(:,i) = dy(4:T,i).^(2) + 2.*dy(4:T,i).*dy(3:(T-1),i) + 2.*dy(4:T,i).*dy(2:(T-2),i) + dy(4:T,i).*dy(1:(T-3),i);
    end
    if pmm(3)==3
        dydyi4(:,i) = [dy(5:T,i).'*dy(5:T,i); dy(5:T,i).'*dy(4:(T-1),i); dy(5:T,i).'*dy(3:(T-2),i); dy(5:T,i).'*dy(2:(T-3),i); dy(5:T,i).'*dy(1:(T-4),i)]./(T-4);
        hi3(:,i) = dy(5:T,i).^(2) + dy(5:T,i).*dy(4:(T-1),i); % (T-3) vector
        gi3(:,i) = dy(5:T,i).^(2) + 2.*dy(5:T,i).*dy(4:(T-1),i) + 2.*dy(5:T,i).*dy(3:(T-2),i) + 2.*dy(5:T,i).*dy(2:(T-3),i) + dy(5:T,i).*dy(1:(T-4),i);
    end
end

if pmm(1)==1 % estimator of 1st moment
% sample moments average across i
  dydy1 = mean(dydyi1,2); % h=0,1,2,...,lagdyy
  dydy2 = mean(dydyi2,2); % h=0,1,2
% MM Version a: dydy1 with different T-h data points
  mm1 = (dydy1(1)+2*dydy1(2)+dydy1(3))/(dydy1(1)+dydy1(2)); % 1st moment
  mms1 = mean((dydyi1(1,:)+2.*dydyi1(2,:)+dydyi1(3,:)-mm1.*(dydyi1(1,:)+dydyi1(2,:))).^2); 
  av1 = ((mean(dydyi1(1,:)+dydyi1(2,:))).^(2).*(mms1^(-1)))^(-1); % estimated asymptotic variance
%GMM A: 1st moment
  hnt1 = mean(hi1,2);
  gnt1 = mean(gi1,2);
  gmms1 = (gi1-mm1.*hi1) * (gi1-mm1.*hi1).' /n;  % the optimal weight matrix
  gmm1 =  (hnt1.' * pinv(gmms1) * hnt1)^(-1) * (hnt1.' * pinv(gmms1) * gnt1); % 1st moment
  avgmm1 = (hnt1.' * pinv(gmms1) * hnt1)^(-1); % asymptotic variance of the GMM estimator of 1st moment  
end

if pmm(2)==2
% sample moments average across i
  dydy3 = mean(dydyi3,2); % h=0,1,2,3
% MM A: dydy1 with different T-h data points
  mm2 = (dydy1(1)+2*dydy1(2)+2*dydy1(3)+dydy1(4))/(dydy1(1)+dydy1(2)); % 2nd moment
  mms2 = mean((dydyi1(1,:)+2.*dydyi1(2,:)+2.*dydyi1(3,:)+dydyi1(4,:)-mm2.*(dydyi1(1,:)+dydyi1(2,:))).^2);
  av2 = ((mean(dydyi1(1,:)+dydyi1(2,:))).^(2).*(mms2^(-1)))^(-1);  % estimated asymptotic variance
% GMM A
  hnt2 = mean(hi2,2);
  gnt2 = mean(gi2,2);
  gmms2 = (gi2-mm2.*hi2) * (gi2-mm2.*hi2).' /n;  % the optimal weight matrix
  gmm2 =  (hnt2.' * pinv(gmms2) * hnt2)^(-1) * (hnt2.' * pinv(gmms2) * gnt2); % second moment
  avgmm2 = (hnt2.' * pinv(gmms2) * hnt2)^(-1); % estimated asymtotic variance 
  jgmmsi = zeros(2*T-5,2*T-5,n); % variance of joint moments for each i
  for i =1:n
      jgmmsi(:,:,i)=[gi1(:,i)-mm1.*hi1(:,i);gi2(:,i)-mm2.*hi2(:,i)]*[gi1(:,i)-mm1.*hi1(:,i);gi2(:,i)-mm2.*hi2(:,i)].';    
  end
  
% estimators of variance 
  % MM A: Var
  var = mm2-mm1^2; 
  mi1 = dydyi1(1,:)+2.*dydyi1(2,:)+dydyi1(3,:) - mm1 .* (dydyi1(1,:)+dydyi1(2,:)); % column vector
  mi2 = dydyi1(1,:)+2.*dydyi1(2,:)+2.*dydyi1(3,:)+dydyi1(4,:) - mm2.* (dydyi1(1,:)+dydyi1(2,:));
  svar2 = 1/n.*[mi1*mi1.',mi1*mi2.';mi2*mi1.',mi2*mi2.'];
  avv = [-2*mm1,1]*[1/(dydy1(1)+dydy1(2)),0;0,1/(dydy1(1)+dydy1(2))]* svar2 *[1/(dydy1(1)+dydy1(2)),0;0,1/(dydy1(1)+dydy1(2))]*[-2*mm1;1]; % estimated asymtotic variance 
 % GMM A: plug in gmm estimators of 1st and 2nd moments
  vargmm = gmm2-gmm1^2;
  jh2 = [hnt1,zeros(T-2,1);zeros(T-3,1),hnt2]; 
  gmma2 = [pinv(gmms1), zeros(T-2,T-3) ;zeros(T-3,T-2),pinv(gmms2)]; % weight matrix
  svargmm2 = pinv(jh2.' * gmma2 * jh2) * jh2.' * gmma2 * mean(jgmmsi,3) * gmma2.' * jh2 * pinv(jh2.'* gmma2.' * jh2);
  avgmmv = [-2*gmm1,1]*svargmm2*[-2*gmm1;1]; % asymptotic variance of hat{var}
end 

if pmm(3)==3 % estimator of 3rd moment
% sample moments average across i
  dydy4 = mean(dydyi4,2); % h=0,1,2,3,4
% MM Version a: dydy1 with different T-h data points
  mm3 = (dydy1(1)+2*dydy1(2)+2*dydy1(3)+2*dydy1(4)+dydy1(5))/(dydy1(1)+dydy1(2)); % 3rd moment
  mms3 = mean((dydyi1(1,:)+2.*dydyi1(2,:)+2.*dydyi1(3,:)+2.*dydyi1(4,:)+dydyi1(5,:)-mm3.*(dydyi1(1,:)+dydyi1(2,:))).^2);
  av3 = ((mean(dydyi1(1,:)+dydyi1(2,:))).^(2).*(mms3^(-1)))^(-1);
% GMM
  hnt3 = mean(hi3,2);
  gnt3 = mean(gi3,2);
  gmms3 = (gi3-mm3.*hi3) * (gi3-mm3.*hi3).' /n;  % the optimal weight matrix (T-3)x(T-3) 
  gmm3 = (hnt3.' * pinv(gmms3) * hnt3)^(-1) * (hnt3.' * pinv(gmms3) * gnt3);
  avgmm3 = (hnt3.' * pinv(gmms3) * hnt3)^(-1); % asymptotic variance
end

%% report results
if pm>2
    thetahat = [mm1,gmm1,mm2,gmm2,mm3,gmm3];
    se= ([av1,avgmm1,av2,avgmm2,av3,avgmm3]./n).^0.5;
    var = [var,vargmm];
    sev = ([avv,avgmmv]./n).^0.5;
elseif pm>1
    thetahat = [mm1,gmm1,mm2,gmm2];
    se= ([av1,avgmm1,av2,avgmm2]./n).^0.5;
    var = [var,vargmm];
    sev = ([avv,avgmmv]./n).^0.5;
elseif pm>0
    thetahat = [mm1,gmm1];
    se= ([av1,avgmm1]./n).^0.5;
    var=NaN;
    sev=NaN;
end
return % function



