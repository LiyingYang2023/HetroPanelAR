###### Pesaran and Yang (2024) "Hetro. AR panels"
rm(list=ls())

## Please change the path to the directory where the simulation outcomes are stores. 
# setwd('~/Downloads') 

## Please install the following packages. 
# list.of.packages <- c("openxlsx","R.matlab")
# new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
# if(length(new.packages)) install.packages(new.packages)

library(openxlsx)
library(R.matlab)



## Compare FDAC and HomoGMM estimators
##############################################################################

rep = 2000; 
Nlist = c(100,1000,5000); Tlist = c(4,6,10)
NT = expand.grid(Nlist,Tlist); NT = cbind(NT[,2],NT[,1]);

#### Functions: calculate statistics
## (Bias, RMSE, T_test & Power, Coverage)
################################################################################
Bias = function(ests,truev) {
  ests = as.matrix(ests)
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  colMeans(ests - truematrix)
}

RMSE = function(ests,truev) {
  ests = as.matrix(ests)
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  sqrt(colMeans((ests - truematrix)^2))
}

T_test = function(truev,estsd,rep){
  ests = as.matrix(estsd[1:rep])
  sds = as.matrix(estsd[(rep+1):(2*rep)])
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  colMeans(abs((ests-truematrix)/sds)>qnorm(p = 0.975))
}

pwlb=-2.5; pwrb=2.5; pwintv=0.01;
pwgrid = length(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv)))
Power = function(truev,estsd,rep){
  h1 = as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv)) # values of alternatives (v0-0.5,v0+0.5) length = 101
  powers = sapply(h1,function(x) T_test(x,estsd,rep))
  powers
}
################################################################################

## Functions: set the format of numbers reported in each cell
## (percent, specify_decimal)
#########################################################################
percent = function(x, digits = 0, format = "f") {
  paste0(formatC(100 * x, format = format, digits = digits), "\\%")
}

specify_decimal = function(x, k) {
  trimws(format(round(x, k), nsmall=k))
}
#########################################################################

# Create a style for center-aligning the numbers
##############################################################################
center_style <- createStyle(halign = "center")
right <- createStyle(halign = "right")
left <- createStyle(halign = "left")
bbs <- createStyle(border = "bottom",borderStyle="thin")
lbl <- createStyle(border = "left",borderStyle="thin")
lbs <- createStyle(border = "bottom",borderStyle="double")
tbs <- createStyle(border = "top",borderStyle="double")
wrap_text_style <- createStyle(wrapText = TRUE)

pwlb=-2.5; pwrb=2.5; pwintv=0.01;
pwgrid = length(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv)))
k=2;
##############################################################################

wb <- createWorkbook()

## Tables
##############################################################################
list = c('Table S.8','Table S.9','Table S.10')
case_l = c(2,3,1)
for (cid in 1:length(list)) {
  case = case_l[cid]
  GAUSSIAN = 1; GARCH = 0; init = 1; m0 = 100

  df = paste("exp_u_c",case,"_i",init,"_m",m0,'_',GAUSSIAN,GARCH,".mat",sep="")
  en = -9999; data = tryCatch(readMat(df),error=function(e) print(en))
  
  sn = list[cid]
  if (data[1] != en) {
    addWorksheet(wb, sn)
    if (cid==1) {
      writeData(wb, sn, x = "Table S.8: Bias, RMSE, and size of FDAC, FDLS, AH, AAH, AB, and BB estimators of E(phi_i) = mu_phi = 0.4 in a heterogeneous panel AR(1) model with uniformly distributed |phi_i|<1 and Gaussian errors wthout GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
    }
    if (cid==2) {
      writeData(wb, sn, x = "Table S.9: Bias, RMSE, and size of FDAC, FDLS, AH, AAH, AB, and BB estimators of E(phi_i) = mu_phi = 0.5 in a heterogeneous panel AR(1) model with uniformly distributed phi_i in [-1 + epsilon, 1] for some epsilon > 0 and Gaussian errors without GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
    }
    if (cid==3) {
      writeData(wb, sn, x = "Table S.10: Bias, RMSE, and size of FDAC, FDLS, AH, AAH, AB, and BB estimators of phi (phi_0 = 0.5) in a homogeneous panel AR(1) model with Gaussian errors without GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
    }
    alist = c(0.5,0.5,0)
    a = alist[cid]
    mblist = c(0.4,0.5,0.5)
    mb = mblist[cid]
    vb = a^(2/3)
    
    #### Create empty matrices to store bias, RMSE, etc.
    m1_bias = matrix(,dim(NT)[1],6)
    m1_rmse = matrix(,dim(NT)[1],6) 
    m1_size = matrix(,dim(NT)[1],6)
    m1_pw = matrix(,dim(NT)[1],6*pwgrid)
    
    #### Get the respective simulation results
    for (j in 1:6) {
      if (j==1) {
        mc_results = data$m1.rep.MM
      }
      if (j==2) {
        mc_results = data$m1.rep.FDLS
      }
      if (j==3) {
        mc_results = data$m1.rep.AH
      }
      if (j==4) {
        mc_results = data$m1.rep.AAH
      }
      if (j==5) {
        mc_results = data$m1.rep.AB
      }
      if (j==6) {
        mc_results = data$m1.rep.BB
      }
      
      for (ss in 1:dim(NT)[1]){ #sample size
        if (case==1) {
          mc_results1 = t(mc_results[((ss-1)*3+1):((ss-1)*3+2),])
        } 
        if (case %in% c(2,3)) {
          mc_results1 = t(mc_results[((ss-1)*3+1):((ss-1)*3+2),,case])
        }
        
        #### Calculate bias, RMSE, size and powers for moments
        results_m1 = mc_results1[,1]
        results_m1_sd = mc_results1[,2]
        m1_bias[ss,j] = Bias(results_m1, mb)
        m1_rmse[ss,j] = RMSE(results_m1, mb)
        e1 = cbind(results_m1,results_m1_sd)
        m1_pw[ss,(pwgrid*(j-1)+1):(pwgrid*(j-1)+pwgrid)] = Power(mb,e1,rep) # length = no. alternative values
        m1_size[ss,j] = m1_pw[ss,pwgrid*(j-1)+(pwgrid-1)/2+1]; rm(e1)
      }
    }
    
    #### Figure: Compare FDAC and FDLS estimators
    #########################################################################
    if (case == 1) {
      powermm1_1 = t(m1_pw[,1:501]) # FDAC estimator
      powermm1_2 = t(m1_pw[,502:1002]) # FDLS estimator
      name = "Figure S.3.png"

      #### Define x axis by alternative values
      #####################################################################################
      truev = 0.5
      mcm = as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv))
      intv = 0.2
      #####################################################################################

      png(name, units="in", width=28, height=26, res=50)
      par(mai=c(3,2,2,2),xpd=TRUE, mfrow=c(2,2),oma=c(4,3,2,2)) # (b,l,t,r)

      #### T=4
      d1 = 201; d2= 301
      mx = mcm[d1:d2]
      xmin = min(mx)
      xmax = max(mx)
      ymin = 0
      ymax = 1
      intv=0.1
      plot(mx, powermm1_1[d1:d2,1], type="l", col=1, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main=expression(paste("T=4, n=100")),cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
      lines(mx, powermm1_2[d1:d2,1], type="l", col=2, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
      axis(side=1, at=round(seq(xmin, xmax, by=intv),1), mgp=c(2, 3.5, 0), cex.axis=3.5)
      axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
      arrows(truev,-0.01, truev, 1, length = 0,lty =3,lwd=3) # denote the true value
      arrows(xmin,0.05,xmax,0.05, length = 0,lty = 3, lwd=3) # denote a line of 5% probability
      mtext("power", side = 2, line = 5, at = 1 , cex = 3)
      mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)
      mtext(expression(mu[phi]), side = 1, line = 8, at = xmax , cex = 3) # label of x-axis
      mtext(expression(mu[paste(phi,",0")]), side = 1, line = 8, at = truev , cex = 3) # label of x-axis    

      d1 = 201; d2= 301
      mx = mcm[d1:d2]
      xmin = min(mx)
      xmax = max(mx)
      ymin = 0
      ymax = 1
      intv=0.1
      plot(mx, powermm1_1[d1:d2,3], type="l", col=1, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main=expression(paste("T=4, n=5,000")),cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
      lines(mx, powermm1_2[d1:d2,3], type="l", col=2, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
      axis(side=1, at=round(seq(xmin, xmax, by=intv),1), mgp=c(2, 3.5, 0), cex.axis=3.5)
      axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
      arrows(truev,-0.01, truev, 1, length = 0,lty =3,lwd=3) # denote the true value
      arrows(xmin,0.05,xmax,0.05, length = 0,lty = 3, lwd=3) # denote a line of 5% probability
      mtext("power", side = 2, line = 5, at = 1 , cex = 3)
      mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)
      mtext(expression(mu[phi]), side = 1, line = 8, at = xmax , cex = 3) # label of x-axis
      mtext(expression(mu[paste(phi,",0")]), side = 1, line = 8, at = truev , cex = 3) # label of x-axis    

      ### T=10
      d1 = 201; d2= 301
      mx = mcm[d1:d2]
      xmin = min(mx)
      xmax = max(mx)
      ymin = 0
      ymax = 1
      intv=0.1
      plot(mx, powermm1_1[d1:d2,7], type="l", col=1, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main=expression(paste("T=10, n=100")),cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
      lines(mx, powermm1_2[d1:d2,7], type="l", col=2, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
      axis(side=1, at=round(seq(xmin, xmax, by=intv),1), mgp=c(2, 3.5, 0), cex.axis=3.5)
      axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
      arrows(truev,-0.01, truev, 1, length = 0,lty =3,lwd=3) # denote the true value
      arrows(xmin,0.05,xmax,0.05, length = 0,lty = 3, lwd=3) # denote a line of 5% probability
      mtext("power", side = 2, line = 5, at = 1 , cex = 3)
      mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)
      mtext(expression(mu[phi]), side = 1, line = 8, at = xmax , cex = 3) # label of x-axis
      mtext(expression(mu[paste(phi,",0")]), side = 1, line = 8, at = truev , cex = 3) # label of x-axis    

      d1 = 201; d2= 301
      mx = mcm[d1:d2]
      xmin = min(mx)
      xmax = max(mx)
      ymin = 0
      ymax = 1
      intv=0.1
      plot(mx, powermm1_1[d1:d2,9], type="l", col=1, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main=expression(paste("T=10, n=5,000")),cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
      lines(mx, powermm1_2[d1:d2,9], type="l", col=2, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
      axis(side=1, at=round(seq(xmin, xmax, by=intv),1), mgp=c(2, 3.5, 0), cex.axis=3.5)
      axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
      arrows(truev,-0.01, truev, 1, length = 0,lty =3,lwd=3) # denote the true value
      arrows(xmin,0.05,xmax,0.05, length = 0,lty = 3, lwd=3) # denote a line of 5% probability
      mtext("power", side = 2, line = 5, at = 1 , cex = 3)
      mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)
      mtext(expression(mu[phi]), side = 1, line = 8, at = xmax , cex = 3) # label of x-axis
      mtext(expression(mu[paste(phi,",0")]), side = 1, line = 8, at = truev , cex = 3) # label of x-axis    

      par(fig = c(0, 1, 0, 1), oma = c(0, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)
      plot(0, 0, type = 'l', bty = 'n', xaxt = 'n', yaxt = 'n')
      legend('bottom',legend = c("FDAC", "FDLS"), lty = c(1,4),col = c(1,2), lwd = 5, xpd = TRUE, horiz = TRUE, cex = 4, seg.len=5, bty = 'n')

      dev.off()
    }
    #########################################################################
    
    #### Set Table Size
    #########################################################################
    nr = length(Tlist); rl = seq(1,nr,by=1); 
    nr2 = length(Nlist); rl2 = seq(1,nr2,by=1); Nlist2 = c("100","1,000","5,000")
    nc = 6
    tab = matrix(,nr*(nr2+1)-1,2+(nc+1)*3) 
    tab2 = matrix(,nr*(nr2+1)-1,2+(nc+1)*3) 
    #########################################################################
    
    #### Put numbers into the respective cells
    #########################################################################
    for (r1 in 1:nr) {
      for (r2 in 1:nr2) {
        tab2[r2+(r1-1)*(nr2+1),1] = Tlist[r1]
        tab2[r2+(r1-1)*(nr2+1),2] = Nlist2[r2]   
        tab[r2+(r1-1)*(nr2+1),4:9] = m1_bias[r2+(r1-1)*nr2,]
        tab[r2+(r1-1)*(nr2+1),11:16] = m1_rmse[r2+(r1-1)*nr2,]
        tab[r2+(r1-1)*(nr2+1),18:23] = m1_size[r2+(r1-1)*nr2,]
      }
    }
    
    #### Change the formats of each column
    for (col in c(4:9,11:16)) {
      v0 = tab[,col]; v1 = v0
      for (i in 1:length(v0)) {
        if (is.na(v0[i]) == 0) {
          v1[i] = format(round(v0[i], 3), nsmall = 3) 
        } else {
          v1[i] = ""
        }
      }
      tab2[,col] = v1; rm(v0,v1)
    }
    for (col in c(18:23)) {
      v0 = tab[,col]; v1 = v0
      for (i in 1:length(v0)) {
        if (is.na(v0[i]) == 0) {
          v1[i] = format(round(v0[i]*100, 1), nsmall = 1) 
        } else {
          v1[i] = ""
        }
      }
      tab2[,col] = v1; rm(v0,v1)
    }
    #########################################################################
    
    h1 = c("T","n",rep(c("","FDAC","FDLS","AH","AAH","AB","BB"),3))
    h = rbind(h1,tab2)
    rownames(h) <- NULL
    colnames(h) <- NULL
    writeData(wb,sn, x = h, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)
    writeData(wb, sn, x = "Bias", startCol = 4, startRow = 2, colNames = FALSE)
    writeData(wb, sn, x = "RMSE", startCol = 11, startRow = 2, colNames = FALSE)
    writeData(wb, sn, x = "Size (*100)", startCol = 18, startRow = 2, colNames = FALSE)
    mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 1)
    mergeCells(wb, sheet = sn, cols = 4:9, rows = 2)
    mergeCells(wb, sheet = sn, cols = 11:16, rows = 2)
    mergeCells(wb, sheet = sn, cols = 18:23, rows = 2)
    
    addStyle(wb,sn,style = center_style, rows = 2:3, cols = 1:(ncol(h)), gridExpand = TRUE)
    addStyle(wb,sn,style = right, rows = 4:(nrow(h)+2), cols = 2:(ncol(h)), gridExpand = TRUE)
    addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = bbs, rows = 2,cols = c(4:9,11:16,18:23), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = bbs, rows = 3,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = lbs, rows = (nrow(h)+2),cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    
    rm(df)
  } 
}
##############################################################################

## Tables with different initializations
##############################################################################
list = c('Table S.14','Table S.15','Table S.16')
GAUSSIAN = 1; GARCH = 0
alist = c(0,0.5,0.5); mblist = c(0.5,0.4,0.5)
init = 1; m0_list = c(100,3,1)

for (cid in 1:length(list)) {
  sn = list[cid]
  addWorksheet(wb, sn)
  if (cid==1) {
    writeData(wb, sn, x = "Table S.14: Bias, RMSE, and size of FDAC, FDLS, AH, AAH, AB, and BB estimators of phi (phi_0 = 0.5) in a homogeneous panel AR(1) model with Gaussian errors without GARCH effects, and different initializations", startCol = 1, startRow = 1, colNames = FALSE)
  }
  if (cid==2) {
    writeData(wb, sn, x = "Table S.15: Bias, RMSE, and size of FDAC, FDLS, AH, AAH, AB, and BB estimators of mu_phi = E(phi_i) = 0.4 in a heterogeneous panel AR(1) model with uniformly distributed phi_i in [-1 + epsilon, 1] for some epsilon > 0, Gaussian errors without GARCH effects, and different initializations", startCol = 1, startRow = 1, colNames = FALSE)
  }
  if (cid==3) {
    writeData(wb, sn, x = "Table S.16: Bias, RMSE, and size of FDAC, FDLS, AH, AAH, AB, and BB estimators of mu_phi = E(phi_i) = 0.5 in a heterogeneous panel AR(1) model with uniformly distributed |phi_i|<=1, Gaussian errors without GARCH effects, and different initializations", startCol = 1, startRow = 1, colNames = FALSE)
  }
  mb = mblist[cid]
  a = alist[cid]
  vb = a^(2/3)
  
  #### Create empty matrices to store bias, RMSE, etc.
  m1_bias = matrix(,dim(NT)[1],6*4-1)
  m1_rmse = matrix(,dim(NT)[1],6*4-1) 
  m1_size = matrix(,dim(NT)[1],6*4-1)
  m1_pw = matrix(,dim(NT)[1],6*3*pwgrid)

  for (mid in 1:length(m0_list)) {
    m0 = m0_list[mid]
    df = paste("exp_u_c",cid,"_i",init,"_m",m0,"_",GAUSSIAN,GARCH,".mat",sep="")
    en = -9999; data = tryCatch(readMat(df),error=function(e) print(en))
    
    if (data[1] != en) {
      
      #### Get the respective simulation results
      for (j in 1:6) {
        if (j==1) {
          mc_results = data$m1.rep.MM
        }
        if (j==2) {
          mc_results = data$m1.rep.FDLS
        }
        if (j==3) {
          mc_results = data$m1.rep.AH
        }
        if (j==4) {
          mc_results = data$m1.rep.AAH
        }
        if (j==5) {
          mc_results = data$m1.rep.AB
        }
        if (j==6) {
          mc_results = data$m1.rep.BB
        }
        
        for (ss in 1:dim(NT)[1]){ #sample size
          if (cid==1) {
            mc_results1 = t(mc_results[((ss-1)*3+1):((ss-1)*3+2),])
          } else {
            mc_results1 = t(mc_results[((ss-1)*3+1):((ss-1)*3+2),,cid])
          }
          
          #### Calculate bias, RMSE, size and powers for moments
          results_m1 = mc_results1[,1]
          results_m1_sd = mc_results1[,2]
          m1_bias[ss,mid+(j-1)*4] = Bias(results_m1, mb)
          m1_rmse[ss,mid+(j-1)*4] = RMSE(results_m1, mb)
          e1 = cbind(results_m1,results_m1_sd)
          m1_pw[ss,(pwgrid*(mid+(j-1)*3-1)+1):(pwgrid*(mid+(j-1)*3-1)+pwgrid)] = Power(mb,e1,rep) # length = no. alternative values
          m1_size[ss,mid+(j-1)*4] = m1_pw[ss,pwgrid*(mid+(j-1)*3-1)+(pwgrid-1)/2+1]; rm(e1)
        }
      }
    } 
  }
  
  nr = length(Tlist); rl = seq(1,nr,by=1); 
  nr2 = length(Nlist); rl2 = seq(1,nr2,by=1); Nlist2 = c("100","1,000","5,000")
  nc = 3
  tab = matrix(,3*nr*(nr2+1)-1,(nc+1)*6-1) 
  tab2 = matrix(,3*nr*(nr2+1)-1,2+(nc+1)*6) 
  #########################################################################
  
  #### Put numbers into the respective cells
  #########################################################################
  for (r1 in 1:nr) {
    for (r2 in 1:nr2) {
      tab2[r2+(r1-1)*(nr2+1),1] = Tlist[r1]
      tab2[r2+(r1-1)*(nr2+1),2] = Nlist2[r2]  
      tab2[r2+(r1-1)*(nr2+1)+12,1] = Tlist[r1]
      tab2[r2+(r1-1)*(nr2+1)+12,2] = Nlist2[r2]  
      tab2[r2+(r1-1)*(nr2+1)+24,1] = Tlist[r1]
      tab2[r2+(r1-1)*(nr2+1)+24,2] = Nlist2[r2]  
      
      tab[r2+(r1-1)*(nr2+1),] = m1_bias[r2+(r1-1)*3,]
      tab[r2+(r1-1)*(nr2+1)+12,] = m1_rmse[r2+(r1-1)*3,]
      tab[r2+(r1-1)*(nr2+1)+24,] = m1_size[r2+(r1-1)*3,]
    }
  }

  
  #### Change the formats of each column
  for (rows in c(1:11,13:23)) {
    v0 = tab[rows,]; v1 = v0
    for (i in 1:length(v0)) {
      if (is.na(v0[i]) == 0) {
        v1[i] = format(round(v0[i], 3), nsmall = 3) 
      } else {
        v1[i] = ""
      }
    }
    tab2[rows,4:(2+(nc+1)*6)] = v1; rm(v0,v1)
  }
  for (rows in c(25:35)) {
    v0 = tab[rows,]; v1 = v0
    for (i in 1:length(v0)) {
      if (is.na(v0[i]) == 0) {
        v1[i] = format(round(v0[i]*100, 1), nsmall = 1) 
      } else {
        v1[i] = ""
      }
    }
    tab2[rows,4:(2+(nc+1)*6)] = v1; rm(v0,v1)
  }
  #########################################################################
  
  cv1 = c(rep("",5),"Bias",rep("",11),"RMSE",rep("",11),"Size (*100)",rep("",5))
  tab3 = cbind(cv1,tab2)
  h1 = c(rep("",4),"FDAC",rep("",3),"FDLS",rep("",3),"AH",rep("",3),"AAH",rep("",3),"AB",rep("",3),"BB",rep("",2))
  h2 = c("","T","n/M_0",rep(c("","100","3","1"),6))
  h = rbind(h1,h2,tab3)
  rownames(h) <- NULL
  colnames(h) <- NULL
  writeData(wb,sn, x = h, startCol = 1, startRow = 2,colNames = FALSE, rowNames = FALSE)
  mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 1)
  mergeCells(wb, sheet = sn, cols = 5:7, rows = 2)
  mergeCells(wb, sheet = sn, cols = 9:11, rows = 2)
  mergeCells(wb, sheet = sn, cols = 13:15, rows = 2)
  mergeCells(wb, sheet = sn, cols = 17:19, rows = 2)
  mergeCells(wb, sheet = sn, cols = 21:23, rows = 2)
  mergeCells(wb, sheet = sn, cols = 25:27, rows = 2)
  
  addStyle(wb,sn,style = center_style, rows = 2:3, cols = 1:(ncol(h)), gridExpand = TRUE)
  addStyle(wb,sn,style = right, rows = 4:(nrow(h)+2), cols = 2:(ncol(h)), gridExpand = TRUE)
  addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
  addStyle(wb,sn,style = bbs, rows = 2,cols = c(5:7,9:11,13:15,17:19,21:23,25:27), gridExpand = TRUE,stack=TRUE)
  addStyle(wb,sn,style = bbs, rows = c(3,14,15,26,27),cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
  addStyle(wb,sn,style = lbl, rows = 2:(nrow(h)+1),cols = 2, gridExpand = TRUE,stack=TRUE)
  addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
  addStyle(wb,sn,style = lbs, rows = (nrow(h)+1),cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
  
  rm(df)
}
##############################################################################


# Save the workbook to an Excel file
saveWorkbook(wb, file = "HetroAR_MC_FDAC_vs_HomoGMM_results.xlsx",overwrite = TRUE)
cat("The MC results have been written to the excel file HetroAR_MC_FDAC_vs_HomoGMM_results.xlsx.")
##############################################################################






