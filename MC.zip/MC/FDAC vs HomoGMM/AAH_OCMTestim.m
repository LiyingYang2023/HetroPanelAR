function [phihat, se,K]=AAH_OCMTestim(Y)
%Y is N x T+1
dy=Y(:,1:end-1)-Y(:,2:end);
[N,T]=size(dy);

%% estimations - general
K=(T-2)*(T-1)/2+(T-2); % number of moment conditions

wqm=ones(T-2,1)/(T-2);
wah=ones((T-2)*(T-1)/2,1)/ ((T-2)*(T-1)/2);
w1=[0.5*wah', 0.5*wqm']';

% define Sample Moment Conditions
%m=m0-phi*m1+pji*m2
m0=zeros(K,1); m0i=zeros(K,N); 
m1=zeros(K,1); m1i=zeros(K,N); 
m2=zeros(K,1); m2i=zeros(K,N); 

k=0;
%dy=Data.dY;
for s=2:T-1
    for t=s+1:T
        k=k+1;
        % moment dy_i,t-s * (dy_i,t-phi* dy_i,t-1)
        m0i(k,:)=dy(:,t-s).*dy(:,t);
        m1i(k,:)=dy(:,t-s).*dy(:,t-1);
        m0(k,1)=sum(dy(:,t-s).*dy(:,t))/N;
        m1(k,1)=sum(dy(:,t-s).*dy(:,t-1))/N;
    end
end
% now augment with BMM moments

for t=2:T-1
    k=k+1;
    m0i(k,:)=dy(:,t).*dy(:,t-1)+dy(:,t).*dy(:,t)+dy(:,t+1).*dy(:,t);
    m0(k,1)=m0i(k,:)*ones(N,1)/N;
    m1i(k,:)=dy(:,t-1).*dy(:,t-1)+2*dy(:,t).*dy(:,t-1)+dy(:,t).*dy(:,t);
    m1(k,1)=m1i(k,:)*ones(N,1)/N;
    m2i(k,:)=dy(:,t-1).*dy(:,t-1);
    m2(k,1)=m2i(k,:)*ones(N,1)/N;
end

%% now conduct pre-selection
% pre-selection is done on AH moment with s>2 only
% these are the moments k=T-1,T-2,... (T-2)*(T-1)/2
sind=false(1,K);

% select moments first
itr=zeros(T-3,1);
for t=4:T
   indsearch=false(T,1);
   indsearch(1:t-3,1)=true;
   Xcond=dy(:,t-2);
   X=dy(:,indsearch);
   y=dy(:,t-1);
   pval=0.05; delta1=1; delta2=2;
   [inds, itr(t-3)] = OCMT_sel(y,X,Xcond, pval, delta1, delta2 );
  % inds=indsearch;
   % s=t-1,...,3
   % now assign selected moments
   k=0;
   for s=2:T-1
     for tt=s+1:T
        k=k+1;
        if t==tt && s>2
            sind(1,k)=inds(t-s);
        end
     end
   end
   
end

% now add remaining moments
ind1=false(1,K);
ind1(1:T-2)=true;
ind1((T-2)*(T-1)/2+1:K)=true;

indu=sind | ind1;
Kr=sum(indu);

m0r=m0(indu);
m1r=m1(indu);
m2r=m2(indu);

% 1-step estimator
os = optimset('LargeScale','off','MaxFunEvals',10^5,'MaxIter',10^5,'TolX',1e-8);
options = optimset('Display','off', 'TolX',1e-6);%
lq = -2;
uq = 2;
stphi=0;
%w1=Wo.aah1;
W1=w1*w1';

Wr=W1(indu,indu);
w1r=w1(indu);
str=evalc('[para,obj,ef, output]=fminunc(@objg_12step,stphi,options,m0r,m1r,m2r, Wr)');
phi_1stepcheck=para;

%phi_1step=w1'*m0/(w1'*m1);

% alternative
%m0-phi*m1+phi^2*m2
Dtmnt=(w1r'*m1r)^2-4*(w1r'*m2r)*(w1r'*m0r);
if Dtmnt>=0
    x1=(w1r'*m1r+Dtmnt^0.5)/2/(w1r'*m2r);
    x2=(w1r'*m1r-Dtmnt^0.5)/2/(w1r'*m2r);
    % now select root
    a1=m0r-x1*m1r+x1^2*m2r;
    a2=m0r-x2*m1r+x2^2*m2r;
    na1=a1'*a1;
    na2=a2'*a2;
    if na1<na2
        phi_1step=x1;
    else
        phi_1step=x2;
    end
end
if Dtmnt<0
    phi_1step=w1r'*m1r/(w1r'*m2r)/2;
end



% 2-step estimator

S=zeros(Kr,Kr); sm=zeros(Kr,1);
Sa=zeros(Kr,Kr); Sb=zeros(Kr,Kr); Sc=zeros(Kr,Kr); Sd=zeros(Kr,Kr); Se=zeros(Kr,Kr);
A=zeros(N,Kr);
for i=1:N
   a=m0i(indu,i)-phi_1step*m1i(indu,i)+(phi_1step^2)*m2i(indu,i);
   Si= a*a';
   sm=sm+a/N;
   A(i,:)=a';
   S=S+Si;
   Sia=m0i(indu,i)*m0i(indu,i)';
   Sib=-m0i(indu,i)*m1i(indu,i)'-m1i(indu,i)*m0i(indu,i)';
   Sic=m1i(indu,i)*m1i(indu,i)'+m2i(indu,i)*m0i(indu,i)'+m0i(indu,i)*m2i(indu,i)';
   Sid=-m2i(indu,i)*m1i(indu,i)'-m1i(indu,i)*m2i(indu,i)';
   Sie=m2i(indu,i)*m2i(indu,i)';
   Sa=Sa+Sia;
   Sb=Sb+Sib;
   Sc=Sc+Sic;
   Sd=Sd+Sid;
   Se=Se+Sie;
end
S1=S/N;
Sa=Sa/N;
Sb=Sb/N;
Sc=Sc/N;
Sd=Sd/N;
Se=Se/N;

%Salt=Sa+phi_1step*Sb+(phi_1step^2)*Sc+(phi_1step^3)*Sd+(phi_1step^4)*Se;

W2=pinv(S1-sm*sm');
W=W2;
if abs(phi_1step)<1
    stphi=phi_1step;
else
    stphi=0;
end
str=evalc('[para,obj,ef, output]=fminunc(@objg_12step,stphi,options,m0r,m1r,m2r, W)');
phi_2step=para;

% now asymptotic variance
D1=-m1r+2*phi_1step*m2r;
av_1step=pinv(D1'*Wr*D1)*D1'*Wr*S1*Wr'*D1*pinv(D1'*Wr*D1);
D2=-m1r+2*phi_2step*m2r;
av_2step=pinv(D2'*pinv(S1-sm*sm')*D2);

%% now report results
se=(av_2step/N)^0.5;
phihat=phi_2step;

return % function


%% declare functions

function obj=objg_12step(phi,m0,m1, m2, W)

% get params from psi
m=m0-phi*m1+phi*phi*m2;

obj=m'*W*m;

return

function obj=objg(phi,m0,m1,m2, Sa,Sb,Sc,Sd,Se)

% get params from psi
m=m0-phi*m1+phi*phi*m2;
S=Sa+phi*Sb+(phi^2)*Sc+(phi^3)*Sd+(phi^4)*Se;

obj=m'*pinv(S)*m;

return