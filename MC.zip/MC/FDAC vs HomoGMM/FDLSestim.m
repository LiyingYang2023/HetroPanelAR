function [phihat, se,K]=FDLSestim(Y)
%Y is N x T+1
dy=Y(:,1:end-1)-Y(:,2:end);
[N,T]=size(dy); % effective T after first differencing

%% estimations
K=T-1; % number of moment conditions

Kaah_aveT=T-1;
% initialize Wopt
Ws1.aah_aveT1=eye(Kaah_aveT);


% define Sample Moment Conditions
%m=m0-phi*m1+pji*m2
m0=zeros(K,1); m0i=zeros(K,N); 
m1=zeros(K,1); m1i=zeros(K,N); 
m2=zeros(K,1); m2i=zeros(K,N); 

k=0;
for s=2:T-1
     k=k+1;
    for t=s+1:T
        % moment dy_i,t-s * (dy_i,t-phi* dy_i,t-1)
        m0i(k,:)= m0i(k,:)+ (dy(:,t-s).*dy(:,t))'/(T-s);
        m1i(k,:)= m1i(k,:)+ (dy(:,t-s).*dy(:,t-1))'/(T-s);
        m0(k,1)= m0(k,1)+ sum(dy(:,t-s).*dy(:,t))/(T-s)/N;
        m1(k,1)= m1(k,1)+ sum(dy(:,t-s).*dy(:,t-1))/(T-s)/N;
    end
end
% now augment with aggregated BMM moments

k=k+1;
for t=2:T-1
    m0i(k,:)=m0i(k,:)+ (dy(:,t).*dy(:,t-1)+dy(:,t).*dy(:,t)+dy(:,t+1).*dy(:,t))'/(T-2);
    m0(k,1)=m0i(k,:)*ones(N,1)/N;
    m1i(k,:)=m1i(k,:) + (dy(:,t-1).*dy(:,t-1)+2*dy(:,t).*dy(:,t-1)+dy(:,t).*dy(:,t))'/(T-2);
    m1(k,1)=m1i(k,:)*ones(N,1)/N;
    m2i(k,:)=m2i(k,:) + (dy(:,t-1).*dy(:,t-1))'/(T-2);
    m2(k,1)=m2i(k,:)*ones(N,1)/N;
end

% 1-step estimator
os = optimset('LargeScale','off','MaxFunEvals',10^5,'MaxIter',10^5,'TolX',1e-8);
options = optimset('Display','off', 'TolX',1e-6);%
lq = -2;
uq = 2;

% compue starting value
a=m2(k,1); b=-m1(k,1); c=m0(k,1);
muhat0=(-b-(b^2-4*a*c)^0.5)/(2*a);
muhat0_alt=(-b+(b^2-4*a*c)^0.5)/(2*a);
muhat1=(-b)/(2*a);
D=b^2-4*a*c;
%dY=Data.dY;
Te=size(dy,2);
du1=dy(:,2:Te)-muhat0*dy(:,1:Te-1);
du2=dy(:,2:Te)-muhat0_alt*dy(:,1:Te-1);
ss1=sum(sum(du1.*du1))/N/(T-2);
ss2=sum(sum(du2.*du2))/N/(T-2);
if b^2-4*a*c>0
    if ss1<ss2
        stphi=muhat0;     
    else
        stphi=muhat0_alt;
    end
else
    stphi=muhat1;
end
if abs(stphi)>2
    stphi=0;
end
W1=Ws1.aah_aveT1*Ws1.aah_aveT1';
W=W1';
%str=evalc('[para,obj,ef, output]=fmincon(@objg_12step,stphi,[],[],[],[],lq,uq,[],options,m0,m1,m2, W)');
str=evalc('[para,obj,ef, output]=fminunc(@objg_12step,stphi,options,m0,m1,m2, W)');
phi_1step=para;

% 2-step estimator

S=zeros(K,K);
Sa=zeros(K,K); Sb=zeros(K,K); Sc=zeros(K,K); Sd=zeros(K,K); Se=zeros(K,K);
vm=zeros(K,1);
for i=1:N
   a=m0i(:,i)-phi_1step*m1i(:,i)+(phi_1step^2)*m2i(:,i);
   Si= a*a';
   vm=vm+a/N;
   S=S+Si;
   Sia=m0i(:,i)*m0i(:,i)';
   Sib=-m0i(:,i)*m1i(:,i)'-m1i(:,i)*m0i(:,i)';
   Sic=m1i(:,i)*m1i(:,i)'+m2i(:,i)*m0i(:,i)'+m0i(:,i)*m2i(:,i)';
   Sid=-m2i(:,i)*m1i(:,i)'-m1i(:,i)*m2i(:,i)';
   Sie=m2i(:,i)*m2i(:,i)';
   Sa=Sa+Sia;
   Sb=Sb+Sib;
   Sc=Sc+Sic;
   Sd=Sd+Sid;
   Se=Se+Sie;
end
S1=S/N;
Sa=Sa/N;
Sb=Sb/N;
Sc=Sc/N;
Sd=Sd/N;
Se=Se/N;

%Salt=Sa+phi_1step*Sb+(phi_1step^2)*Sc+(phi_1step^3)*Sd+(phi_1step^4)*Se;

W2=pinv(S1-vm*vm');
W=W2;
if abs(phi_1step)<1
    stphi=phi_1step;
else
    stphi=0;
end
%str=evalc('[para,obj,ef, output]=fmincon(@objg_12step,stphi,[],[],[],[],lq,uq,[],options,m0,m1,m2, W)');
str=evalc('[para,obj,ef, output]=fminunc(@objg_12step,stphi,options,m0,m1,m2, W)');
phi_2step=para;

% now asymptotic variance
D1=-m1+2*phi_1step*m2;
av_1step=pinv(D1'*W1*D1)*D1'*W1*S1*W1'*D1*pinv(D1'*W1*D1);
D2=-m1+2*phi_2step*m2;
av_2step=pinv(D2'*pinv(S1)*D2);


%% now report results
se=(av_2step/N)^0.5;
phihat=phi_2step;

return

%% declare functions

function obj=objg_12step(phi,m0,m1, m2, W)

% get params from psi
m=m0-phi*m1+phi*phi*m2;

obj=m'*W*m;

return

function obj=objg(phi,m0,m1,m2, Sa,Sb,Sc,Sd,Se)

% get params from psi
m=m0-phi*m1+phi*phi*m2;
S=Sa+phi*Sb+(phi^2)*Sc+(phi^3)*Sd+(phi^4)*Se;

obj=m'*pinv(S)*m;

return