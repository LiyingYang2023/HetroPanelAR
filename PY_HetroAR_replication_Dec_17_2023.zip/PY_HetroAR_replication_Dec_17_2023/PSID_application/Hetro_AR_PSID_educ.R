###### An application of heterogeneous panel AR(1) model of income processes using the PSID data
###### Pesaran and Yang (2023) "Hetro Panel AR"
rm(list=ls())
list.of.packages <- c("parallel","parallelly","openxlsx","R.matlab","abind")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
library(parallel) # mclapply
library(parallelly) # detect cores
library(openxlsx)
library(R.matlab)
library(abind)

### Codes of MSW estimator
################################################################################
### Function Epanechnikov Kernel
K = function(u){
  # 0.75 * (1-u^2) * (u > -1) * (u < 1)
  dnorm(u)
}

### Square Integrated Kernel
K22 = function(res){
  ulist = (-1*res):res / res
  sum( K(ulist)^2 / (2*res+1) * 2 )
}

### Function Row Product
RowProd = function(U){
  nc = ncol(U)
  ones = as.matrix(array(1,nc))
  u = log(U) %*% ones
  exp(u)
}

### Function Multivariate Normal Random Number Generator
rmultnorm = function(n, mu, vmat, tol=1e-07){
  p = ncol(vmat)
  if (length(mu)!=p)
    stop("mu vector is the wrong length")
  if (max(abs(vmat - t(vmat))) > tol)
    stop("vmat not symmetric")
  vs = svd(vmat)
  vsqrt = t(vs$v %*% (t(vs$u) * sqrt(vs$d)))
  ans = matrix(rnorm(n * p), nrow=n) %*% vsqrt
  ans = sweep(ans, 2, mu, "+")
  dimnames(ans) = list(NULL, dimnames(vmat)[[2]])
  return(ans)
}

### Function Multivariate Normal Density
dmultnorm = function(X,M,V){
  dim = ncol(X)
  d = exp( -0.5 * ( t(X-M)%*%solve(V)%*%(X-M) ) )
  d / ( (2*3.1415)^dim * abs(det(V)) )^.5
}

### Function Generate Random Parameters (Y1,Alpha,Beta,Sigma)
GenRandomPara = function(N,NumPara,M,S,r){
  V = S %*% t(S)
  R = array(r,dim=c(NumPara,NumPara)) + diag(1-r,NumPara,NumPara)
  V = V * R
  para = array(0,dim=c(N,NumPara))
  for(i in 1:N){
    para[i,1:NumPara] = rmultnorm(1, M, vmat=V)
  }
  para
}

### Function Generate Random Processes Y
GenRandomY = function(N,T,para,sigma){
  Y = array(0,dim=c(N,T))
  Y[1:N,1] = para[1:N,1]
  epsilon = rnorm(N*(T-1))
  epsilon = matrix(epsilon,N,T-1)
  for(t in 1:(T-1)){
    ### Below: Y_{t+1} = alpha + beta Y_t + sigma 
    Y[1:N,(t+1)] = para[1:N,2] + para[1:N,3] * Y[1:N,t] + sigma * epsilon[1:N,t]
  }
  Y
}

### Function Estimate Parameters for Time Series (Takes ROW Vector of Series Y)
GetParaHat = function(Y){
  Y = t( as.matrix(Y) )
  T = ncol(as.matrix(Y))
  Xmat = t( rbind(1, Y[1:(T-1)]) )
  Ymat = t( Y[2:T] )
  
  alpha_beta = solve(t(Xmat)%*%Xmat) %*% t(Xmat)%*%t(Ymat)
  sigma = (t(t(Ymat)-Xmat%*%alpha_beta) %*% (t(Ymat)-Xmat%*%alpha_beta) / T )^.5
  rbind(alpha_beta,log(sigma))
}

### Function Generate A Sample of (alpha hat, beta hat, log sigma hat)
GenSample = function(N,T,NumPara,M,S,r){
  para = GenRandomPara(N,NumPara,M,S,r)
  Y = GenRandomY(N,T,para)
  
  para_hat = array(0,dim=c(N,NumPara-1))
  for(i in 1:N){
    para_hat[i,1:(NumPara-1)] = t( GetParaHat(Y[i,1:T]) )
  }
  cbind(para[1:N,1] , para_hat)
}

### Function List of Parameters over Which to Integrate
GetList = function(NumPara, MinInt, MaxInt, ResInt){
  length = ResInt^NumPara
  list = array(0,dim=c(length,NumPara))
  idx_list = array(0,dim=c(length,NumPara))
  count = 1:(length) - 1
  for(i in 1:NumPara){
    idx_list[1:length,i] = count-floor(count/ResInt)*ResInt
    count = floor(count/ResInt)
  }
  idx_list = idx_list + 1
  # single_list = (1:ResInt - 0.5) * (MaxInt-MinInt)/ResInt + MinInt
  for(i in 1:NumPara){
    single_list = (1:ResInt - 0.5) * (MaxInt[i]-MinInt[i])/ResInt + MinInt[i]
    list[1:length,i] = single_list[idx_list[1:length,i]]
  }
  list
}

### Function Calculate Integral Operator (para_list - N matrix)
IntOperator = function(N,T,int_para_list,paneldata,sigma){
  list_length = nrow(int_para_list)
  alpha_list = int_para_list[1:list_length,1]
  beta_list = int_para_list[1:list_length,2]
  OperF = array(1,dim=c(list_length,N))
  
  for(i in 1:N){
    for(j in 2:T){
      OperF[1:list_length,i] = OperF[1:list_length,i] * dnorm( (paneldata[i,j] - alpha_list - beta_list * paneldata[i,j-1]) / sigma ) / sigma
    }
  }
  OperF
}

### Function Calculate Likelihood Integrand (para_list vector)
Integrand = function(int_para_list,MSR_hat,NumPara){
  # NumPara = 3
  list_length = nrow(int_para_list)
  M_hat = MSR_hat[1:NumPara]
  S_hat = MSR_hat[(NumPara+1):(2*NumPara)]
  R_hat = array(1,dim=c(NumPara,NumPara))
  V_hat = S_hat %*% t(S_hat)
  idx = 1
  for(i in 2:NumPara){
    for(j in 1:(i-1)){
      R_hat[i,j] = MSR_hat[2*NumPara+idx]
      R_hat[j,i] = R_hat[i,j]
      idx = idx + 1
    }
  }
  V_hat = V_hat * R_hat
  
  d_list = array(0,list_length)
  for(i in 1:list_length){
    d_list[i] = dmultnorm(as.matrix(int_para_list[i,1:NumPara]),M_hat,V_hat)
  }
  d_list
}

### Function Calculate Negative Log Likelihood
#NegativeLogLikelihood = function(MSR_hat,N,T,int_para_list,paneldata,Y1,y1,h,paneldata_w,paneldata_k,paneldata_ys){
NegativeLogLikelihood = function(MSR_hat,N,T,int_para_list,paneldata,Y1,y1,h){
  NumPara = ncol(int_para_list)
  Likelihood_Integrand = Integrand(int_para_list,MSR_hat,NumPara)
  ### Below is A Non_Weighted Likelihoods across i ###
  #OperF = IntOperator(N,T,int_para_list,paneldata,MSR_hat[6],paneldata_w,0,0,paneldata_k,0,0,paneldata_ys,0,0)
  OperF = IntOperator(N,T,int_para_list,paneldata,MSR_hat[6])
  OperF = t(OperF)
  Likelihood = OperF %*% as.matrix(Likelihood_Integrand)
  penalty = 100000000*sum((MSR_hat[3:4]<0)*(MSR_hat[3:4]^2)) + 0.001*sum(MSR_hat[3:4]^(-2)) + 100000000*(MSR_hat[5]^2>1)*((MSR_hat[5]-1)^2) + 1*MSR_hat[5]^2## PENALTY
  ### Below is A Weighted Sum of Log Likelihoods across i ###
  -1 * t(log(Likelihood)) %*% as.matrix( K((Y1- y1)/h) ) / N / h + penalty
}

### Function Calculate Agent-Wise Negative Log Likelihood
#AgentWiseNegativeLogLikelihood = function(MSR_hat,N,T,int_para_list,paneldata,Y1,y1,h,paneldata_w,paneldata_k,paneldata_ys){
AgentWiseNegativeLogLikelihood = function(MSR_hat,N,T,int_para_list,paneldata,Y1,y1,h){
  NumPara = ncol(int_para_list)
  Likelihood_Integrand = Integrand(int_para_list,MSR_hat,NumPara)
  ### Below is A Non_Weighted Likelihoods across i ###
  #OperF = IntOperator(N,T,int_para_list,paneldata,MSR_hat[6],paneldata_w,0,0,paneldata_k,0,0,paneldata_ys,0,0)
  OperF = IntOperator(N,T,int_para_list,paneldata,MSR_hat[6])
  OperF = t(OperF)
  Likelihood = OperF %*% as.matrix(Likelihood_Integrand)
  ### Below is to Avoid Infinite Log Likelihood
  # Likelihood = Likelihood + 0.0000000001
  ### Below is A Weighted Sum of Log Likelihoods across i ###
  -1 * (log(Likelihood)) * sqrt( as.matrix( K((Y1- y1)/h) ) / N / h )
}
################################################################################

### Compute MSE estimates of mu_phi = E(phi_i) and Var(phi_i)
################################################################################
sub = c("PSID2_educ_76_80.mat","PSID2_educ_81_85.mat","PSID2_educ_86_90.mat","PSID2_educ_91_95.mat","PSID2_educ_76_85.mat","PSID2_educ_81_90.mat","PSID2_educ_86_95.mat")
# 4 (sub-)panels for 7 periods
est_beta_m1 = matrix(,2*7,5) 
est_beta_var = matrix(,2*7,5)

for (ids in 1:7) {
  mat = readMat(sub[ids])
  panel0 = t(mat[["Y.ALL"]])
  panel1 = t(mat[["Y.HSD"]])
  panel2 = t(mat[["Y.HSG"]])
  panel3 = t(mat[["Y.CLG"]])
  
  for (p in c(0,1,2,3)) {
    name = paste("panel",p,sep="")
    paneldata = get(name)
    
    ####################################################################
    N = nrow(paneldata)
    T = ncol(paneldata)
    
    k=1
    NumPara = 3
    ResInt = 10
    h = 1.06 * sd(paneldata[,1]) * length(paneldata[,1])^(-1/5)
    
    sav  = cbind(2)#0.5,1,2)   #Alpha
    sbv  = cbind(0.5)#0.1,0.25,0.5) #Beta
    mbv  = cbind(0.4)#,0.5)   #Beta
    sab = expand.grid(sav,sbv,mbv) 
    my1 = 10    #Y_1
    ma  = 5  #Alpha
    mb = sab[1,3]
    M = c(my1,ma,mb)
    sy1 = 1   #Y_1
    sa = sab[1,1]
    sb = sab[1,2]
    S = c(sy1,sa,sb)
    corr   = 0.5   #Correlation Coefficient
    sigma = 0.5
    
    MinInt = c( ma-sa, mb-sb)    # para_means - 2* para_stdvs
    MaxInt = c( ma+sa, mb+sb)    # para_means + 2* para_stdvs
    
    int_para_list = GetList(NumPara-1, MinInt, MaxInt, ResInt)
    
    Y1= paneldata[1:N,1]
    y1list = Y1
    numy1list = length(y1list)
    Nkernel = nrow(paneldata)
    Tkernel = ncol(paneldata)
    estimate_list = array(0, dim=c(nrow(as.matrix(y1list)),6))
    stderr_list = array(0, dim=c(nrow(as.matrix(y1list)),6))
    idx = 1
    
    localest = function(y1){
      ### Initial Values of Estimates (conditional on Y_1 = y1) #####################
      M_hat = c(ma,mb) # NumPara=3 Conditional on Y_1=y1
      S_hat = c(sa,sb) # NumPara=3 Conditional on Y_1=y1
      R_hat = c(-corr) # NumPara*(NumPara)/2 = 1
      Sigma_hat = c(sigma)
      MSR_hat = rbind(as.matrix(M_hat),as.matrix(S_hat),as.matrix(R_hat),as.matrix(Sigma_hat))
      
      #results <- nlm(NegativeLogLikelihood,MSR_hat,N,T,int_para_list,paneldata,Y1,y1,h,paneldata_w,paneldata_k,paneldata_ys,hessian=TRUE) #,iterlim=MaxGaussNewtonIterations)
      results <- nlm(NegativeLogLikelihood,MSR_hat,Nkernel,Tkernel,int_para_list,paneldata,Y1,y1,h,hessian=TRUE) #,iterlim=MaxGaussNewtonIterations)
      est = results$estimate
      return(est)
    }
    
    estimate_list = t(sapply(Y1, localest))
    
    hatma = matrix(, ncol= dim(sab)[1], nrow=2)
    hatmb = matrix(, ncol= dim(sab)[1], nrow=2)
    hatva = matrix(, ncol= dim(sab)[1], nrow=2)
    hatvb = matrix(, ncol= dim(sab)[1], nrow=2)
    
    estimate_list = cbind(estimate_list,estimate_list[,1:2]^2)
    estimate_list = cbind(estimate_list,estimate_list[,3:4]^2)
    # COMPUTE THE MEAN PARAMETER ESTIAMTES #
    mean_para = colSums(estimate_list) / numy1list
    dev_para = estimate_list - t(array(mean_para,dim=c(10,numy1list)))
    # COMPUTE THE VARIANCE COVARIANCE MATRIX OF PARAMETER ESTIAMTES #
    var_para = t(dev_para)%*%dev_para / numy1list
    
    # STD ERR OF MEAN(ALPHA) #
    stderr_mean_alpha = var_para[1,1]^.5
    # STD ERR OF MEAN(BETA) #
    stderr_mean_beta = var_para[2,2]^.5
    
    # VARIANCE MATRICES FOR VARIOUS MOMENTS OF ALPHA AND BETA #
    S_alpha = array(0,dim=c(3,3))
    S_beta = array(0,dim=c(3,3))
    S_alpha[1,1] = cov(estimate_list[,3],estimate_list[,3])
    S_alpha[1,2] = cov(estimate_list[,3],estimate_list[,1]^2)
    S_alpha[1,3] = cov(estimate_list[,3],estimate_list[,1])
    S_alpha[2,1] = cov(estimate_list[,1]^2,estimate_list[,3])
    S_alpha[2,2] = cov(estimate_list[,1]^2,estimate_list[,1]^2)
    S_alpha[2,3] = cov(estimate_list[,1]^2,estimate_list[,1])
    S_alpha[3,1] = cov(estimate_list[,1],estimate_list[,3])
    S_alpha[3,2] = cov(estimate_list[,1],estimate_list[,1]^2)
    S_alpha[3,3] = cov(estimate_list[,1],estimate_list[,1])
    S_beta[1,1] = cov(estimate_list[,4],estimate_list[,4])
    S_beta[1,2] = cov(estimate_list[,4],estimate_list[,2]^2)
    S_beta[1,3] = cov(estimate_list[,4],estimate_list[,2])
    S_beta[2,1] = cov(estimate_list[,2]^2,estimate_list[,4])
    S_beta[2,2] = cov(estimate_list[,2]^2,estimate_list[,2]^2)
    S_beta[2,3] = cov(estimate_list[,2]^2,estimate_list[,2])
    S_beta[3,1] = cov(estimate_list[,2],estimate_list[,4])
    S_beta[3,2] = cov(estimate_list[,2],estimate_list[,2]^2)
    S_beta[3,3] = cov(estimate_list[,2],estimate_list[,2])
    stderr_sqrtvar_alpha = sqrt( c(1,1,2) %*% S_alpha %*% c(1,1,2) / (mean_para[9]+mean_para[7]-mean_para[1]^2) / 4 / N )
    stderr_sqrtvar_beta = sqrt( c(1,1,2) %*% S_beta %*% c(1,1,2) / (mean_para[10]+mean_para[8]-mean_para[2]^2) / 4 / N )
    
    # DISPLAY OUTPUT OF MEAN AND VARIANCE #
    hatma[,k] = cbind(mean_para[1], stderr_mean_alpha)
    hatva[,k] = cbind((mean_para[9]+mean_para[7]-mean_para[1]^2), stderr_sqrtvar_alpha*2*(mean_para[9]+mean_para[7]-mean_para[1]^2)^.5)
    hatmb[,k] = cbind(mean_para[2], stderr_mean_beta)
    hatvb[,k] = cbind((mean_para[10]+mean_para[8]-mean_para[2]^2), stderr_sqrtvar_beta*2*(mean_para[10]+mean_para[8]-mean_para[2]^2)^.5)
    
    ####################################################################
    est_beta_m1[(1+(ids-1)*2):(2+(ids-1)*2),(p+1+1*(p>0))] = hatmb
    est_beta_var[(1+(ids-1)*2):(2+(ids-1)*2),(p+1+1*(p>0))] = hatvb
    nam = paste("localest_",ids,"_p", p, sep = ""); assign(nam, estimate_list)
    nam = paste("mean_para_",ids,"_p",p, sep = ""); assign(nam, mean_para)  
    nam = paste("S_alpha_",ids,"_p",p,sep = ""); assign(nam, S_alpha) 
    nam = paste("S_beta_",ids,"_p",p,sep = ""); assign(nam, S_beta)  
    nam = paste("beta",ids,"_p",p,sep = "");
    rm(nam); rm(mean_para,var_para,S_alpha,S_beta,stderr_mean_alpha,stderr_mean_beta,estimate_list)
    rm(mb,sa,sb)
  }
  nam = paste("est_beta_m1_",ids,sep = ""); assign(nam,est_beta_m1)
  nam = paste("est_beta_var_",ids,sep = ""); assign(nam,est_beta_var)
}
################################################################################

### Tabulate estimation results: Tables 2, S.33, S.34, S.35, S.36, and S.37
##############################################################################
# Create a style for center-aligning the numbers
center_style <- createStyle(halign = "center")
right <- createStyle(halign = "right")
left <- createStyle(halign = "left")
bbs <- createStyle(border = "bottom",borderStyle="thin")
lbs <- createStyle(border = "bottom",borderStyle="double")
tbs <- createStyle(border = "top",borderStyle="double")
wrap_text_style <- createStyle(wrapText = TRUE)

wb <- createWorkbook()
list = c('Table 2','Table S.33','Table S.34','Table S.35','Table S.36','Table S.37')
df = readMat('PSID2_educ.mat') # Estimation results of FDAC and HomoGMM estimators

# Tabulate estimation results of E(phi_i)
for (id in c(1,2,3)) {
  sn = list[id]
  addWorksheet(wb, sn)
  if (id==1) {
    writeData(wb, sn, x = "Table 2: Estimates of mean persistence (phi_0 = E(phi_i)) of log real earnings in a panel AR(1) model with a common linear trend using PSID data over 1991-1995 and 1986-1995", startCol = 1, startRow = 1, colNames = FALSE)
    pid = c(4,7); h1 = c("","1991-1995, T=5",rep("",5),"1986-1995, T=10",rep("",4))
  }
  if (id==2) {
    writeData(wb, sn, x = "Table S.33: Estimates of mean persistence (phi_0 = E(phi_i)) of log real earnings in a panel AR(1) model with a common linear trend using the PSID data over the sub-periods 1976-1980, 1981-1985 and 1986-1990", startCol = 1, startRow = 1, colNames = FALSE)
    pid = c(1,2,3); h1 = c("","1976-1980, T=5",rep("",5),"1981-1985, T=5",rep("",5),"1986-1990, T=5",rep("",4))
  }
  if (id==3) {
    writeData(wb, sn, x = "Table S.34: Estimates of mean persistence (phi_0 = E(phi_i)) of log real earnings in a panel AR(1) model with a common linear trend using the PSID data over the sub-periods 1976-1985 and 1981-1990", startCol = 1, startRow = 1, colNames = FALSE)
    pid = c(5,6); h1 = c("","1976-1985, T=10",rep("",5),"1981-1990, T=10",rep("",4))
  }
  
  tab = matrix(,16,length(pid)*(5+1)-1)
  tab2 = matrix(,16,length(pid)*(5+1)-1)
  for (j in 1:length(pid)) {
    s = pid[j]
    tab[,(1+(j-1)*6):(5+(j-1)*6)] = df$m1[,,s];
    tab[12:13,(1+(j-1)*6):(5+(j-1)*6)] = est_beta_m1[(1+(s-1)*2):(2+(s-1)*2),];
  }
  tab2[which(is.na(tab)==F)] = sprintf("%.3f", tab[which(is.na(tab)==F)] )
  for (i in c(3,5,7,11,13)) { # Format of S.E.
    for (j in 1:ncol(tab2)) {
      if (is.na(tab2[i,j])==F) {
        tab2[i,j] = paste0("(",tab2[i,j],")",sep="")
      }
    }
  }
  for (i in c(16)) { # Format of n
    for (j in 1:ncol(tab2)) {
      if (is.na(tab2[i,j])==F) {
        tab2[i,j] = sprintf("%.0f",tab[i,j])
      }
    }
  }
  if (length(pid)==2) {
    tab2[1,] = rep("",11)  
    tab2[8,] = rep("",11)
    tab2[9,] = rep("",11)  
    tab2[14,] = rep("",11)  
  } else {
    tab2[1,] = rep("",17)  
    tab2[8,] = rep("",17)
    tab2[9,] = rep("",17)  
    tab2[14,] = rep("",17)  
    tab2[,14] = rep("",16)   
  }
  tab2[,2] = rep("",16)  
  tab2[,8] = rep("",16)    
  c1 = c("Homogeneous slopes","AAH","","AB","","BB","","","Heterogeneous slopes","FDAC","","MSW","","","Common linear trend","n")
  tab3 = cbind(c1,tab2)
  h2 = rep(c("","All","","Category by education","",""),2)
  h3 = rep(c("","categories","","HSD","HSG","CLG"),2)
  if (length(pid)>2) {
    h2 = rep(c("","All","","Category by education","",""),3)
    h3 = rep(c("","categories","","HSD","HSG","CLG"),3)
  }
  h = rbind(h1,h2,h3,tab3)
  
  rownames(h) <- NULL
  colnames(h) <- NULL
  writeData(wb,sn, x = h, startCol = 1, startRow = 2,colNames = FALSE, rowNames = FALSE)
  mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 1)
  mergeCells(wb, sheet = sn, cols = 2:6, rows = 2)
  mergeCells(wb, sheet = sn, cols = 8:12, rows = 2)
  mergeCells(wb, sheet = sn, cols = 4:6, rows = 3)
  mergeCells(wb, sheet = sn, cols = 10:12, rows = 3)
  if (length(pid)>2) {
    mergeCells(wb, sheet = sn, cols = 14:18, rows = 2)    
    mergeCells(wb, sheet = sn, cols = 16:18, rows = 3)    
  }
  
  addStyle(wb,sn,style = center_style, rows = 6:(nrow(h)+1), cols = 2:(ncol(h)), gridExpand = TRUE)
  addStyle(wb,sn,style = center_style, rows = 2:4, cols = 1:(ncol(h)), gridExpand = TRUE)
  addStyle(wb,sn,style = center_style, rows = 2:(nrow(h)+1), cols = 1, gridExpand = TRUE)  
  addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
  addStyle(wb,sn,style = bbs, rows = 2,cols = c(2:6,8:12), gridExpand = TRUE,stack=TRUE)
  addStyle(wb,sn,style = bbs, rows = 3,cols = c(4:6,10:12), gridExpand = TRUE,stack=TRUE)
  if (length(pid)>2) {
    addStyle(wb,sn,style = bbs, rows = 2,cols = c(14:18), gridExpand = TRUE,stack=TRUE)  
    addStyle(wb,sn,style = bbs, rows = 3,cols = c(16:18), gridExpand = TRUE,stack=TRUE)
  }
  addStyle(wb,sn,style = bbs, rows = c(4,19),cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
  addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
  addStyle(wb,sn,style = lbs, rows = (nrow(h)+1),cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)  
  
  rm(tab,tab2,tab3,h)
}

# Tabulate estimation results of Var(phi_i)
for (id in c(4,5,6)) {
  sn = list[id]
  addWorksheet(wb, sn)
  if (id==4) {
    writeData(wb, sn, x = "Table S.35: Estimates of variance of heterogeneous persistence (Var(phi_i)) of log real earnings in a panel AR(1) model with a common linear trend using the PSID data over the sub-periods 1991-1995 and 1986-1995", startCol = 1, startRow = 1, colNames = FALSE)
    pid = c(4,7); h1 = c("","1991-1995, T=5",rep("",5),"1986-1995, T=10",rep("",4))
  }
  if (id==5) {
    writeData(wb, sn, x = "Table S.36: Estimates of variance of heterogeneous persistence (Var(phi_i)) of log real earnings in a panel AR(1) model with a common linear trend using the PSID data over the sub-periods 1976-1985 and 1981-1990", startCol = 1, startRow = 1, colNames = FALSE)
    pid = c(5,6); h1 = c("","1976-1985, T=10",rep("",5),"1981-1990, T=10",rep("",4))
  }
  if (id==6) {
    writeData(wb, sn, x = "Table S.37: Estimates of variance of heterogeneous persistence (Var(phi_i)) of log real earnings in a panel AR(1) model with a common linear trend using the PSID data over the sub-periods 1976-1980, 1981-1985, and 1986-1990", startCol = 1, startRow = 1, colNames = FALSE)
    pid = c(1,2,3); h1 = c("","1976-1980, T=5",rep("",5),"1981-1985, T=5",rep("",5),"1986-1990, T=5",rep("",4))
  }
  
  tab = matrix(,5,length(pid)*(5+1)-1)
  tab2 = matrix(,5,length(pid)*(5+1)-1)
  for (j in 1:length(pid)) {
    s = pid[j]
    tab[,(1+(j-1)*6):(5+(j-1)*6)] = df$var[,,s];
    tab[3:4,(1+(j-1)*6):(5+(j-1)*6)] = est_beta_var[(1+(s-1)*2):(2+(s-1)*2),];
  }
  tab2[which(is.na(tab)==F)] = sprintf("%.3f", tab[which(is.na(tab)==F)] )
  for (i in c(2,4)) { # Format of S.E.
    for (j in 1:ncol(tab2)) {
      if (is.na(tab2[i,j])==F) {
        tab2[i,j] = paste0("(",tab2[i,j],")",sep="")
      }
    }
  }
  for (i in c(5)) { # Format of n
    for (j in 1:ncol(tab2)) {
      if (is.na(tab2[i,j])==F) {
        tab2[i,j] = sprintf("%.0f",tab[i,j])
      }
    }
  }
  if (length(pid)>2) {
    tab2[,14] = rep("",5)   
  }
  tab2[,2] = rep("",5)  
  tab2[,8] = rep("",5)   
  c1 = c("FDAC","","MSW","","n")
  tab3 = cbind(c1,tab2)
  if (length(pid)==2) {
    h2 = rep(c("","All","","Category by education","",""),2)
    h3 = rep(c("","categories","","HSD","HSG","CLG"),2)
   } else {
    h2 = rep(c("","All","","Category by education","",""),3)
    h3 = rep(c("","categories","","HSD","HSG","CLG"),3)
  }
  h = rbind(h1,h2,h3,tab3)
  rownames(h) <- NULL
  colnames(h) <- NULL
  writeData(wb,sn, x = h, startCol = 1, startRow = 2,colNames = FALSE, rowNames = FALSE)
  mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 1)
  mergeCells(wb, sheet = sn, cols = 2:6, rows = 2)
  mergeCells(wb, sheet = sn, cols = 8:12, rows = 2)
  mergeCells(wb, sheet = sn, cols = 4:6, rows = 3)
  mergeCells(wb, sheet = sn, cols = 10:12, rows = 3)
  if (length(pid)>2) {
    mergeCells(wb, sheet = sn, cols = 14:18, rows = 2)    
    mergeCells(wb, sheet = sn, cols = 16:18, rows = 3)    
  }
  
  addStyle(wb,sn,style = center_style, rows = 6:(nrow(h)+1), cols = 2:(ncol(h)), gridExpand = TRUE)
  addStyle(wb,sn,style = center_style, rows = 2:5, cols = 1:(ncol(h)), gridExpand = TRUE)
  addStyle(wb,sn,style = center_style, rows = 2:(nrow(h)+1), cols = 1, gridExpand = TRUE)  
  addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
  addStyle(wb,sn,style = bbs, rows = 2,cols = c(2:6,8:12), gridExpand = TRUE,stack=TRUE)
  addStyle(wb,sn,style = bbs, rows = 3,cols = c(4:6,10:12), gridExpand = TRUE,stack=TRUE)
  if (length(pid)>2) {
    addStyle(wb,sn,style = bbs, rows = 2,cols = c(14:18), gridExpand = TRUE,stack=TRUE)  
    addStyle(wb,sn,style = bbs, rows = 3,cols = c(16:18), gridExpand = TRUE,stack=TRUE)
  }
  addStyle(wb,sn,style = bbs, rows = c(4,8),cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
  addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
  addStyle(wb,sn,style = lbs, rows = (nrow(h)+1),cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
  
  rm(tab,tab2,tab3,h)
}

saveWorkbook(wb, file = "HetroAR_PSID_educ_results.xlsx",overwrite = TRUE)
cat("The MC results have been written to the excel file HetroAR_PSID_educ_results.xlsx.")
##############################################################################
