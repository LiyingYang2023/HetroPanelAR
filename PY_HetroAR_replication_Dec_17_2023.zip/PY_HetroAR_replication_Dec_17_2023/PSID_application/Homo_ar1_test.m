function [H,pv] = Homo_ar1_test(Y,ar1_est)
%% input data
%Y is (T+1) x n matrix
%ar1_est = resultsAAH(1);
%Y = Y_ALL;
dy = Y(1:end-1,:)-Y(2:end,:);
[T,n] = size(dy);

%% estimators of auto-correlations of first-differenced process
pmm = [1*(T-2>0),2*(T-3>0),3*(T-3>0)];
pm = max(pmm);

% (pm+2)*n matrix: average over T-h-1 for each i
dydyi1 = zeros(pm+2,n); % sample moments h=0,1,...,lagdyy

for i =  1:n
    for ll = 0:(pm+1)
      dydyi1((ll+1),i) = mean(dy((ll+1):T,i).*dy(1:(T-ll),i)); % average over T-h 
    end   
end

% sample moments of dydy(h) for MM estimators
if pmm(1)==1 % 
% sample moments average across i
  dydy1 = mean(dydyi1,2); % h=0,1,2,...,lagdyy
end


%% calculate test statistics and two-sided p-value
if pmm(1)==1 
    m = dydy1(2)/dydy1(1) + .5*(1 - ar1_est);
    av = mean((.5*(1 - ar1_est).*dydyi1(1,:)-dydyi1(2,:)).^2);
    H = m/sqrt(av/n);
    pv = 2*(1-normcdf(abs(H),0,1));
end 

%if pmm(2)==2 
%m2 =  dydy1(3)/dydy1(1) + .5*(ar1_est^1)*(1 - ar1_est);
%av2 = mean((.5*(ar1_est^1)*(1 - ar1_est).*dydyi1(1,:)-dydyi1(3,:)).^2);
%H = m2/sqrt(av2/n);
%pv = 2*(1-normcdf(abs(H),0,1));
%end

return % function


