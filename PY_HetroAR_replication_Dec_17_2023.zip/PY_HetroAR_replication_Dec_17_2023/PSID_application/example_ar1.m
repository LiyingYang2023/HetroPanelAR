% import data
clear
PSID2 = importdata('PSID2.csv');
PCED2 = importdata('PCED2.csv');
 
N0=3113;  % the maximum number of cross-sectional units
T0=30;    % time length
K0=11;    % number of variables
 
% select the starting and final year (1(=1967) <= t <= 30(=1996))
T_list = [5 5 5 5 10 10 10];  % length of selected period
t0_list = [1976 1981 1986 1991 1976 1981 1986];


for id=1:7
t0 = t0_list(id);
T = T_list(id);
t_start = 1+t0-1967; 
t_end = t_start+T-1; 

data0 = zeros(K0,T0,N0);
 
for i=1:N0
    data0(:,:,i) = PSID2(K0*(i-1)+1:K0*i,:);
end
 
for i=1:N0
    for t=1:T0
        if data0(4,t,i) == 0; data0(4,t,i) = NaN;  end
    end
end
 
data1 = data0(:,t_start:t_end,:);
data2 = zeros(T,N0,K0);
j_ALL=1;
for i=1:N0
   if isnan(data1(:,:,i)) == zeros(K0,T);   data2(:,j_ALL,:)=reshape(data1(:,:,i)',T,1,K0); j_ALL=j_ALL+1; end 
end
N_ALL = j_ALL-1;
data_ALL = data2(:,1:N_ALL,:);
 
data_HSD = zeros(T,N_ALL,K0);
data_HSG = zeros(T,N_ALL,K0);
data_CLG = zeros(T,N_ALL,K0);
j_HSD=1;
j_HSG=1;
j_CLG=1;
for i=1:N_ALL
   if data_ALL(1,i,2) < 12;   data_HSD(:,j_HSD,:)=data_ALL(:,i,:); j_HSD=j_HSD+1; end 
   if data_ALL(1,i,2) >= 12 && data_ALL(1,i,2) <= 15;   data_HSG(:,j_HSG,:)=data_ALL(:,i,:); j_HSG=j_HSG+1; end 
   if data_ALL(1,i,2) > 15;   data_CLG(:,j_CLG,:)=data_ALL(:,i,:); j_CLG=j_CLG+1; end 
end
N_HSD = j_HSD - 1;
N_HSG = j_HSG - 1;
N_CLG = j_CLG - 1;
data_HSD = data_HSD(:,1:N_HSD,:);
data_HSG = data_HSG(:,1:N_HSG,:);
data_CLG = data_CLG(:,1:N_CLG,:);

Y_ALL = log(data_ALL(:,:,8)./( (PCED2(t_start:t_end)*ones(1,N_ALL)).*(data_ALL(:,:,5))) );
Y_HSD = log(data_HSD(:,:,8)./( (PCED2(t_start:t_end)*ones(1,N_HSD)).*(data_HSD(:,:,5))) );
Y_HSG = log(data_HSG(:,:,8)./( (PCED2(t_start:t_end)*ones(1,N_HSG)).*(data_HSG(:,:,5))) );
Y_CLG = log(data_CLG(:,:,8)./( (PCED2(t_start:t_end)*ones(1,N_CLG)).*(data_CLG(:,:,5))) );

% de-trend
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dy_ALL = Y_ALL(2:end,:)-Y_ALL(1:end-1,:);
g_ALL = sum(dy_ALL,"all")/N_ALL/(T-1);
gt_ALL = zeros(T,N_ALL);
for j=1:T
    gt_ALL(j,:)= repmat(g_ALL*j,1,N_ALL);
end
Y_ALL = Y_ALL - gt_ALL;

dy_HSD = Y_HSD(2:end,:)-Y_HSD(1:end-1,:);
g_HSD = sum(dy_HSD,"all")/N_HSD/(T-1);
gt_HSD = zeros(T,N_HSD);
for j=1:T
    gt_HSD(j,:)= repmat(g_HSD*j,1,N_HSD);
end
Y_HSD = Y_HSD - gt_HSD;

dy_HSG = Y_HSG(2:end,:)-Y_HSG(1:end-1,:);
g_HSG = sum(dy_HSG,"all")/N_HSG/(T-1);
gt_HSG = zeros(T,N_HSG);
for j=1:T
    gt_HSG(j,:)= repmat(g_HSG*j,1,N_HSG);
end
Y_HSG = Y_HSG - gt_HSG;

dy_CLG = Y_CLG(2:end,:)-Y_CLG(1:end-1,:);
g_CLG = sum(dy_CLG,"all")/N_CLG/(T-1);
gt_CLG = zeros(T,N_CLG);
for j=1:T
    gt_CLG(j,:)= repmat(g_CLG*j,1,N_CLG);
end
Y_CLG = Y_CLG - gt_CLG;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

K=0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% estimate using data_ALL 
[transML, GMM_DIF1_1step, GMM_DIF1_2step, GMM_DIF1_CUE, GMM_DIF2_1step, GMM_DIF2_2step, GMM_DIF2_CUE, GMM_SYS1_1step, GMM_SYS1_2step, GMM_SYS1_CUE,   GMM_SYS2_1step, GMM_SYS2_2step, GMM_SYS2_CUE] = ML_GMM_estimators_ar1( Y_ALL );

Ytrans=Y_ALL'; %n x T
[phihat, se, KAH]=AAHestim(Ytrans);
resultsAAH=[phihat;se;KAH];

% GMM estimators of moments of heterogeneous AR(1) coefficients
[thetahat,se_GMM_hp,var_GMM_hp,sev] = GMM_hp_ar1(Y_ALL);
results_MM_hp=[thetahat(1);se_GMM_hp(1);NaN];
results_MMb_hp=[thetahat(2);se_GMM_hp(2);NaN];
results_GMM_hp=[thetahat(3);se_GMM_hp(3);NaN];
results_GMMb_hp=[thetahat(4);se_GMM_hp(4);NaN];
% estimators of 2nd moment identified when T>3
[results_m2(1:2,2:5)] = [thetahat(5:8);se_GMM_hp(5:8)];
% estimators of variance
[results_var(1:2,1:4)] = [var_GMM_hp;sev];
% estimators of 3rd moment dentified when T>4
[results_m3(1:2,1:3)] = [thetahat(9:11);se_GMM_hp(9:11)]; 

resuls_transML = reshape(squeeze(transML)',(K+1)*3,1);
resuls_GMM_DIF1_1step = reshape(squeeze(GMM_DIF1_1step)',(K+1)*3,1);
resuls_GMM_DIF1_2step = reshape(squeeze(GMM_DIF1_2step)',(K+1)*3,1);
resuls_GMM_DIF1_CUE = reshape(squeeze(GMM_DIF1_CUE)',(K+1)*3,1);
resuls_GMM_DIF2_1step = reshape(squeeze(GMM_DIF2_1step)',(K+1)*3,1);
resuls_GMM_DIF2_2step = reshape(squeeze(GMM_DIF2_2step)',(K+1)*3,1);
resuls_GMM_DIF2_CUE = reshape(squeeze(GMM_DIF2_CUE)',(K+1)*3,1);
resuls_GMM_SYS1_1step = reshape(squeeze(GMM_SYS1_1step)',(K+1)*3,1);
resuls_GMM_SYS1_2step = reshape(squeeze(GMM_SYS1_2step)',(K+1)*3,1);
resuls_GMM_SYS1_CUE = reshape(squeeze(GMM_SYS1_CUE)',(K+1)*3,1);
resuls_GMM_SYS2_1step = reshape(squeeze(GMM_SYS2_1step)',(K+1)*3,1);
resuls_GMM_SYS2_2step = reshape(squeeze(GMM_SYS2_2step)',(K+1)*3,1);
resuls_GMM_SYS2_CUE = reshape(squeeze(GMM_SYS2_CUE)',(K+1)*3,1);

output_ALL = [results_MM_hp resultsAAH resuls_GMM_DIF1_2step resuls_GMM_SYS1_2step resuls_transML];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  estimate using data_HSD 
[transML, GMM_DIF1_1step, GMM_DIF1_2step, GMM_DIF1_CUE,   GMM_DIF2_1step, GMM_DIF2_2step, GMM_DIF2_CUE,   GMM_SYS1_1step, GMM_SYS1_2step, GMM_SYS1_CUE,   GMM_SYS2_1step, GMM_SYS2_2step, GMM_SYS2_CUE] = ML_GMM_estimators_ar1( Y_HSD );

[phihat, se,KAH]=AAHestim(Y_HSD');
resultsAAH=[phihat;se;KAH];

% GMM estimators of moments of heterogeneous AR(1) coefficients
[thetahat, se_GMM_hp, var_GMM_hp,sev] = GMM_hp_ar1(Y_HSD);
results_MM_hp=[thetahat(1);se_GMM_hp(1);NaN];
[results_var(5:6,1:4)] = [var_GMM_hp;sev];

resuls_transML = reshape(squeeze(transML)',(K+1)*3,1);
resuls_GMM_DIF1_1step = reshape(squeeze(GMM_DIF1_1step)',(K+1)*3,1);
resuls_GMM_DIF1_2step = reshape(squeeze(GMM_DIF1_2step)',(K+1)*3,1);
resuls_GMM_DIF1_CUE = reshape(squeeze(GMM_DIF1_CUE)',(K+1)*3,1);
resuls_GMM_DIF2_1step = reshape(squeeze(GMM_DIF2_1step)',(K+1)*3,1);
resuls_GMM_DIF2_2step = reshape(squeeze(GMM_DIF2_2step)',(K+1)*3,1);
resuls_GMM_DIF2_CUE = reshape(squeeze(GMM_DIF2_CUE)',(K+1)*3,1);
resuls_GMM_SYS1_1step = reshape(squeeze(GMM_SYS1_1step)',(K+1)*3,1);
resuls_GMM_SYS1_2step = reshape(squeeze(GMM_SYS1_2step)',(K+1)*3,1);
resuls_GMM_SYS1_CUE = reshape(squeeze(GMM_SYS1_CUE)',(K+1)*3,1);
resuls_GMM_SYS2_1step = reshape(squeeze(GMM_SYS2_1step)',(K+1)*3,1);
resuls_GMM_SYS2_2step = reshape(squeeze(GMM_SYS2_2step)',(K+1)*3,1);
resuls_GMM_SYS2_CUE = reshape(squeeze(GMM_SYS2_CUE)',(K+1)*3,1);


output_HSD = [results_MM_hp resultsAAH resuls_GMM_DIF1_2step resuls_GMM_SYS1_2step resuls_transML];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  estimate using data_HSG 
[transML, GMM_DIF1_1step, GMM_DIF1_2step, GMM_DIF1_CUE,   GMM_DIF2_1step, GMM_DIF2_2step, GMM_DIF2_CUE,   GMM_SYS1_1step, GMM_SYS1_2step, GMM_SYS1_CUE,   GMM_SYS2_1step, GMM_SYS2_2step, GMM_SYS2_CUE] = ML_GMM_estimators_ar1( Y_HSG );

[phihat, se,KAH]=AAHestim(Y_HSG');
resultsAAH=[phihat;se;KAH];

% GMM estimators of moments of heterogeneous AR(1) coefficients
[thetahat, se_GMM_hp, var_GMM_hp,sev] = GMM_hp_ar1(Y_HSG);
results_MM_hp=[thetahat(1);se_GMM_hp(1);NaN];
[results_var(9:10,1:4)] = [var_GMM_hp;sev];

resuls_transML = reshape(squeeze(transML)',(K+1)*3,1);
resuls_GMM_DIF1_1step = reshape(squeeze(GMM_DIF1_1step)',(K+1)*3,1);
resuls_GMM_DIF1_2step = reshape(squeeze(GMM_DIF1_2step)',(K+1)*3,1);
resuls_GMM_DIF1_CUE = reshape(squeeze(GMM_DIF1_CUE)',(K+1)*3,1);
resuls_GMM_DIF2_1step = reshape(squeeze(GMM_DIF2_1step)',(K+1)*3,1);
resuls_GMM_DIF2_2step = reshape(squeeze(GMM_DIF2_2step)',(K+1)*3,1);
resuls_GMM_DIF2_CUE = reshape(squeeze(GMM_DIF2_CUE)',(K+1)*3,1);
resuls_GMM_SYS1_1step = reshape(squeeze(GMM_SYS1_1step)',(K+1)*3,1);
resuls_GMM_SYS1_2step = reshape(squeeze(GMM_SYS1_2step)',(K+1)*3,1);
resuls_GMM_SYS1_CUE = reshape(squeeze(GMM_SYS1_CUE)',(K+1)*3,1);
resuls_GMM_SYS2_1step = reshape(squeeze(GMM_SYS2_1step)',(K+1)*3,1);
resuls_GMM_SYS2_2step = reshape(squeeze(GMM_SYS2_2step)',(K+1)*3,1);
resuls_GMM_SYS2_CUE = reshape(squeeze(GMM_SYS2_CUE)',(K+1)*3,1);


output_HSG = [results_MM_hp resultsAAH resuls_GMM_DIF1_2step resuls_GMM_SYS1_2step resuls_transML];



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  estimate using data_CLG 
[transML, GMM_DIF1_1step, GMM_DIF1_2step, GMM_DIF1_CUE,   GMM_DIF2_1step, GMM_DIF2_2step, GMM_DIF2_CUE,   GMM_SYS1_1step, GMM_SYS1_2step, GMM_SYS1_CUE,   GMM_SYS2_1step, GMM_SYS2_2step, GMM_SYS2_CUE] = ML_GMM_estimators_ar1( Y_CLG );

[phihat, se,KAH]=AAHestim(Y_CLG');
resultsAAH=[phihat;se;KAH];

% GMM estimators of moments of heterogeneous AR(1) coefficients
[thetahat, se_GMM_hp, var_GMM_hp,sev] = GMM_hp_ar1(Y_CLG);
results_MM_hp=[thetahat(1);se_GMM_hp(1);NaN];
[results_var(13:14,1:4)] = [var_GMM_hp;sev];


resuls_transML = reshape(squeeze(transML)',(K+1)*3,1);
resuls_GMM_DIF1_1step = reshape(squeeze(GMM_DIF1_1step)',(K+1)*3,1);
resuls_GMM_DIF1_2step = reshape(squeeze(GMM_DIF1_2step)',(K+1)*3,1);
resuls_GMM_DIF1_CUE = reshape(squeeze(GMM_DIF1_CUE)',(K+1)*3,1);
resuls_GMM_DIF2_1step = reshape(squeeze(GMM_DIF2_1step)',(K+1)*3,1);
resuls_GMM_DIF2_2step = reshape(squeeze(GMM_DIF2_2step)',(K+1)*3,1);
resuls_GMM_DIF2_CUE = reshape(squeeze(GMM_DIF2_CUE)',(K+1)*3,1);
resuls_GMM_SYS1_1step = reshape(squeeze(GMM_SYS1_1step)',(K+1)*3,1);
resuls_GMM_SYS1_2step = reshape(squeeze(GMM_SYS1_2step)',(K+1)*3,1);
resuls_GMM_SYS1_CUE = reshape(squeeze(GMM_SYS1_CUE)',(K+1)*3,1);
resuls_GMM_SYS2_1step = reshape(squeeze(GMM_SYS2_1step)',(K+1)*3,1);
resuls_GMM_SYS2_2step = reshape(squeeze(GMM_SYS2_2step)',(K+1)*3,1);
resuls_GMM_SYS2_CUE = reshape(squeeze(GMM_SYS2_CUE)',(K+1)*3,1);

output_CLG = [results_MM_hp resultsAAH resuls_GMM_DIF1_2step resuls_GMM_SYS1_2step resuls_transML];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%  store estimation results
tab = zeros(16,5);
% AAH
tab(2:3,1) = output_ALL(1:2,2);
tab(2:3,3) = output_HSD(1:2,2);
tab(2:3,4) = output_HSG(1:2,2);
tab(2:3,5) = output_CLG(1:2,2);
% AB
tab(4:5,1) = output_ALL(1:2,3);
tab(4:5,3) = output_HSD(1:2,3);
tab(4:5,4) = output_HSG(1:2,3);
tab(4:5,5) = output_CLG(1:2,3);
% BB
tab(6:7,1) = output_ALL(1:2,4);
tab(6:7,3) = output_HSD(1:2,4);
tab(6:7,4) = output_HSG(1:2,4);
tab(6:7,5) = output_CLG(1:2,4);
% FDAC
tab(10:11,1) = output_ALL(1:2,1);
tab(10:11,3) = output_HSD(1:2,1);
tab(10:11,4) = output_HSG(1:2,1);
tab(10:11,5) = output_CLG(1:2,1);
% Estimated common trends
tab(15,1) = g_ALL;
tab(15,3) = g_HSD;
tab(15,4) = g_HSG;
tab(15,5) = g_CLG;
% Numebr of cross-sectional units
tab(16,1) = N_ALL;
tab(16,3) = N_HSD;
tab(16,4) = N_HSG;
tab(16,5) = N_CLG;

% FDAC
tab_var = zeros(5,5);
tab_var(1:2,1) = results_var(1:2,1); 
tab_var(1:2,3) = results_var(5:6,1);
tab_var(1:2,4) = results_var(9:10,1);
tab_var(1:2,5) = results_var(13:14,1);

tab_var(5,1) = N_ALL;
tab_var(5,3) = N_HSD;
tab_var(5,4) = N_HSG;
tab_var(5,5) = N_CLG;

m1(:,:,id) = tab;
var(:,:,id) = tab_var;

end
save('PSID2_educ.mat','m1','var')
