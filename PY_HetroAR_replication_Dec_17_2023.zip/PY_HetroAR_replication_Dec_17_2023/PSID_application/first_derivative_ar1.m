function [firstder]=first_derivative_ar1(n,T,dy,Phi,phi,omega,sig2_u,inOmegastar)
 % vector of first derivatives of the trasformed log-likelihood in Hsiao et al 2002
% see transformed_ml.m
 
g = 1+T*(omega-1);
 
firstder = zeros(4,1);
 
 for i=1:n
    DWi = [1,   0;
           zeros(T-1,1), dy(1:T-1,i)];    
    Dui =  dy(:,i) - DWi*phi;
    firstder(1:2,1) = firstder(1:2,1) + (1/sig2_u)*DWi'*inOmegastar*Dui;
    firstder(3,1)   = firstder(3,1)   + (1/(2*sig2_u*g^2))* Dui'*Phi*Dui;
    firstder(4,1)   = firstder(4,1)   + (1/(2*sig2_u^2))* Dui'*inOmegastar*Dui;
end
 
    firstder(3,1) = firstder(3,1) - (n*T)/(2*g);
    firstder(4,1) = firstder(4,1) - (n*T)/(2*sig2_u);
