function [transML, GMM_DIF1_1step, GMM_DIF1_2step, GMM_DIF1_CUE,   GMM_DIF2_1step, GMM_DIF2_2step, GMM_DIF2_CUE,   GMM_SYS1_1step, GMM_SYS1_2step, GMM_SYS1_CUE,   GMM_SYS2_1step, GMM_SYS2_2step, GMM_SYS2_CUE] = ML_GMM_estimators_ar1( Y_NT )
%   Y_NT:  T+1 x N 

[TT, N] = size(Y_NT);
T  = TT-1;
T1 = T-1;
K=0;




% first-difference and system GMM estimatos (1step, 2step, CUE)    
% number of moment conditions
[ coef_GMM_DIF1, coef_GMM_DIF2, coef_GMM_SYS1, coef_GMM_SYS2, var_GMM_DIF1, var_GMM_DIF2, var_GMM_SYS1, var_GMM_SYS2, coef_GMM_DIF_ML ] = GMMestimator_ar1(Y_NT,  T, N );


GMM_DIF1_1step = cat(3, coef_GMM_DIF1(:,1), sqrt( diag( var_GMM_DIF1(:,:,1) ) ), NaN(K+1,1) );
GMM_DIF1_2step = cat(3, coef_GMM_DIF1(:,2), sqrt( diag( var_GMM_DIF1(:,:,2) ) ), sqrt( diag( var_GMM_DIF1(:,:,3) ) ) );
GMM_DIF1_CUE   = cat(3, coef_GMM_DIF1(:,3), sqrt( diag( var_GMM_DIF1(:,:,4) ) ), sqrt( diag( var_GMM_DIF1(:,:,5) ) ) );
GMM_DIF2_1step = cat(3, coef_GMM_DIF2(:,1), sqrt( diag( var_GMM_DIF2(:,:,1) ) ), NaN(K+1,1) );
GMM_DIF2_2step = cat(3, coef_GMM_DIF2(:,2), sqrt( diag( var_GMM_DIF2(:,:,2) ) ), sqrt( diag( var_GMM_DIF2(:,:,3) ) ) );
GMM_DIF2_CUE   = cat(3, coef_GMM_DIF2(:,3), sqrt( diag( var_GMM_DIF2(:,:,4) ) ), sqrt( diag( var_GMM_DIF2(:,:,5) ) ) );
GMM_SYS1_1step = cat(3, coef_GMM_SYS1(:,1), sqrt( diag( var_GMM_SYS1(:,:,1) ) ), NaN(K+1,1) );
GMM_SYS1_2step = cat(3, coef_GMM_SYS1(:,2), sqrt( diag( var_GMM_SYS1(:,:,2) ) ), sqrt( diag( var_GMM_SYS1(:,:,3) ) ) );
GMM_SYS1_CUE   = cat(3, coef_GMM_SYS1(:,3), sqrt( diag( var_GMM_SYS1(:,:,4) ) ), sqrt( diag( var_GMM_SYS1(:,:,5) ) ) );
GMM_SYS2_1step = cat(3, coef_GMM_SYS2(:,1), sqrt( diag( var_GMM_SYS2(:,:,1) ) ), NaN(K+1,1) );
GMM_SYS2_2step = cat(3, coef_GMM_SYS2(:,2), sqrt( diag( var_GMM_SYS2(:,:,2) ) ), sqrt( diag( var_GMM_SYS2(:,:,3) ) ) );
GMM_SYS2_CUE   = cat(3, coef_GMM_SYS2(:,3), sqrt( diag( var_GMM_SYS2(:,:,4) ) ), sqrt( diag( var_GMM_SYS2(:,:,5) ) ) );





% transformed ML Estimation
y = Y_NT(2:TT,:);  y1 = Y_NT(1:TT-1,:);
dy = y(2:T,:)  - y(1:T-1,:);
dy1= y1(2:T,:) - y1(1:T-1,:);
du = reshape(dy,N*(T-1),1)  - reshape(dy1,N*(T-1),1)*coef_GMM_DIF_ML;
sigma_d = (du'*du)/(2*N*(T-2));
[coef_ML, var_ML, sigma_ML] = transformed_ml_ar1(N, T, Y_NT, coef_GMM_DIF_ML, sigma_d);
se_ML   = sqrt( diag( var_ML ) );

transML = cat(3, coef_ML, se_ML, NaN(K+1,1) );




end

