function [coef_ML, var_ML, sigma_ML]=transformed_ml_ar1(n, T, Y_NT,  d_d, sigma_d)
 
% compute the transformed likelihood estimator by Hsiao et al 2002,
% assuming homoskedastic errors, and 1 regressor (k=1)
 
% INPUT:
%  n  : number of cross section units 
%  T  : number of T periods-1
% Y_NT: dependent variable in the form of a  (T+1) x n matrix
% regressor
% d_d: GMM estimator of d=(gamma, beta')' to initialize the minimum distance estimator
% sigma_d: GMM estimator of the variance of u_it to initialize the minimum distance estimator.
 
% OUTPUT:
% d_ml: transformed lik estimator of d=(gamma, beta)'
% vard_ml: estimated asymptotic covariance of d_ml
 
dy  = Y_NT(2:T+1,:) - Y_NT(1:T,:) ;

Omegastar = 2*eye(T)+diag(-1*ones(T-1,1),1)+diag(-1*ones(T-1,1),-1);
Phi = sort((1:T)','descend')*sort((1:T),'descend');
 
expl = [ones(n,1)];
b0 = pinv(expl'*expl)*expl'*dy(1,:)';
phi0 = [b0; d_d];
% compute the minimum distance estimator
% [mde_phi,var_mde_phi,mde_omega,mde_sigma]=minimum_distance_estimator_ar1(n,T,dy,Phi,Omegastar,phi0,sigma_d);
 
% correct MDE
% if mde_omega<((T-1)/T)  mde_omega=((T-1)/T)+0.01;end;
% if mde_phi(2,1)>1 mde_phi(2,1)=0.999; end

omega0 = var(dy(1,:))/sigma_d;
% mde_omega = omega0;
% disp([omega0 mde_omega]);

% start transformed_ML estimation using mde as initial values
% theta0 = [mde_phi; mde_omega; mde_sigma];
theta0 = [phi0; omega0; sigma_d];
conv = 10^-4;  
diff = 1; 
r = 0;
lq = [-inf; -1.0; (T-1)/T; 0.01];
uq = [ inf;  1.0;  inf; inf];
while diff>conv && r<1000
    r=r+1;
   [theta,fval,exitflag,output,lambda,grad,hessian] = transformed_ml_opt_ar1(n,T,dy,Phi,Omegastar,theta0,lq,uq);
   diff = sum(abs(theta-theta0));
   theta0 = theta;
end
if exitflag<1 theta=1000*ones(size(theta));end
    
phi_ML   = theta(1:2);
omega_ML = theta(3);
sigma_ML = theta(4);
Omegastar(1,1) = omega_ML;
invOmegastar = pinv(Omegastar);


A11 = zeros(2,2);
A21 = zeros(1,2);

B11 = zeros(2,2);
B22 = zeros(1,1);
B33 = zeros(1,1);
B21 = zeros(1,2);
B31 = zeros(1,2);
B32 = zeros(1,1);

sig2_uhat = 0;
sig4_uhat = 0;
q_num=0;
q_den=0;

for i=1:n
    DWi = [1,   0;
           zeros(T-1,1), dy(1:T-1,i)];    
    Dui =  dy(:,i) - DWi*phi_ML;
    sig2_uhat = sig2_uhat + Dui'*invOmegastar*Dui;
    sig4_uhat = sig4_uhat + (Dui'*invOmegastar*Dui)^2;
    q_num = q_num + Dui'*Dui; 
    q_den = q_den + (Dui'*invOmegastar*Dui)^2; 

    A11 = A11 + DWi'*invOmegastar*DWi;
    A21 = A21 + Dui'*Phi*DWi;
    B11 = B11 + DWi'*invOmegastar*(Dui*Dui')*invOmegastar*DWi;
    B22 = B22 + (Dui'*Phi*Dui/T)^2;
    B33 = B33 + (Dui'*invOmegastar*Dui/T)^2;
    B21 = B21 + (Dui'*invOmegastar*DWi)*(Dui'*Phi*Dui);
    B31 = B31 + (Dui'*invOmegastar*DWi)*(Dui'*invOmegastar*Dui);
    B32 = B32 + (Dui'*Phi*Dui/T)*(Dui'*invOmegastar*Dui/T);
    
end
g = 1+T*(omega_ML-1);
sig2_uhat = sig2_uhat/(n*(T-0));
q = q_num/q_den;
Omega_sig = eye(T+1);
Omega_sig(1,1) = omega_ML-1;
H = [-eye(T) zeros(T,1)] + [zeros(T,1) eye(T) ];
H(1,1)=1;
G = Omega_sig^(1/2)*H'*invOmegastar*H*Omega_sig^(1/2);
exkurt = (T*(T+2)*q-3*omega_ML^2-12*(T-1))/( (omega_ML-1)^2+2*T-1-q*sum(diag(G).*diag(G)) );
sig4_uhat = sig4_uhat/(n*(exkurt*sum(diag(G).*diag(G))+ T*(T+2)));

sig4_uhat = sig4_uhat/(n*T*(T+2));

A11 = (1/(n*T*sig2_uhat))*A11;
A22 = T/(2*g^2);
A33 = 1/(2*sig2_uhat^2);
A21 = (1/(g^2*n*T*sig2_uhat))*A21;
A12 = A21';
A31 = zeros(1,2);
A13 = A31';
A32 = 1/(2*g*sig2_uhat);
A23 = A32';
A = [A11 A12 A13; 
     A21 A22 A23; 
     A31 A32 A33];

B11 = (1/(n*T*sig2_uhat^2))*B11;
B22 = (T/(4*g^4*sig2_uhat^2))*(n^(-1)*B22 - g^2*sig4_uhat);
B33 = (T/(4*sig2_uhat^4))*(n^(-1)*B33 - sig4_uhat);
B21 = (1/(2*n*T*g^2*sig2_uhat^2))*B21;
B31 = (1/(2*n*T*sig2_uhat^3))*B31;
B32 = (T/(4*g^2*sig2_uhat^3))*(n^(-1)*B32 - g*sig4_uhat);
B12 = B21';
B13 = B31';
B23 = B32';
B = [B11 B12 B13; 
     B21 B22 B23;
     B31 B32 B33];


var_theta = pinv(A)*B*pinv(A)/(n*T);
% var_theta = pinv(A)/(n*T);

% [secder] = second_derivative(n,T,dy,dx,Phi,phi_ML,omega_ML,sigma_ML,invOmegastar);
% var_theta = (pinv(-secder));
% disp(A);
% disp(secder/(n*T));

% disp(A+secder/(n*T));
% var_theta = pinv(secder/(n*T))*B*pinv(secder/(n*T))/(n*T);


%  disp(A*n*T);
%  disp(-secder);
coef_ML    = theta(2,1);
var_ML = var_theta(2,2);
% se_ML = sqrt(diag(var_theta(T+2:T+3,T+2:T+3)));
