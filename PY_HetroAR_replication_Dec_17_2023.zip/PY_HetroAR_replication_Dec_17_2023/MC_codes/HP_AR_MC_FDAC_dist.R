#### FDAC and HetroGMM estimators proposed in Pesaran and Yang (2023) "Hetro. AR panels"
rm(list=ls())
list.of.packages <- c("parallel","parallelly","openxlsx")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
library(parallel) # mclapply
library(parallelly) # detect cores
library(openxlsx)


rep = 2000 # number of replications in each loop
reps = 1:rep
NumPara = 3
Nlist = c(2000,5000,10000,50000); 
Tlist = c(6,8,10); 
Nmax = max(Nlist); Tmax = max(Tlist)
NT = expand.grid(Nlist,Tlist); NT = cbind(NT[,2],NT[,1])
M0=50 
set.seed(123987654) 

# parameters of AR(1) coefficients
mphi_l = c(0.4,0.4,0.62,0.475,0.62) # mean
p3 = c(0.3,0.5,0.2,0,0) 
p4 = c(0,  0,  0.8,0,0)
p5 = c(0,  0,  0.3,0,0)
vphi_l = c(p3[1]^(2/3),p3[2]^(2/3),(p3[3]^2*p5[3]+p4[3]^2*(1-p5[3]))-mphi_l[3]^2,0,0) # variance
pm = rbind(mphi_l,vphi_l,p3,p4,p5)

mcvs = cbind(0.6, 0.2) # parameters for GARCH effects

#### Data generating process
################################################################################
### Generate initial values and random coefficients
GenRandomPara = function(N,NumPara,case,ka=1) {
  para = array(0,dim=c(N,NumPara))
  ## initial values
  para[,1] = ka*0 # y1_{i} = 0 for all individuals
  p = pm[case,]
  ## AR(1) coefficients
  if (case==1) {
    mphi = 0.4; a = 0.3 # 0.4 + uniform (-0.3, 0.3)
    para[,3] = mphi + runif(N, min=-a, max=a) 
  }
  if (case==2) { 
    mphi = 0.4; a = 0.5 # 0.4 + uniform (-0.5, 0.5)
    para[,3] = mphi + runif(N, min=-a, max=a) 
  }
  if (case==3) {
    lb= 0.2; ub= 0.8; pi= 0.3 # categorical
    para[,3] = matrix(t(matrix(c(rep(lb,pi*N),rep(ub,(1-pi)*N)),N/10,10)),N,1)
  }
  if (case==4) {
    mphi = 0.475 # homogeneous phi_i = phi_0 = 0.475
    para[,3] = rep(mphi,N)
  }
  if (case==5) {
    mphi = 0.620 # homogeneous phi_i = phi_0 = 0.620
    para[,3] = rep(mphi,N)
  }
  ## individual fixed effects
  para[,2] = para[,3]+rnorm(N,0,1) 
  para
}

### Generate errors and a panel of outcome variables
GenError = function(N,T,ve,GAUSSIAN,GARCH){
  u = array(0,dim=c(N,T))
  e = array(0,dim=c(N,T))
  h = array(0,dim=c(N,T))
  
  if (GAUSSIAN == TRUE & GARCH == FALSE){
    e[,2:T] = matrix(rnorm(N*(T-1)),N,T-1)
    h[,2:T] = matrix(sqrt(ve),N,T-1)
    u[,2:T] = h[,2:T]*e[,2:T]
  }
  
  if (GAUSSIAN == TRUE & GARCH == TRUE){
    e[,2:T] = matrix(rnorm(N*(T-1)),N,T-1)
    cvs = t(matrix(mcvs,2,N)) # coefficients of GARCH effects
    h[,1] = sqrt(ve) # stationary initial values for GARCH(1,1)
    for(t in 2:T){
      ### GARCH(1,1)
      h[,t] = sqrt(ve-ve*rowSums(cvs) + cvs[,1]*h[,t-1]^2 + cvs[,2]*u[,t-1]^2)
      u[,t] = h[,t]*e[,t]
    }
  }
  
  if (GAUSSIAN == FALSE & GARCH == FALSE){
    e[,2:T] = matrix((rchisq(N*(T-1),2,ncp=0)-2)/2,N,T-1)
    h[,2:T] = matrix(sqrt(ve),N,T-1)
    u[,2:T] = h[,2:T]*e[,2:T]
  }
  
  if (GAUSSIAN == FALSE & GARCH == TRUE){
    cvs = t(matrix(mcvs,2,N)) # coefficients of GARCH effects
    e[,2:T] = matrix((rchisq(N*(T-1),2,ncp=0)-2)/2,N,T-1)
    h[,1] = sqrt(ve) # stationary initial values for GARCH(1,1)
    for(t in 2:T){
      ### GARCH(1,1)
      h[,t] = sqrt(ve-ve*rowSums(cvs) + cvs[,1]*h[,t-1]^2 + cvs[,2]*u[,t-1]^2)
      u[,t] = h[,t]*e[,t]
    }
  }
  
  return(u[,2:T])
}

### Function: Generate Y
GenRandomY = function(N,T,para,ve,GAUSSIAN,GARCH){
  Y = array(0,dim=c(N,T))
  Y[1:N,1] = para[1:N,1]
  GAUSSIAN = GAUSSIAN
  GARCH = GARCH
  T = T
  errors = GenError(N,T,ve,GAUSSIAN,GARCH) # N*(T-1) matrix
  for(t in 1:(T-1)){
    ### Below: Y_{t+1} = alpha + beta Y_t + sigma 
    Y[1:N,(t+1)] = para[1:N,2] + para[1:N,3] * Y[1:N,t] + errors[1:N,t]
  }
  Y
}
################################################################################


##############################################################################
####### FDAC and HetroGMM estimators of moments and categorical distribution parameters by Pesaran and Yang (2023)
##############################################################################
inv = function(m) class(try(solve(m),silent=T))[1]=="matrix"

Moment_mv = function(paneldata){
  T = dim(paneldata)[2]; N = dim(paneldata)[1]
  y = matrix(t(paneldata),nrow=T,ncol=N)
  Tm = min(dim(y))
  tm = min(dim(y)) -1
  n = max(dim(y))
  dy = y[2:Tm,] - y[1:(Tm-1),]  # first difference of panel data
  
  ######## MM: Individual Moments average over T : (T-h-1)*N matrix 
  lagdyy = 1*(tm>2)+1*(tm>3)+1*(tm>4)+1 # order of h for \Delta y_{it}\Delta y_{i,t-h}
  dyyi1 = matrix(, nrow = 5, ncol = n) # moments of \Delta y_{it}\Delta y_{i,t-h}, h=0,1,...,lagdyy
  dyyi2 = matrix(, nrow = 3, ncol = n) # T-3 h=0,1,2 
  dyyi3 = matrix(, nrow = 4, ncol = n) # T-4 h=0,1,2,3  
  dyyi4 = matrix(, nrow = 5, ncol = n) # T-5 h=0,1,2,3,4 
  
  for (ll in 0:lagdyy){
    dyyi1[(ll+1),] = matrix(t(dy[(1+ll):tm,]*dy[1:(tm-ll),]),nrow=n,ncol=(tm-ll)) %*% matrix(1,nrow = tm-ll,ncol=1) / (tm-ll)# average over t-h-1 
  }
  
  if (tm>=3) {
    dyyi2 = rbind(matrix(matrix(t(dy[3:tm,]^2),nrow=n,ncol=(tm-2)) %*% matrix(1,nrow=tm-2,ncol=1)/(tm-2),nrow=1,ncol=n),
                  matrix(matrix(t(dy[3:tm,]*dy[2:(tm-1),]),nrow=n,ncol=(tm-2)) %*% matrix(1,nrow=tm-2,ncol=1)/(tm-2),nrow=1,ncol=n),
                  matrix(matrix(t(dy[3:tm,]*dy[1:(tm-2),]),nrow=n,ncol=(tm-2)) %*% matrix(1,nrow=tm-2,ncol=1)/(tm-2),nrow=1,ncol=n)) # MM b
    hi1 = matrix(dy[3:tm,]^(2) + dy[3:tm,]*dy[2:(tm-1),],nrow=(tm-2),ncol=n) # GMM (T-3)*n vector
    gi1 = matrix(dy[3:tm,]^(2) + 2*dy[3:tm,]*dy[2:(tm-1),] + dy[3:tm,]*dy[1:(tm-2),],nrow=(tm-2),ncol=n) 
    
    ####### MM Average across i
    dyy1 = dyyi1 %*% matrix(1,nrow=n,ncol=1)/n # h=0,1,2,...,lagdyy
    dyy2 = dyyi2 %*% matrix(1,nrow=n,ncol=1)/n # h=0,1,2
    ####### MM Version a: dyy1 with different T-h-1
    mm1 = (dyy1[1]+2*dyy1[2]+dyy1[3])/(dyy1[1]+dyy1[2]) # Equation (15) 
    mms1 = sum((dyyi1[1,]+2*dyyi1[2,]+dyyi1[3,]-mm1*(dyyi1[1,]+dyyi1[2,]))^2)/n # average across i
    std_mm1 = sqrt((dyy1[1]+dyy1[2])^(-2)*mms1/n) # ((mean(dyyi1[1,]+dyyi1[2,]))^(2)*(mms1^(-1)))^(-1)/n   
    
    
    ####### GMM 
    hnt1 = hi1 %*% matrix(1,nrow=n,ncol=1) / n  # (T-3)*1 average over n rowMeans(hi1)
    gnt1 = gi1 %*% matrix(1,nrow=n,ncol=1) / n  # average over n rowMeans(gi1) 
    gmms1 = (gi1-mm1*hi1) %*% t(gi1-mm1*hi1) /n  # the optimal weight (T-3)*(T-3) matrix for the mean Equation (20)
    if (inv(gmms1) == 1) {
      gmms1 = gmms1
    } else {
      gmms1 = diag(tm-2)/n
    }
    gmm1 =  solve(t(hnt1) %*% solve(gmms1) %*% hnt1) * (t(hnt1) %*% solve(gmms1) %*% gnt1) # 1st moment: Equation (22)
    std_gmm1 = sqrt(solve(t(hnt1) %*% solve(gmms1) %*% hnt1) /n) #Asymptotic variance
  }
  
  if (tm>=4) {
    svmi = matrix(, nrow = 2^2 , ncol=n) # sample variance of moment conditions
    svgi = matrix(, nrow = (tm-2+tm-3)^2 , ncol=n) # sample variance of joint moment conditions: 1st, 2nd
    
    dyyi3 = rbind(matrix(matrix(t(dy[4:tm,]^2),nrow=n,ncol=(tm-3)) %*% matrix(1,nrow=tm-3,ncol=1)/(tm-3),nrow=1,ncol=n), 
                  matrix(matrix(t(dy[4:tm,]*dy[3:(tm-1),]),nrow=n,ncol=(tm-3)) %*% matrix(1,nrow=tm-3,ncol=1)/(tm-3),nrow=1,ncol=n),
                  matrix(matrix(t(dy[4:tm,]*dy[2:(tm-2),]),nrow=n,ncol=(tm-3)) %*% matrix(1,nrow=tm-3,ncol=1)/(tm-3),nrow=1,ncol=n),
                  matrix(matrix(t(dy[4:tm,]*dy[1:(tm-3),]),nrow=n,ncol=(tm-3)) %*% matrix(1,nrow=tm-3,ncol=1)/(tm-3),nrow=1,ncol=n))
    hi2 = matrix(dy[4:tm,]^(2) + dy[4:tm,]*dy[3:(tm-1),],nrow=(tm-3),ncol=n) #  (T-4)*n vector
    gi2 = matrix(dy[4:tm,]^(2) + 2*dy[4:tm,]*dy[3:(tm-1),] + 2*dy[4:tm,]*dy[2:(tm-2),] + dy[4:tm,]*dy[1:(tm-3),],nrow=(tm-3),ncol=n) 
    
    dyy3 = dyyi3 %*% matrix(1,nrow=n,ncol=1)/ n # h=0,1,2,3
    ### MM: 2nd
    mm2 = (dyy1[1]+2*dyy1[2]+2*dyy1[3]+dyy1[4])/(dyy1[1]+dyy1[2]) # Equation (16) 
    mms2 = mean((dyyi1[1,]+2*dyyi1[2,]+2*dyyi1[3,]+dyyi1[4,]-mm2*(dyyi1[1,]+dyyi1[2,]))^2)
    std_mm2 = sqrt((dyy1[1]+dyy1[2])^(-2)*mms2 /n)  #1-(rho[1]+2*mm1*rho[1]+mm2*rho[1])/(1-rho[1]) - mm2 
    mmv = mm2-mm1^2 # plug-in estimator of variance
    
    mc = rbind(mm1 * (dyyi1[1,]+dyyi1[2,]) - (dyyi1[1,]+2*dyyi1[2,]+dyyi1[3,]), mm2*(dyyi1[1,]+dyyi1[2,]) - (dyyi1[1,]+2*dyyi1[2,]+2*dyyi1[3,]+dyyi1[4,])) # n*2 matrix
    index = 1
    for (i in 1:2){
      for (j in 1:2) {
        svmi[index,] = mc[i,] * mc[j,]
        index = index +1
      }
    }
    rm(mc)
    jmms2 = matrix(c(rowMeans(svmi)),nrow = 2 ,ncol = 2) # with the mmb plugged in  
    dmm2 = matrix(c(-2*mm1,1),nrow = 2,ncol = 1)
    jhm2 = matrix(c((dyy1[1]+dyy1[2]),0,0,(dyy1[1]+dyy1[2])),nrow=2,ncol=2)
    
    if (inv(jhm2) == 1) {
      jhm2 = jhm2} else {
        jhm2 = diag(2)
      }
    std_mmv = sqrt(t(dmm2) %*% solve(jhm2) %*% (jmms2) %*% solve(jhm2) %*% dmm2 /n  )
    
    ### GMM : 2nd
    hnt2 = rowMeans(hi2)
    gnt2 = rowMeans(gi2)
    gmms2 = (gi2-mm2*hi2) %*% t(gi2-mm2*hi2) /n  # the optimal weight (T-4)*(T-4) matrix for the mean Equation (31)
    if (inv(gmms2) == 1) {
      gmms2 = gmms2} else {
        gmms2 = diag(tm-3)
      }
    gmm2 =  solve(t(hnt2) %*% solve(gmms2) %*% hnt2) * (t(hnt2) %*% solve(gmms2) %*% gnt2) # 2nd moment: Equation (29)
    gmmv = gmm2 - gmm1^2
    zeroh1 = matrix(rep(0,length(hi1[,i])), nrow=length(hi1[,i]),ncol=1)
    zeroh2 = matrix(rep(0,length(hi2[,i])), nrow=length(hi2[,i]),ncol=1)
    zerom1 = matrix(rep(0, (tm-2)*(tm-3)),nrow=tm-2,ncol=tm-3)
    zerom2 = matrix(rep(0, (tm-2)*(tm-3)),nrow=tm-3,ncol=tm-2)
    
    mc = rbind(kronecker(gmm1,hi1)-gi1, kronecker(gmm2,hi2)-gi2) # (T-3+T-4)*2 matrix
    index = 1
    for (i in 1:(2*tm-5)){
      for (j in 1:(2*tm-5)) {
        svgi[index,] = mc[i,] * mc[j,]
        index = index +1
      }
    }
    rm(mc)
    jgmms2 = matrix(c(rowMeans(svgi)),nrow = 2*tm-5 ,ncol = 2*tm-5) # covariance matrix of joint moments
    jhg2 =  rbind(cbind(hnt1,zeroh1),cbind(zeroh2,hnt2)) # （2*tm-5) times 2 matrix
    
    gmma2 = rbind(cbind(solve(gmms1),zerom1),cbind(zerom2,solve(gmms2))) # weight matrix
    gmmcv2 = solve(t(jhg2) %*% gmma2 %*% jhg2) %*% t(jhg2) %*% gmma2 %*% jgmms2 %*% t(gmma2) %*% jhg2 %*% solve(t(jhg2) %*% t(gmma2) %*% jhg2)
    dgmm2 = matrix(c(-2*gmm1,1),nrow = 2,ncol = 1)
    
    std_gmm2 = sqrt((t(hnt2) %*% solve(gmms2) %*% hnt2)^(-1)/n)
    std_gmmv =  sqrt(t(dgmm2) %*% gmmcv2  %*% dgmm2 /n)
    
  }
  
  if (tm>=5) {
    dyyi4 = rbind(matrix(matrix(t(dy[5:tm,]^2),nrow=n,ncol=(tm-4)) %*% matrix(1,nrow=tm-4,ncol=1)/(tm-4),nrow=1,ncol=n),
                  matrix(matrix(t(dy[5:tm,]*dy[4:(tm-1),]),nrow=n,ncol=(tm-4)) %*% matrix(1,nrow=tm-4,ncol=1)/(tm-4),nrow=1,ncol=n),
                  matrix(matrix(t(dy[5:tm,]*dy[3:(tm-2),]),nrow=n,ncol=(tm-4)) %*% matrix(1,nrow=tm-4,ncol=1)/(tm-4),nrow=1,ncol=n),
                  matrix(matrix(t(dy[5:tm,]*dy[2:(tm-3),]),nrow=n,ncol=(tm-4)) %*% matrix(1,nrow=tm-4,ncol=1)/(tm-4),nrow=1,ncol=n),
                  matrix(matrix(t(dy[5:tm,]*dy[1:(tm-4),]),nrow=n,ncol=(tm-4)) %*% matrix(1,nrow=tm-4,ncol=1)/(tm-4),nrow=1,ncol=n))
    hi3 = matrix(dy[5:tm,]^(2) + dy[5:tm,]*dy[4:(tm-1),],nrow=(tm-4),ncol=n) #  (T-5)*n vector
    gi3 = matrix(dy[5:tm,]^(2) + 2*dy[5:tm,]*dy[4:(tm-1),] + 2*dy[5:tm,]*dy[3:(tm-2),] + 2*dy[5:tm,]*dy[2:(tm-3),] + dy[5:tm,]*dy[1:(tm-4),],nrow=(tm-4),ncol=n) # 
    
    dyy4 = rowMeans(dyyi4) # h=0,1,2,3,4
    ### MM
    mm3 = (dyy1[1]+2*dyy1[2]+2*dyy1[3]+2*dyy1[4]+dyy1[5])/(dyy1[1]+dyy1[2]) # 
    mms3 = mean((dyyi1[1,]+2*dyyi1[2,]+2*dyyi1[3,]+2*dyyi1[4,]+dyyi1[5,]-mm3*(dyyi1[1,]+dyyi1[2,]))^2)
    std_mm3 = sqrt((dyy1[1]+dyy1[2])^(-2)*mms3 /n)  #1-(rho[1]+2*mm1*rho[1]+mm2*rho[1])/(1-rho[1]) - mm2 
    
    
    ### GMM: 3rd
    hnt3 = rowMeans(hi3)
    gnt3 = rowMeans(gi3)
    gmms3 = (gi3-mm3*hi3) %*% t(gi3-mm3*hi3) /n  # the optimal weight (T-5)*(T-5) matrix for the mean Equation (31)
    if (inv(gmms3) == 1) {
      gmms3 = gmms3} else {
        gmms3 = diag(tm-4)
      }
    gmm3 =  solve(t(hnt3) %*% solve(gmms3) %*% hnt3) * (t(hnt3) %*% solve(gmms3) %*% gnt3) # 2nd moment: Equation (29)
    std_gmm3 = sqrt((t(hnt3) %*% solve(gmms3) %*% hnt3)^(-1)/n)
  }
  
  if (tm==3){
    return(cbind(mm1,std_mm1,gmm1,std_gmm1))
  }
  if (tm==4) {
    return(cbind(mm1,std_mm1,gmm1,std_gmm1,
                 mm2,std_mm2,gmm2,std_gmm2,
                 mmv,std_mmv,gmmv,std_gmmv))
  }
  if (tm>4){
    return(cbind(mm1,std_mm1,gmm1,std_gmm1,
                 mm2,std_mm2,gmm2,std_gmm2,
                 mmv,std_mmv,gmmv,std_gmmv,
                 mm3,std_mm3,gmm3,std_gmm3))
  }
}

Moment_dist = function(paneldata){
  ## Input paneldata and first difference
  ##########################################################
  T = dim(paneldata)[2]; N = dim(paneldata)[1]
  y = matrix(t(paneldata),nrow=T,ncol=N)
  Tm = min(dim(y))
  tm = min(dim(y)) -1
  n = max(dim(y))
  dy = y[2:Tm,] - y[1:(Tm-1),]  # first difference of panel data
  ##########################################################
  
  ## Individual Moments average over T : (T-h-1)*N matrix 
  ##########################################################
  lagdyy = 1*(tm>2)+1*(tm>3)+1*(tm>4)+1 # order of h for \Delta y_{it}\Delta y_{i,t-h}
  dyyi1 = matrix(, nrow = 5, ncol = n) # moments of \Delta y_{it}\Delta y_{i,t-h}, h=0,1,...,lagdyy
  
  for (ll in 0:lagdyy){
    dyyi1[(ll+1),] = matrix(t(dy[(1+ll):tm,]*dy[1:(tm-ll),]),nrow=n,ncol=(tm-ll)) %*% matrix(1,nrow = tm-ll,ncol=1) / (tm-ll)# average over t-h-1 
  }
  dyy1 = dyyi1 %*% matrix(1,nrow=n,ncol=1)/n # h=0,1,2,...,lagdyy
  ##########################################################

  ## MM estimator of 1st, 2nd, and 3rd moments and covariance matrix
  ##########################################################
  m1 = (dyy1[1]+2*dyy1[2]+dyy1[3])/(dyy1[1]+dyy1[2]) # Equation (15) 
  #mms1 = sum((dyyi1[1,]+2*dyyi1[2,]+dyyi1[3,]-mm1*(dyyi1[1,]+dyyi1[2,]))^2)/n # average across i
  #std_mm1 = sqrt((dyy1[1]+dyy1[2])^(-2)*mms1/n) # ((mean(dyyi1[1,]+dyyi1[2,]))^(2)*(mms1^(-1)))^(-1)/n   
  m2 = (dyy1[1]+2*dyy1[2]+2*dyy1[3]+dyy1[4])/(dyy1[1]+dyy1[2]) # Equation (16) 
  #mms2 = mean((dyyi1[1,]+2*dyyi1[2,]+2*dyyi1[3,]+dyyi1[4,]-mm2*(dyyi1[1,]+dyyi1[2,]))^2)
  #std_mm2 = sqrt((dyy1[1]+dyy1[2])^(-2)*mms2 /n)  #1-(rho[1]+2*mm1*rho[1]+mm2*rho[1])/(1-rho[1]) - mm2 
  m3 = (dyy1[1]+2*dyy1[2]+2*dyy1[3]+2*dyy1[4]+dyy1[5])/(dyy1[1]+dyy1[2]) # 
  #mms3 = mean((dyyi1[1,]+2*dyyi1[2,]+2*dyyi1[3,]+2*dyyi1[4,]+dyyi1[5,]-mm3*(dyyi1[1,]+dyyi1[2,]))^2)
  #std_mm3 = sqrt((dyy1[1]+dyy1[2])^(-2)*mms3 /n)  #1-(rho[1]+2*mm1*rho[1]+mm2*rho[1])/(1-rho[1]) - mm2 
  
  svmi = matrix(, nrow = 3^3 , ncol=n) # sample variance of moment conditions
  mc = rbind(m1 * (dyyi1[1,]+dyyi1[2,]) - (dyyi1[1,]+2*dyyi1[2,]+dyyi1[3,]), m2*(dyyi1[1,]+dyyi1[2,]) - (dyyi1[1,]+2*dyyi1[2,]+2*dyyi1[3,]+dyyi1[4,]), 
             m3*(dyyi1[1,]+dyyi1[2,]) - (dyyi1[1,]+2*dyyi1[2,]+2*dyyi1[3,]+2*dyyi1[4,]+dyyi1[5,])) # n*2 matrix
  index = 1
  for (i in 1:3){
    for (j in 1:3) {
      svmi[index,] = mc[i,] * mc[j,]
      index = index +1
    }
  }
  rm(mc,index)
  jmms3 = matrix(c(rowMeans(svmi)),nrow = 3 ,ncol = 3) 
  jhm3 = matrix(c((dyy1[1]+dyy1[2]),0,0,0,(dyy1[1]+dyy1[2]),0,0,0,(dyy1[1]+dyy1[2])),nrow=3,ncol=3)
  if (inv(jhm3) == 1) {
    jhm3 = jhm3} else {
      jhm3 = diag(3)
    }
  
  cov_m3 = solve(jhm3) %*% (jmms3) %*% solve(jhm3) /n  
  ##########################################################

  ## MM estimator of distribution parameters 
  ##########################################################
  #A = (m3-m1*m2)/(m2-m1^2)
  #B = (m1*m3-m2^2)/(m2-m1^2)
  #D = A^2-4*B
  A=m2-m1^2
  B=m3-m1*m2
  C=m1*m3-m2^2
  D=B^2-4*A*C
  if (D<0) {
    v1 = 9999
    v2 = 9999
    p1 = 9999
  }
  if (D>0) {
    #v1 = 1/2*(A-sqrt(D))
    #v2 = 1/2*(A+sqrt(D))
    v1 = 1/(2*A)*(B-sqrt(D))
    v2 = 1/(2*A)*(B+sqrt(D))
    vs = cbind(v1,v2)
    pi = (v2 - m1)/(v2-v1)
  }
  ##########################################################


  return(append(D>0,cbind(v1,v2,pi)))
}

MonteCarloSim = function(r,N,Tobs){
  panel0 = matrix(data_all[,r],Nmax,Tmax); 
  panel1 = panel0[1:N,1:Tobs]
  Moment_dist(panel1)
}


for (GAUSSIAN in c(0,1)) {
 for (GARCH in c(0,1)) {
   for (case in 1:3) {
     start_time = Sys.time()
     
     #### Generate samples
     ##################################################################################################
     data_all = matrix(,Nmax*Tmax,rep); 
     for (r in 1:rep ) {
       ve = 0.5+ 0.5*rchisq(Nmax,1,ncp=0) # cross-sectional hetero variance of errors
       para = GenRandomPara(Nmax,NumPara,case,ka=1) 
       paneldata = GenRandomY(Nmax,(Tmax+M0+2),para,ve,GAUSSIAN,GARCH)
       paneldata = paneldata[,(M0+2+1):(M0+2+Tmax)]
       data_all[,r] = matrix(paneldata,Nmax*Tmax,1);rm(paneldata)
     }
     rm(para,ve)
     ##################################################################################################
     
     for (Tobs in Tlist) {
       for (N in Nlist) {
         numCores = availableCores()
         mc_results = mclapply(reps,MonteCarloSim,N=N,Tobs=Tobs,mc.preschedule = TRUE, mc.cores = numCores)
         temp = matrix(unlist(mc_results),4,rep)
         
         name = paste("cd",case,sep="_c") 
         Nid = which(Nlist==N); Tid = which(Tlist==Tobs)
         s = (Tid-1)*length(Nlist)+Nid;
         if (s<10) {
           name = paste(name,s,sep="_0")
         } else {
           name = paste(name,s,sep="_") 
         }
         assign(name,temp);rm(temp,name,mc_results)
       }
     }
     
     rm(data_all)
     end_time = Sys.time()
     time = end_time - start_time
     fn = paste("exp_fdac_dist_c",case,"_",GAUSSIAN,GARCH,".RData",sep="")
     save.image(file=fn)
   }  
 } 
}






#### Functions: calculate statistics
## (Bias, RMSE, T_test & Power, Coverage)
################################################################################
Bias = function(ests,truev) {
  ests = as.matrix(ests)
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  colMeans(ests - truematrix)
}

RMSE = function(ests,truev) {
  ests = as.matrix(ests)
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  sqrt(colMeans((ests - truematrix)^2))
}

T_test = function(truev,estsd,rep){
  ests = as.matrix(estsd[1:rep])
  sds = as.matrix(estsd[(rep+1):(2*rep)])
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  colMeans(abs((ests-truematrix)/sds)>qnorm(p = 0.975))
}

pwlb=-2.5; pwrb=2.5; pwintv=0.01;
pwgrid = length(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv)))
Power = function(truev,estsd,rep){
  h1 = as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv)) # values of alternatives (v0-0.5,v0+0.5) length = 101
  powers = sapply(h1,function(x) T_test(x,estsd,rep))
  powers
}
################################################################################

## Functions: set the format of numbers reported in each cell
## (percent, specify_decimal)
#########################################################################
percent = function(x, digits = 0, format = "f") {
  paste0(formatC(100 * x, format = format, digits = digits), "\\%")
}

specify_decimal = function(x, k) {
  trimws(format(round(x, k), nsmall=k))
}
#########################################################################


Nlist = c(2000,5000,10000,50000); Tlist = c(6,8,10); 
NT = expand.grid(Nlist,Tlist); NT = cbind(NT[,2],NT[,1])

g1 = c(1,1,0,0) # Gaussian or non-Gaussian
g2 = c(1,0,0,1) # with or without GARCH effects

g_list = cbind(g1,g2)
tab_list = c('Table S.28','Table S.29','Table S.30','Table S.31')

# Create a style for center-aligning the numbers
##############################################################################
center_style <- createStyle(halign = "center")
right <- createStyle(halign = "right")
left <- createStyle(halign = "left")
bbs <- createStyle(border = "bottom",borderStyle="thin")
lbs <- createStyle(border = "bottom",borderStyle="double")
tbs <- createStyle(border = "top",borderStyle="double")
wrap_text_style <- createStyle(wrapText = TRUE)

pwlb=-2.5; pwrb=2.5; pwintv=0.01;
pwgrid = length(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv)))
k=2;
##############################################################################


# Create a new workbook
wb <- createWorkbook()

for (gid in 1:4) {
  sn = tab_list[gid]
  addWorksheet(wb, sn)
  
  if (gid==1) {
    writeData(wb, sn, x = "Table S.28 Bias and RMSE of FDAC estimator of categorical distribution parameters (phi_L, phi_H, pi)' with Gaussian errors and GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
  }
  if (gid==2) {
    writeData(wb, sn, x = "Table S.29 Bias and RMSE of FDAC estimator of categorical distribution parameters (phi_L, phi_H, pi)' with Gaussian errors", startCol = 1, startRow = 1, colNames = FALSE)
  }
  if (gid==3) {
    writeData(wb, sn, x = "Table S.30 Bias and RMSE of FDAC estimator of categorical distribution parameters (phi_L, phi_H, pi)' with non-Gaussian errors", startCol = 1, startRow = 1, colNames = FALSE)
  }
  if (gid==4) {
    writeData(wb, sn, x = "Table S.31 Bias and RMSE of FDAC estimator of categorical distribution parameters (phi_L, phi_H, pi)' with non-Gaussian errors and GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
  }
  writeData(wb, sn, x = "phi_i = 0.4 + v_i, v_i~IIDU(-0.3,0.3)", startCol = 4, startRow = 2, colNames = FALSE)
  writeData(wb, sn, x = "phi_i = 0.4 + v_i, v_i~IIDU(-0.5,0.5)", startCol = 13, startRow = 2, colNames = FALSE)
  writeData(wb, sn, x = "Categorical distributed phi_i", startCol = 22, startRow = 2, colNames = FALSE)
  
  GAUSSIAN = g_list[gid,1]; GARCH = g_list[gid,2]
  dp = matrix(,dim(NT)[1],2) # distribution parameters
  
  phi1_bias = matrix(,dim(NT)[1],3) 
  phi2_bias = matrix(,dim(NT)[1],3) 
  pi1_bias = matrix(,dim(NT)[1],3) 
  
  phi1_rmse = matrix(,dim(NT)[1],3) 
  phi2_rmse = matrix(,dim(NT)[1],3) 
  pi1_rmse = matrix(,dim(NT)[1],3)
  
  for (case in c(1,2,3)) {
    #### Distribution parameters of phi_i
    if (case==1) {
      mphi = 0.4
      a = 0.3
      ub = mphi+a; lb=mphi-a
      vphi = a^2/3 
      mphi2 = vphi+mphi^2
      mphi3 = 1/4/(ub-lb)*(ub^4-lb^4) 
      p = rbind(mphi,vphi,lb,ub)
      a = (mphi3-mphi*mphi2)/(mphi2-mphi^2)
      b = (mphi*mphi3 - mphi2^2)/(mphi2-mphi^2)
      d = a^2-4*b
      phi1 = 0.5*(a-sqrt(d)) # 0.23
      phi2 = 0.5*(a+sqrt(d)) # 0.57
      pi1 = (phi2 - mphi)/(phi2-phi1) # 0.5
      pi2 = 1-pi1 # 0.5
     }
    if (case==2) {
      mphi = 0.4
      a = 0.5
      ub = mphi+a; lb=mphi-a
      vphi = a^2/3 
      mphi2 = vphi+mphi^2
      mphi3 = 1/4/(ub-lb)*(ub^4-lb^4) 
      p = rbind(mphi,vphi,lb,ub)
      a = (mphi3-mphi*mphi2)/(mphi2-mphi^2)
      b = (mphi*mphi3 - mphi2^2)/(mphi2-mphi^2)
      d = a^2-4*b
      phi1 = 0.5*(a-sqrt(d)) # 0.11
      phi2 = 0.5*(a+sqrt(d)) # 0.69
      pi1 = (phi2 - mphi)/(phi2-phi1) # 0.5
      pi2 = 1-pi1
    }
    if (case==3) {
      lb = 0.2
      ub = 0.8
      pi = 0.3
      mphi = lb*pi+ub*(1-pi) # moments (mb, vb)
      vphi = (lb^2*pi+ub^2*(1-pi))-mphi^2
      mphi2 = vphi+mphi^2
      mphi3 = lb^3*pi+ub^3*(1-pi)
      p = rbind(mphi,vphi,lb,ub,pi)
      phi1 = lb
      phi2 = ub
      pi1 = pi
      pi2 = 1-pi1
    }
    
    #### Get the respective simulation results
    ################################################################################  
    fn = paste("exp_fdac_dist_c",case,"_",GAUSSIAN,GARCH,".RData",sep="")
    en = -9999; temp1 = tryCatch(load(fn),error=function(e) print(en))
    
    for (k in 1:dim(NT)[1]){
      name = paste("cd",case,sep="_c") 
      Nid = which(Nlist==N); Tid = which(Tlist==Tobs)
      s = (Tid-1)*length(Nlist)+Nid;
      if (s<10) {
        name = paste(name,s,sep="_0")
      } else {
        name = paste(name,s,sep="_") 
      }
      results_g2_1 = get(name)[1:4,]
      
      Tobs = NT[k,1] 
      N = NT[k,2]
      tm = Tobs-1
      
      #### Calculate bias, RMSE, size and powers for categorical distribution parameters
      if (tm>4) {
        dp[k,1] = mean(results_g2_1[1,results_g2_1[1,]==TRUE])
        phi1_bias[k,1] = Bias(as.matrix(results_g2_1[2,results_g2_1[1,]==TRUE]),phi1)
        phi2_bias[k,1] = Bias(as.matrix(results_g2_1[3,results_g2_1[1,]==TRUE]),phi2)
        pi1_bias[k,1] = Bias(as.matrix(results_g2_1[4,results_g2_1[1,]==TRUE]),pi1)
        phi1_rmse[k,1] = RMSE(as.matrix(results_g2_1[2,results_g2_1[1,]==TRUE]),phi1)
        phi2_rmse[k,1] = RMSE(as.matrix(results_g2_1[3,results_g2_1[1,]==TRUE]),phi2)
        pi1_rmse[k,1] = RMSE(as.matrix(results_g2_1[4,results_g2_1[1,]==TRUE]),pi1)
        
      }
    }
    ################################################################################
    temp_dp = dp[,1]
    temp_bias = cbind(phi1_bias[,1],phi2_bias[,1],pi1_bias[,1])
    temp_rmse = cbind(phi1_rmse[,1],phi2_rmse[,1],pi1_rmse[,1]) 
    
    name1 = paste("d", case, sep = "_")
    name2 = paste("g_bias", case, sep = "_")
    name3 = paste("g_rmse", case, sep = "_")
    
    assign(name1, temp_dp)
    assign(name2, temp_bias)
    assign(name3, temp_rmse)
    rm(name1,name2,name3,temp_dp,temp_bias,temp_rmse)
  }
  
  #### Set Table Size
  #########################################################################
  nr = length(Tlist); rl = seq(1,nr,by=1); 
  nr2 = length(Nlist); rl2 = seq(1,nr2,by=1); Nlist2 = c("2,000", "5,000", "10,000", "50,000")
  nc = 3
  tab = matrix(,nr*(nr2+1)-1,2+nc*9) 
  tab2 = matrix(,nr*(nr2+1)-1,2+nc*9) 
  #########################################################################
  
  #### Put numbers into the respective cells
  #########################################################################
  for (rid in rl) {
    for (rid2 in rl2) {
      tab2[rid2+(rid-1)*(nr2+1),1] = Tlist[rid] # T
      tab2[rid2+(rid-1)*(nr2+1),2] = Nlist2[rid2] # N  
      
      tab[rid2+(rid-1)*(nr2+1),4:5] = cbind(g_bias_1[rid2+(rid-1)*(nr2),1],g_rmse_1[rid2+(rid-1)*(nr2),1])
      tab[rid2+(rid-1)*(nr2+1),7:8] = cbind(g_bias_1[rid2+(rid-1)*(nr2),2],g_rmse_1[rid2+(rid-1)*(nr2),2])
      tab[rid2+(rid-1)*(nr2+1),10:11] = cbind(g_bias_1[rid2+(rid-1)*(nr2),3],g_rmse_1[rid2+(rid-1)*(nr2),3])    
      
      tab[rid2+(rid-1)*(nr2+1),13:14] = cbind(g_bias_2[rid2+(rid-1)*(nr2),1],g_rmse_2[rid2+(rid-1)*(nr2),1])
      tab[rid2+(rid-1)*(nr2+1),16:17] = cbind(g_bias_2[rid2+(rid-1)*(nr2),2],g_rmse_2[rid2+(rid-1)*(nr2),2])
      tab[rid2+(rid-1)*(nr2+1),19:20] = cbind(g_bias_2[rid2+(rid-1)*(nr2),3],g_rmse_2[rid2+(rid-1)*(nr2),3])
      
      tab[rid2+(rid-1)*(nr2+1),22:23] = cbind(g_bias_3[rid2+(rid-1)*(nr2),1],g_rmse_3[rid2+(rid-1)*(nr2),1])
      tab[rid2+(rid-1)*(nr2+1),25:26] = cbind(g_bias_3[rid2+(rid-1)*(nr2),2],g_rmse_3[rid2+(rid-1)*(nr2),2])
      tab[rid2+(rid-1)*(nr2+1),28:29] = cbind(g_bias_3[rid2+(rid-1)*(nr2),3],g_rmse_3[rid2+(rid-1)*(nr2),3])
    }
  }
  #########################################################################
  
  #### Change the formats of each column
  #########################################################################
  for (col in c(4:5,7:8,10:11,13:14,16:17,19:20,22:23,25:26,28:29)) {
    v0 = tab[,col]; v1 = v0
    for (i in 1:length(v0)) {
      if (is.na(v0[i]) == 0) {
        v1[i] = format(round(v0[i], 3), nsmall = 3) #round(bias_0[i],digits=3)
      } else {
        v1[i] = ""
      }
    }
    tab2[,col] = v1; rm(v0,v1)
  }
  #########################################################################
  
  h1 = c(rep("",3),"phi_L=0.23","","","phi_H=0.57","","","pi=0.5","","","phi_L=0.11","","","phi_H=0.69","","","pi=0.5","","","phi_L=0.2","","","phi_H=0.8","","","pi=0.3","")
  h2 = c("T","n",rep(c("","Bias","RMSE"),9))
  h = rbind(h1,h2,tab2)
  rownames(h) <- NULL
  colnames(h) <- NULL
  writeData(wb,sn, x = h, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)  
  mergeCells(wb, sheet = sn, cols = 1:11, rows = 1)
  mergeCells(wb, sheet = sn, cols = 4:11, rows = 2)
  mergeCells(wb, sheet = sn, cols = 13:20, rows = 2)
  mergeCells(wb, sheet = sn, cols = 22:29, rows = 2)
  mergeCells(wb, sheet = sn, cols = 4:5, rows = 3)
  mergeCells(wb, sheet = sn, cols = 7:8, rows = 3)
  mergeCells(wb, sheet = sn, cols = 10:11, rows = 3)
  mergeCells(wb, sheet = sn, cols = 13:14, rows = 3)
  mergeCells(wb, sheet = sn, cols = 16:17, rows = 3)
  mergeCells(wb, sheet = sn, cols = 19:20, rows = 3)
  mergeCells(wb, sheet = sn, cols = 22:23, rows = 3)
  mergeCells(wb, sheet = sn, cols = 25:26, rows = 3)
  mergeCells(wb, sheet = sn, cols = 28:29, rows = 3)
  
  addStyle(wb,sn,style = center_style, rows = 2:4,cols = 1:(ncol(h)), gridExpand = T)
  addStyle(wb,sn,style = right, rows = 5:(nrow(h)+2),cols = 1:(ncol(h)), gridExpand = T)
  addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = T,stack=T)
  addStyle(wb,sn,style = bbs, rows = 2,cols = c(4:11,13:20,22:29), gridExpand = T,stack=T)
  addStyle(wb,sn,style = bbs, rows = 3,cols = c(4:5,7:8,10:11,13:14,16:17,19:20,22:23,25:26,28:29), gridExpand = T,stack=T)
  addStyle(wb,sn,style = bbs, rows = c(4),cols = 1:(ncol(h)), gridExpand = T,stack=T) 
  addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = T,stack=T)
  addStyle(wb,sn,style = lbs, rows = (nrow(h)+2),cols = 1:(ncol(h)), gridExpand = T,stack=T)
  #########################################################################
  rm(tab,tab2)
}

# Save the workbook to an Excel file
saveWorkbook(wb, file = "HetroAR_MC_FDAC_dist_parameters.xlsx",overwrite = TRUE)
cat("The MC results have been written to the excel file HetroAR_MC_FDAC_dist_parameters.xlsx.")





