function [panel] = GenRandomY(N,T,M,para,ve,cvs,GAU,GAR)


Tm = T+M+1; 
y = zeros(N,Tm); 

% initial values 
y(:,1)=0; % t=-M

% generate random coefficients
alpha_n = para(:,1); 
phi_n = para(:,2);

% generate errors
u = GenError(N,Tm,ve,cvs,GAU,GAR);


% generate panel data from t=-M+1,-M+2...,-1,0,1,...,T
for t=2:Tm
    y(:,t)=alpha_n+phi_n.*y(:,t-1)+u(:,t);
end

panel=y(:,(M+1+1):Tm); % n*T matrix

end


