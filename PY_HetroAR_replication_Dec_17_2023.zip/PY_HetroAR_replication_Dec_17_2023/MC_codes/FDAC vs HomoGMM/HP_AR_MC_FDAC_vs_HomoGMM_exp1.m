clear all;
rep = 2000;
 
% sample sizes
Nlist = [100 1000 5000];
Tlist = [4 6 10];
Nmax = max(Nlist); Tmax = max(Tlist);

% initial value t=-M0-1
M = 51; % the process starting at y_{i,-M} 
 
% random AR coefficients: phi_i = mu_phi + v_i
% v_i draws from a uniform distribution
Dlist=1;

% parameter values for uniform distributed phi_i
mu_phi = [0.4];
alist = [0, 0.3, 0.5];
 

%% Compute estimates
for GAU = 0:1
for GAR = 1
for a_id = 1:length(alist)
    a = alist(a_id);
% set seed
    rng(123987654);
    cvs = [0.6;0.2]; % coefficients for generating GARCH(1,1) effects in errors
  for r=1:rep
        ve = 0.5+0.5*chi2rnd(1,Nmax,1); % cross sectional heteroskedastic variance    
        para = GenRandomParaU(Nmax,mu_phi,a); % (alpha_n',phi_n')'
        data(:,:,r) = GenRandomY(Nmax,Tmax,M,para,ve,cvs,GAU,GAR);
   end


 for Tid = 1:length(Tlist)
        T = Tlist(Tid);
    for Nid = 1:length(Nlist)
        N = Nlist(Nid);
        s = (Tid-1)*length(Nlist)+Nid;
    
    if T==4    
    for r = 1:rep
    % get a panel with the respective sample size
    panel=data(1:N,1:T,r); % N*T panel
    
    % MM 
    [thetahat,se_GMM_hp] = GMM_hp_ar1(panel);
    m1_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(1);se_GMM_hp(1)];
    m1_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(2);se_GMM_hp(2)];

    % AH, FDLS, AAH, and AAH_OCMT 
    [phihat, se] = AHestim(panel);
    m1_rep_AH(((s-1)*3+1):((s-1)*3+2),r,a_id) = [phihat;se]; 
    [phihat_1, se_1, KAH_1] = FDLSestim(panel);
    m1_rep_FDLS(((s-1)*3+1):((s-1)*3+3),r,a_id) = [phihat_1;se_1;KAH_1]; 
    [phihat_2, se_2, KAH_2] = AAHestim(panel);
    m1_rep_AAH(((s-1)*3+1):((s-1)*3+3),r,a_id) = [phihat_2;se_2;KAH_2];  
    [phihat_3, se_3, KAH_3] = AAH_OCMTestim(panel);
    m1_rep_AAH_OCMT(((s-1)*3+1):((s-1)*3+3),r,a_id) = [phihat_3;se_3;KAH_3]; 

    T1 = T-1;
    K=0;
    % AB, BB
    [ coef_GMM_DIF1, coef_GMM_DIF2, coef_GMM_SYS1, coef_GMM_SYS2, var_GMM_DIF1, var_GMM_DIF2, var_GMM_SYS1, var_GMM_SYS2] = GMMestimator_ar1_v2(panel.', T1, N );

    GMM_DIF1_2step = cat(3, coef_GMM_DIF1(:,2), sqrt( diag( var_GMM_DIF1(:,:,2) ) ), sqrt( diag( var_GMM_DIF1(:,:,3) ) ) );
    GMM_SYS1_2step = cat(3, coef_GMM_SYS1(:,2), sqrt( diag( var_GMM_SYS1(:,:,2) ) ), sqrt( diag( var_GMM_SYS1(:,:,3) ) ) );
    m1_rep_AB(((s-1)*3+1):((s-1)*3+3),r,a_id) = reshape(squeeze(GMM_DIF1_2step)',(K+1)*3,1);
    m1_rep_BB(((s-1)*3+1):((s-1)*3+3),r,a_id) = reshape(squeeze(GMM_SYS1_2step)',(K+1)*3,1);

    clear thetahat se* var_GMM_hp phihat* KAH* GMM* transML
    end
    end

    if T==5 
    for r = 1:rep
    % get a panel with the respective sample size
    panel=data(1:N,1:T,r); % N*T panel
    
    % MM 
    [thetahat,se_GMM_hp,var_GMM_hp,sev] = GMM_hp_ar1(panel);
    m1_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(1);se_GMM_hp(1)];
    m1_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(2);se_GMM_hp(2)];
    m2_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(3);se_GMM_hp(3)];
    m2_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(4);se_GMM_hp(4)];
    % variance
    var_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[var_GMM_hp(1);sev(1)];
    var_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[var_GMM_hp(2);sev(2)];

    % AH, FDLS, AAH, and AAH_OCMT 
    [phihat, se] = AHestim(panel);
    m1_rep_AH(((s-1)*3+1):((s-1)*3+2),r,a_id) = [phihat;se]; 
    [phihat_1, se_1, KAH_1] = FDLSestim(panel);
    m1_rep_FDLS(((s-1)*3+1):((s-1)*3+3),r,a_id) = [phihat_1;se_1;KAH_1]; 
    [phihat_2, se_2, KAH_2] = AAHestim(panel);
    m1_rep_AAH(((s-1)*3+1):((s-1)*3+3),r,a_id) = [phihat_2;se_2;KAH_2];  
    [phihat_3, se_3, KAH_3] = AAH_OCMTestim(panel);
    m1_rep_AAH_OCMT(((s-1)*3+1):((s-1)*3+3),r,a_id) = [phihat_3;se_3;KAH_3]; 
    
    K=0;
    % AB, BB, and TMLE 
    [transML, GMM_DIF1_1step, GMM_DIF1_2step, GMM_DIF1_CUE, GMM_DIF2_1step, GMM_DIF2_2step, GMM_DIF2_CUE, GMM_SYS1_1step, GMM_SYS1_2step, GMM_SYS1_CUE,   GMM_SYS2_1step, GMM_SYS2_2step, GMM_SYS2_CUE] = ML_GMM_estimators_ar1(panel.');
    m1_rep_AB(((s-1)*3+1):((s-1)*3+3),r,a_id) = reshape(squeeze(GMM_DIF1_2step)',(K+1)*3,1);
    m1_rep_BB(((s-1)*3+1):((s-1)*3+3),r,a_id) = reshape(squeeze(GMM_SYS1_2step)',(K+1)*3,1);
    m1_rep_TMLE(((s-1)*3+1):((s-1)*3+3),r,a_id) = reshape(squeeze(transML)',(K+1)*3,1); 

    clear thetahat se* var_GMM_hp phihat* KAH* GMM* transML
    end
    end

    if T>5 
    for r = 1:rep
    % get a panel with the respective sample size
    panel=data(1:N,1:T,r); % N*T panel
    
    % MM 
    [thetahat,se_GMM_hp,var_GMM_hp,sev] = GMM_hp_ar1(panel);
    m1_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(1);se_GMM_hp(1)];
    m1_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(2);se_GMM_hp(2)];
    m2_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(3);se_GMM_hp(3)];
    m2_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(4);se_GMM_hp(4)];
    % variance
    var_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[var_GMM_hp(1);sev(1)];
    var_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[var_GMM_hp(2);sev(2)];
    % 3rd
    m3_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(5);se_GMM_hp(5)];
    m3_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(6);se_GMM_hp(6)];

    % AH, FDLS, AAH, and AAH_OCMT 
    [phihat, se] = AHestim(panel);
    m1_rep_AH(((s-1)*3+1):((s-1)*3+2),r,a_id) = [phihat;se]; 
    [phihat_1, se_1, KAH_1] = FDLSestim(panel);
    m1_rep_FDLS(((s-1)*3+1):((s-1)*3+3),r,a_id) = [phihat_1;se_1;KAH_1]; 
    [phihat_2, se_2, KAH_2] = AAHestim(panel);
    m1_rep_AAH(((s-1)*3+1):((s-1)*3+3),r,a_id) = [phihat_2;se_2;KAH_2];  
    [phihat_3, se_3, KAH_3] = AAH_OCMTestim(panel);
    m1_rep_AAH_OCMT(((s-1)*3+1):((s-1)*3+3),r,a_id) = [phihat_3;se_3;KAH_3]; 
    
    K=0;
    % AB, BB, and TMLE 
    [transML, GMM_DIF1_1step, GMM_DIF1_2step, GMM_DIF1_CUE, GMM_DIF2_1step, GMM_DIF2_2step, GMM_DIF2_CUE, GMM_SYS1_1step, GMM_SYS1_2step, GMM_SYS1_CUE,   GMM_SYS2_1step, GMM_SYS2_2step, GMM_SYS2_CUE] = ML_GMM_estimators_ar1(panel.');
    m1_rep_AB(((s-1)*3+1):((s-1)*3+3),r,a_id) = reshape(squeeze(GMM_DIF1_2step)',(K+1)*3,1);
    m1_rep_BB(((s-1)*3+1):((s-1)*3+3),r,a_id) = reshape(squeeze(GMM_SYS1_2step)',(K+1)*3,1);
    m1_rep_TMLE(((s-1)*3+1):((s-1)*3+3),r,a_id) = reshape(squeeze(transML)',(K+1)*3,1); 

    clear thetahat se* var_GMM_hp phihat* KAH* GMM* transML
    end
    end

 end
end
    clear panel para ve data Tid Nid
    fn = strcat('exp_u',num2str(a_id-1),"_",num2str(GAU),num2str(GAR),'.mat');
    save(fn);
end
end
end


