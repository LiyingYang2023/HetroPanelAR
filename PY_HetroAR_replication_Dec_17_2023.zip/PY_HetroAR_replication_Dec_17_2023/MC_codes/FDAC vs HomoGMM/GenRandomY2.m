function [panel] = GenRandomY2(N,T,M,para,ve,cvs,GAU,GAR)

y = zeros(N,T+1); 
u = zeros(N,T+1); 
e = zeros(N,T+1); 

% random coefficients
alpha_n = para(:,1); 
phi_n = para(:,2);
mu_n = alpha_n./(1-phi_n);

% initial states
m = mu_n.*(1-phi_n.^M); % mean
s = sqrt(ve.*(1-phi_n.^(2*M))./(1-phi_n.^2)); % standard deviation
y(:,1)= m+s.*normrnd(0,1,N,1); % generate random initial states of the process
dv = sqrt((1-phi_n.^(2*M))./(1-phi_n.^2));
u(:,1) = (y(:,1)-m)./dv ; 

% cross-sectonal heteroskedastic standard deviations of errors
sigma = sqrt(ve);

% coefficients for GARCH effects
cvs_n = repmat(cvs.',N,1); 


if GAU==1 && GAR==0 
    e(:,2:(T+1)) = normrnd(0,1,N,T);
    h = repmat(sigma,1,(T+1));
    u(:,2:(T+1)) = h(:,2:(T+1)).*e(:,2:(T+1));
end
if GAU==1 && GAR==1
    e(:,2:(T+1)) = normrnd(0,1,N,T);
    h = zeros(N,(T+1));
    h(:,1) = sqrt(ve); % stationary initialization
    for t = 2:(T+1)
        h(:,t) = sqrt(ve-ve.*sum(cvs)+cvs_n(:,1).*h(:,t-1).^2+cvs_n(:,2).*u(:,t-1).^2);
        u(:,t) = h(:,t).*e(:,t);    
    end
end
if GAU==0 && GAR==0
    e(:,2:(T+1)) = 1/2*(chi2rnd(2,N,T)-2);
    h = repmat(sigma,1,(T+1));
    u(:,2:(T+1)) = h(:,2:(T+1)).*e(:,2:(T+1));
end
if GAU==0 && GAR==1
    e(:,2:(T+1)) = 1/2*(chi2rnd(2,N,T)-2);
    h = zeros(N,(T+1));
    h(:,1) = sqrt(ve); % stationary initialization
    for t = 2:(T+1)
        h(:,t) = sqrt(ve-ve.*sum(cvs)+cvs_n(:,1).*h(:,t-1).^2+cvs_n(:,2).*u(:,t-1).^2);
        u(:,t) = h(:,t).*e(:,t);    
    end
end



% generate panel data from t=-M+1,-M+2...,-1,0,1,...,T
for t=2:(T+1)
    y(:,t)=alpha_n+phi_n.*y(:,t-1)+u(:,t);
end

panel=y(:,2:(T+1)); % n*T matrix

end


