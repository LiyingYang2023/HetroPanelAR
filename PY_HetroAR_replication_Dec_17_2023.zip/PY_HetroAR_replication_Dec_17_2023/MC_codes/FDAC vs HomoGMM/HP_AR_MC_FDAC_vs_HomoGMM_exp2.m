clear all;
rep = 2000;
 
% sample sizes
Nlist = [100 1000 5000];
Tlist = [4 6 10];
Nmax = max(Nlist); Tmax = max(Tlist);

% initial value t=-M0-1
Mlist = [1,2,15]; % the process starting at y_{i,-M} 
valist = [1,3,5]; % Var(alpha_i)/Var(u_it)
GAU = 1; % Gaussian errors
GAR = 0; % GARCH effects in errors
 
% random AR coefficients: phi_i = mu_phi + v_i
% v_i draws from a uniform distribution
Dlist=1;

% parameter values for uniform distributed phi_i
mu_phi = 0.4
alist = [0, 0.3, 0.5];
 

%% Compute estimates
for M_id = 1:length(Mlist)
    M = Mlist(M_id);
for va_id = 1:length(valist)
    va = valist(va_id)
for a_id = 1:length(alist)
    a = alist(a_id);
% set seed
    rng(123987654);
    cvs = [0.6;0.2]; % coefficients for generating GARCH(1,1) effects in errors
  for r=1:rep
        ve = 0.5+0.5*chi2rnd(1,Nmax,1); % cross sectional heteroskedastic variance    
        para = GenRandomParaU2(Nmax,mu_phi,a,va); % (alpha_n',phi_n')'
        data(:,:,r) = GenRandomY2(Nmax,Tmax,M,para,ve,cvs,GAU,GAR);
    end


 for Tid = 1%:length(Tlist)
        T = Tlist(Tid);
    for Nid = 1%:length(Nlist)
        N = Nlist(Nid);
        s = (Tid-1)*length(Nlist)+Nid;
    
    if T==4    
    for r = 1:rep
    % get a panel with the respective sample size
    panel=data(1:N,1:T,r); % N*T panel
    
    % MM 
    [thetahat,se_GMM_hp] = GMM_hp_ar1(panel);
    m1_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(1);se_GMM_hp(1)];
    m1_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(2);se_GMM_hp(2)];

    % AH, FDLS, AAH
    [phihat, se] = AHestim(panel);
    m1_rep_AH(((s-1)*3+1):((s-1)*3+2),r,a_id) = [phihat;se]; 
    [phihat_1, se_1] = FDLSestm(panel);
    m1_rep_FDLS(((s-1)*3+1):((s-1)*3+2),r,a_id) = [phihat_1;se_1]; 
    [phihat_2, se_2, KAH_2] = AAHestim(panel);
    m1_rep_AAH(((s-1)*3+1):((s-1)*3+3),r,a_id) = [phihat_2;se_2;KAH_2];  

    T1 = T-1;
    K=0;
    % AB, BB
    [ coef_GMM_DIF1, coef_GMM_DIF2, coef_GMM_SYS1, coef_GMM_SYS2, var_GMM_DIF1, var_GMM_DIF2, var_GMM_SYS1, var_GMM_SYS2] = GMMestimator_ar1_v2(panel.', T1, N );

    GMM_DIF1_2step = cat(3, coef_GMM_DIF1(:,2), sqrt( diag( var_GMM_DIF1(:,:,2) ) ), sqrt( diag( var_GMM_DIF1(:,:,3) ) ) );
    GMM_SYS1_2step = cat(3, coef_GMM_SYS1(:,2), sqrt( diag( var_GMM_SYS1(:,:,2) ) ), sqrt( diag( var_GMM_SYS1(:,:,3) ) ) );
    m1_rep_AB(((s-1)*3+1):((s-1)*3+3),r,a_id) = reshape(squeeze(GMM_DIF1_2step)',(K+1)*3,1);
    m1_rep_BB(((s-1)*3+1):((s-1)*3+3),r,a_id) = reshape(squeeze(GMM_SYS1_2step)',(K+1)*3,1);

    clear thetahat se* var_GMM_hp phihat* KAH* GMM* 
    end
    end

    if T==5 
    for r = 1:rep
    % get a panel with the respective sample size
    panel=data(1:N,1:T,r); % N*T panel
    
    % MM 
    [thetahat,se_GMM_hp,var_GMM_hp,sev] = GMM_hp_ar1(panel);
    m1_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(1);se_GMM_hp(1)];
    m1_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(2);se_GMM_hp(2)];
    m2_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(3);se_GMM_hp(3)];
    m2_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(4);se_GMM_hp(4)];
    % variance
    var_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[var_GMM_hp(1);sev(1)];
    var_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[var_GMM_hp(2);sev(2)];

    % AH, FDLS, AAH
    [phihat, se] = AHestim(panel);
    m1_rep_AH(((s-1)*3+1):((s-1)*3+2),r,a_id) = [phihat;se]; 
    [phihat_1, se_1] = FDLSestm(panel);
    m1_rep_FDLS(((s-1)*3+1):((s-1)*3+2),r,a_id) = [phihat_1;se_1]; 
    [phihat_2, se_2, KAH_2] = AAHestim(panel);
    m1_rep_AAH(((s-1)*3+1):((s-1)*3+3),r,a_id) = [phihat_2;se_2;KAH_2];  
    
    T1 = T-1;
    K=0;
    % AB, BB
    [ coef_GMM_DIF1, coef_GMM_DIF2, coef_GMM_SYS1, coef_GMM_SYS2, var_GMM_DIF1, var_GMM_DIF2, var_GMM_SYS1, var_GMM_SYS2] = GMMestimator_ar1_v2(panel.', T1, N );

    GMM_DIF1_2step = cat(3, coef_GMM_DIF1(:,2), sqrt( diag( var_GMM_DIF1(:,:,2) ) ), sqrt( diag( var_GMM_DIF1(:,:,3) ) ) );
    GMM_SYS1_2step = cat(3, coef_GMM_SYS1(:,2), sqrt( diag( var_GMM_SYS1(:,:,2) ) ), sqrt( diag( var_GMM_SYS1(:,:,3) ) ) );
    m1_rep_AB(((s-1)*3+1):((s-1)*3+3),r,a_id) = reshape(squeeze(GMM_DIF1_2step)',(K+1)*3,1);
    m1_rep_BB(((s-1)*3+1):((s-1)*3+3),r,a_id) = reshape(squeeze(GMM_SYS1_2step)',(K+1)*3,1);

    clear thetahat se* var_GMM_hp phihat* KAH* GMM* 
    end
    end

    if T>5 
    for r = 1:rep
    % get a panel with the respective sample size
    panel=data(1:N,1:T,r); % N*T panel
    
    % MM 
    [thetahat,se_GMM_hp,var_GMM_hp,sev] = GMM_hp_ar1(panel);
    m1_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(1);se_GMM_hp(1)];
    m1_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(2);se_GMM_hp(2)];
    m2_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(3);se_GMM_hp(3)];
    m2_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(4);se_GMM_hp(4)];
    % variance
    var_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[var_GMM_hp(1);sev(1)];
    var_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[var_GMM_hp(2);sev(2)];
    % 3rd
    m3_rep_MM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(5);se_GMM_hp(5)];
    m3_rep_GMM(((s-1)*3+1):((s-1)*3+2),r,a_id)=[thetahat(6);se_GMM_hp(6)];

    % AH, FDLS, AAH
    [phihat, se] = AHestim(panel);
    m1_rep_AH(((s-1)*3+1):((s-1)*3+2),r,a_id) = [phihat;se]; 
    [phihat_1, se_1] = FDLSestm(panel);
    m1_rep_FDLS(((s-1)*3+1):((s-1)*3+2),r,a_id) = [phihat_1;se_1]; 
    [phihat_2, se_2, KAH_2] = AAHestim(panel);
    m1_rep_AAH(((s-1)*3+1):((s-1)*3+3),r,a_id) = [phihat_2;se_2;KAH_2];  

    T1 = T-1;
    K=0;
    % AB, BB
    [ coef_GMM_DIF1, coef_GMM_DIF2, coef_GMM_SYS1, coef_GMM_SYS2, var_GMM_DIF1, var_GMM_DIF2, var_GMM_SYS1, var_GMM_SYS2] = GMMestimator_ar1_v2(panel.', T1, N );

    GMM_DIF1_2step = cat(3, coef_GMM_DIF1(:,2), sqrt( diag( var_GMM_DIF1(:,:,2) ) ), sqrt( diag( var_GMM_DIF1(:,:,3) ) ) );
    GMM_SYS1_2step = cat(3, coef_GMM_SYS1(:,2), sqrt( diag( var_GMM_SYS1(:,:,2) ) ), sqrt( diag( var_GMM_SYS1(:,:,3) ) ) );
    m1_rep_AB(((s-1)*3+1):((s-1)*3+3),r,a_id) = reshape(squeeze(GMM_DIF1_2step)',(K+1)*3,1);
    m1_rep_BB(((s-1)*3+1):((s-1)*3+3),r,a_id) = reshape(squeeze(GMM_SYS1_2step)',(K+1)*3,1);

    clear thetahat se* var_GMM_hp phihat* KAH* GMM* 
    end
    end

 end
end
    clear panel para ve data Tid Nid
end
    fn = strcat('exp_u',num2str(a_id-1),"_m",num2str(M),'_v',num2str(va),'.mat');
    save(fn);
end
end
