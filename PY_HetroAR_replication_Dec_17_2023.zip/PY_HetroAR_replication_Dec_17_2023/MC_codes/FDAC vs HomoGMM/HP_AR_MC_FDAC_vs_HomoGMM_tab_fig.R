###### FDAC estimator in Pesaran and Yang (2023) "Hetro. AR panels"
rm(list=ls())
list.of.packages <- c("parallel","parallelly","openxlsx","R.matlab","abind","sm")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
library(parallel) # mclapply
library(parallelly) # detect cores
library(openxlsx)
library(R.matlab)
library(abind)
library(sm)

rep = 2000; 
Nlist = c(100,1000,5000); Tlist = c(4,6,10)
NT = expand.grid(Nlist,Tlist); NT = cbind(NT[,2],NT[,1]);

#### Functions: calculate statistics
## (Bias, RMSE, T_test & Power, Coverage)
################################################################################
Bias = function(ests,truev) {
  ests = as.matrix(ests)
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  colMeans(ests - truematrix)
}

RMSE = function(ests,truev) {
  ests = as.matrix(ests)
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  sqrt(colMeans((ests - truematrix)^2))
}

T_test = function(truev,estsd,rep){
  ests = as.matrix(estsd[1:rep])
  sds = as.matrix(estsd[(rep+1):(2*rep)])
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  colMeans(abs((ests-truematrix)/sds)>qnorm(p = 0.975))
}

pwlb=-2.5; pwrb=2.5; pwintv=0.01;
pwgrid = length(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv)))
Power = function(truev,estsd,rep){
  h1 = as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv)) # values of alternatives (v0-0.5,v0+0.5) length = 101
  powers = sapply(h1,function(x) T_test(x,estsd,rep))
  powers
}
################################################################################

## Functions: set the format of numbers reported in each cell
## (percent, specify_decimal)
#########################################################################
percent = function(x, digits = 0, format = "f") {
  paste0(formatC(100 * x, format = format, digits = digits), "\\%")
}

specify_decimal = function(x, k) {
  trimws(format(round(x, k), nsmall=k))
}
#########################################################################

# Create a style for center-aligning the numbers
##############################################################################
center_style <- createStyle(halign = "center")
right <- createStyle(halign = "right")
left <- createStyle(halign = "left")
bbs <- createStyle(border = "bottom",borderStyle="thin")
lbs <- createStyle(border = "bottom",borderStyle="double")
tbs <- createStyle(border = "top",borderStyle="double")
wrap_text_style <- createStyle(wrapText = TRUE)

pwlb=-2.5; pwrb=2.5; pwintv=0.01;
pwgrid = length(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv)))
k=2;
##############################################################################

wb <- createWorkbook()

## Table S.3-S.8 and Figure S.5-S.6
##############################################################################
list = c('Table S.3','Table S.4','Table S.5','Table S.6','Table S.7','Table S.8')
GARCH = 1
cp = expand.grid(1:3,c(1,0))

for (cid in 1:dim(cp)[1]) {
  GAUSSIAN=cp[cid,2]
  a_id = cp[cid,1]
  df = paste("exp_u",a_id-1,'_',GAUSSIAN,GARCH,".mat",sep="")
  en = -9999; data = tryCatch(readMat(df),error=function(e) print(en))
  
  if (data[1] != en) {
    sn = list[cid]
    addWorksheet(wb, sn)
    if (cid==1) {
      writeData(wb, sn, x = "Table S.3: Bias, RMSE, and size of FDAC, FDLS, AH, AAH, AB, and BB estimators of phi (phi_0 = 0.4) in a homogeneous panel AR(1) model with Gaussian errors and GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
    }
    if (cid==2) {
      writeData(wb, sn, x = "Table S.4: Bias, RMSE, and size of FDAC, FDLS, AH, AAH, AB, and BB estimators in a heterogeneous panel AR(1) model with uniformly distributed autoregressive coeffcients, phi_i = mu_phi + v_i, mu_phi = 0.4, and v_i~IIDU(-0.3,0.3), Gaussian errors, and GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
    }
    if (cid==3) {
      writeData(wb, sn, x = "Table S.5: Bias, RMSE, and size of FDAC, FDLS, AH, AAH, AB, and BB estimators in a heterogeneous panel AR(1) model with uniformly distributed autoregressive coeffcients, phi_i = mu_phi + v_i, mu_phi = 0.4, and v_i~IIDU(-0.5,0.5), Gaussian errors, and GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
    }
    if (cid==4) {
      writeData(wb, sn, x = "Table S.6: Bias, RMSE, and size of FDAC, FDLS, AH, AAH, AB, and BB estimators of phi (phi_0 = 0.4) in a homogeneous panel AR(1) model with non-Gaussian errors and GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
    }
    if (cid==5) {
      writeData(wb, sn, x = "Table S.7: Bias, RMSE, and size of FDAC, FDLS, AH, AAH, AB, and BB estimators in a heterogeneous panel AR(1) model with uniformly distributed autoregressive coeffcients, phi_i = mu_phi + v_i, mu_phi = 0.4, and v_i~IIDU(-0.3,0.3), non-Gaussian errors, and GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
    }
    if (cid==6) {
      writeData(wb, sn, x = "Table S.8: Bias, RMSE, and size of FDAC, FDLS, AH, AAH, AB, and BB estimators in a heterogeneous panel AR(1) model with uniformly distributed autoregressive coeffcients, phi_i = mu_phi + v_i, mu_phi = 0.4, and v_i~IIDU(-0.5,0.5), non-Gaussian errors, and GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
    }
    alist = c(0,0.3,0.5)
    a = alist[a_id]
    mb = 0.4
    vb = a^(2/3)
    
    #### Create empty matrices to store bias, RMSE, etc.
    m1_bias = matrix(,dim(NT)[1],6)
    m1_rmse = matrix(,dim(NT)[1],6) 
    m1_size = matrix(,dim(NT)[1],6)
    m1_pw = matrix(,dim(NT)[1],6*pwgrid)
    
    #### Get the respective simulation results
    for (j in 1:6) {
      if (j==1) {
        mc_results = data$m1.rep.MM
      }
      if (j==2) {
        mc_results = data$m1.rep.FDLS
      }
      if (j==3) {
        mc_results = data$m1.rep.AH
      }
      if (j==4) {
        mc_results = data$m1.rep.AAH
      }
      if (j==5) {
        mc_results = data$m1.rep.AB
      }
      if (j==6) {
        mc_results = data$m1.rep.BB
      }
      
      for (ss in 1:dim(NT)[1]){ #sample size
        if (a_id==1) {
          mc_results1 = t(mc_results[((ss-1)*3+1):((ss-1)*3+2),])
        } else {
          mc_results1 = t(mc_results[((ss-1)*3+1):((ss-1)*3+2),,a_id])
        }
        
        #### Calculate bias, RMSE, size and powers for moments
        results_m1 = mc_results1[,1]
        results_m1_sd = mc_results1[,2]
        m1_bias[ss,j] = Bias(results_m1, mb)
        m1_rmse[ss,j] = RMSE(results_m1, mb)
        e1 = cbind(results_m1,results_m1_sd)
        m1_pw[ss,(pwgrid*(j-1)+1):(pwgrid*(j-1)+pwgrid)] = Power(mb,e1,rep) # length = no. alternative values
        m1_size[ss,j] = m1_pw[ss,pwgrid*(j-1)+(pwgrid-1)/2+1]; rm(e1)
      }
    }
    
    #### Figure S.5
    #########################################################################
    if (cid == 1) {
      powermm1_1 = t(m1_pw[,1:501]) # FDAC estimator
      powermm1_2 = t(m1_pw[,502:1002]) # FDLS estimator
  
      name = "Figure S.5.png"
      
      #### Define x axis by alternative values
      #####################################################################################
      truev = 0.4
      mcm = as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv))
      intv = 0.2
      #####################################################################################
      
      png(name, units="in", width=30, height=28, res=45)
      par(mai=c(3,2,2,2),xpd=TRUE, mfrow=c(2,2),oma=c(2,3,2,2)) # (b,l,t,r)
      
      #### T=4
      d1 = 201; d2= 301
      mx = mcm[d1:d2] 
      xmin = min(mx) 
      xmax = max(mx) 
      ymin = 0
      ymax = 1
      intv=0.1
      plot(mx, powermm1_1[d1:d2,1], type="l", col=1, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="T=4, n=100",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
      lines(mx, powermm1_2[d1:d2,1], type="l", col=2, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
      axis(side=1, at=round(seq(xmin, xmax, by=intv),1), mgp=c(2, 3.5, 0), cex.axis=3.5)
      axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
      arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
      arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
      mtext("power", side = 2, line = 5, at = 1 , cex = 3)
      mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)
      
      d1 = 231; d2= 271
      mx = mcm[d1:d2] 
      xmin = min(mx) 
      xmax = max(mx) 
      ymin = 0
      ymax = 1
      intv=0.1
      plot(mx, powermm1_1[d1:d2,3], type="l", col=1, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="T=4, n=5,000",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
      lines(mx, powermm1_2[d1:d2,3], type="l", col=2, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
      axis(side=1, at=seq(xmin, xmax, by=intv), mgp=c(2, 3.5, 0), cex.axis=3.5)
      axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
      arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
      arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
      mtext("power", side = 2, line = 5, at = 1 , cex = 3)
      mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)
      
      ### T=10
      d1 = 201; d2= 301
      mx = mcm[d1:d2] 
      xmin = min(mx) 
      xmax = max(mx) 
      ymin = 0
      ymax = 1
      intv=0.1
      plot(mx, powermm1_1[d1:d2,7], type="l", col=1, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="T=10, n=100",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
      lines(mx, powermm1_2[d1:d2,7], type="l", col=2, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
      axis(side=1, at=round(seq(xmin, xmax, by=intv),1), mgp=c(2, 3.5, 0), cex.axis=3.5)
      axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
      arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
      arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
      mtext("power", side = 2, line = 5, at = 1 , cex = 3)
      mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)
      
      d1 = 231; d2= 271
      mx = mcm[d1:d2] 
      xmin = min(mx) 
      xmax = max(mx) 
      ymin = 0
      ymax = 1
      intv=0.1
      plot(mx, powermm1_1[d1:d2,9], type="l", col=1, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="T=10, n=5,000",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
      lines(mx, powermm1_2[d1:d2,9], type="l", col=2, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
      axis(side=1, at=seq(xmin, xmax, by=intv), mgp=c(2, 3.5, 0), cex.axis=3.5)
      axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
      arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
      arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
      mtext("power", side = 2, line = 5, at = 1 , cex = 3)
      mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)
      
      par(fig = c(0, 1, 0, 1), oma = c(0, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)
      plot(0, 0, type = 'l', bty = 'n', xaxt = 'n', yaxt = 'n')
      legend('bottom',legend = c("FDAC", "FDLS"), lty = c(1,4),col = c(1,2), lwd = 5, xpd = TRUE, horiz = TRUE, cex = 4, seg.len=5, bty = 'n')
      
      dev.off()
    }
    #########################################################################
    
    #### Set Table Size
    #########################################################################
    nr = length(Tlist); rl = seq(1,nr,by=1); 
    nr2 = length(Nlist); rl2 = seq(1,nr2,by=1); Nlist2 = c("100","1,000","5,000")
    nc = 6
    tab = matrix(,nr*(nr2+1)-1,2+(nc+1)*3) 
    tab2 = matrix(,nr*(nr2+1)-1,2+(nc+1)*3) 
    #########################################################################
    
    #### Put numbers into the respective cells
    #########################################################################
    for (r1 in 1:nr) {
      for (r2 in 1:nr2) {
        tab2[r2+(r1-1)*(nr2+1),1] = Tlist[r1]
        tab2[r2+(r1-1)*(nr2+1),2] = Nlist2[r2]   
        tab[r2+(r1-1)*(nr2+1),4:9] = m1_bias[r2+(r1-1)*nr2,]
        tab[r2+(r1-1)*(nr2+1),11:16] = m1_rmse[r2+(r1-1)*nr2,]
        tab[r2+(r1-1)*(nr2+1),18:23] = m1_size[r2+(r1-1)*nr2,]
      }
    }
    
    #### Change the formats of each column
    for (col in c(4:9,11:16)) {
      v0 = tab[,col]; v1 = v0
      for (i in 1:length(v0)) {
        if (is.na(v0[i]) == 0) {
          v1[i] = format(round(v0[i], 3), nsmall = 3) 
        } else {
          v1[i] = ""
        }
      }
      tab2[,col] = v1; rm(v0,v1)
    }
    for (col in c(18:23)) {
      v0 = tab[,col]; v1 = v0
      for (i in 1:length(v0)) {
        if (is.na(v0[i]) == 0) {
          v1[i] = format(round(v0[i]*100, 1), nsmall = 1) 
        } else {
          v1[i] = ""
        }
      }
      tab2[,col] = v1; rm(v0,v1)
    }
    #########################################################################
    
    h1 = c("T","n",rep(c("","FDAC","FDLS","AH","AAH","AB","BB"),3))
    h = rbind(h1,tab2)
    rownames(h) <- NULL
    colnames(h) <- NULL
    writeData(wb,sn, x = h, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)
    writeData(wb, sn, x = "Bias", startCol = 4, startRow = 2, colNames = FALSE)
    writeData(wb, sn, x = "RMSE", startCol = 11, startRow = 2, colNames = FALSE)
    writeData(wb, sn, x = "Size (*100)", startCol = 18, startRow = 2, colNames = FALSE)
    mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 1)
    mergeCells(wb, sheet = sn, cols = 4:9, rows = 2)
    mergeCells(wb, sheet = sn, cols = 11:16, rows = 2)
    mergeCells(wb, sheet = sn, cols = 18:23, rows = 2)
    
    addStyle(wb,sn,style = center_style, rows = 2:3, cols = 1:(ncol(h)), gridExpand = TRUE)
    addStyle(wb,sn,style = right, rows = 4:(nrow(h)+2), cols = 2:(ncol(h)), gridExpand = TRUE)
    addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = bbs, rows = 2,cols = c(4:9,11:16,18:23), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = bbs, rows = 3,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = lbs, rows = (nrow(h)+2),cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    
    rm(df)
  } else {
    cat(paste("The MC results of ",sn," are not found.",sep=""))
  }
}
##############################################################################

name = "Figure S.6.png"
#####################################################################################
#### Define x axis by alternative values
truev = 0.4
mcm = as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv))
intv = 0.2

png(name, units="in", width=32, height=53, res=45)
GAUSSIAN = 1;
GARCH = 1;

par(mai=c(2,2,2,2),xpd=TRUE, mfrow=c(4,2),oma=c(3,3,2,2)) # (b,l,t,r)

#### Create empty matrices to store bias, RMSE, etc.
m1_bias = matrix(,dim(NT)[1],2)
m1_rmse = matrix(,dim(NT)[1],2) 
m1_size = matrix(,dim(NT)[1],2)
m1_pw = matrix(,dim(NT)[1],2*pwgrid)


#### Get the respective simulation results
for (j in 1:2) {
  a_id = 1+(j-1)*2
  a = alist[a_id]
  df = paste("exp_u",a_id-1,'_',GAUSSIAN,GARCH,".mat",sep="")
  data = readMat(df);
  mc_results = data$m1.rep.MM
  
  ####### distributions of AR(1) coefficients 
  mphi = 0.4
  vphi = a^2/3 
  
  mb = mphi; 
  vb = vphi;
  
  for (ss in 1:dim(NT)[1]){ #sample size
    if (a_id==1) {
      mc_results1 = t(mc_results[((ss-1)*3+1):((ss-1)*3+2),])
    } else {
      mc_results1 = t(mc_results[((ss-1)*3+1):((ss-1)*3+2),,a_id])
    }
    
    #### Calculate bias, RMSE, size and powers for moments
    results_m1 = mc_results1[,1]
    results_m1_sd = mc_results1[,2]
    m1_bias[ss,j] = Bias(results_m1, mb)
    m1_rmse[ss,j] = RMSE(results_m1, mb)
    e1 = cbind(results_m1,results_m1_sd)
    m1_pw[ss,(pwgrid*(j-1)+1):(pwgrid*(j-1)+pwgrid)] = Power(mb,e1,rep) # length = no. alternative values
    m1_size[ss,j] = m1_pw[ss,pwgrid*(j-1)+(pwgrid-1)/2+1]; rm(e1)
  }
}

power1 = t(m1_pw[,1:501]) # FDAC estimator
power2 = t(m1_pw[,502:1002]) # AAH estimator

#### T=4
d1 = 201; d2= 301
mx = mcm[d1:d2] 
xmin = min(mx) 
xmax = max(mx) 
ymin = 0
ymax = 1
intv=0.1
plot(mx, power1[d1:d2,1], type="l", col=1, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="Homogeneous with T=4",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
lines(mx, power1[d1:d2,2], type="l", col=2, lwd=5, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
lines(mx, power1[d1:d2,3], type="l", col=4, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
axis(side=1, at=round(seq(xmin, xmax, by=intv),1), mgp=c(2, 3.5, 0), cex.axis=3.5)
axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
mtext("power", side = 2, line = 5, at = 1 , cex = 3)
mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)

d1 = 201; d2= 301
mx = mcm[d1:d2] 
xmin = min(mx) 
xmax = max(mx) 
ymin = 0
ymax = 1
intv=0.1
plot(mx, power2[d1:d2,1], type="l", col=1, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="Heterogeneous with T=4",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
lines(mx, power2[d1:d2,2], type="l", col=2, lwd=5, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
lines(mx, power2[d1:d2,3], type="l", col=4, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
axis(side=1, at=round(seq(xmin, xmax, by=intv),1), mgp=c(2, 3.5, 0), cex.axis=3.5)
axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
mtext("power", side = 2, line = 5, at = 1 , cex = 3)
mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)


### T=10
d1 = 201; d2= 301
mx = mcm[d1:d2] 
xmin = min(mx) 
xmax = max(mx) 
ymin = 0
ymax = 1
intv=0.1
plot(mx, power1[d1:d2,4], type="l", col=1, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="Homogeneous with T=10",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
lines(mx, power1[d1:d2,5], type="l", col=2, lwd=5, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
lines(mx, power1[d1:d2,6], type="l", col=4, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
axis(side=1, at=round(seq(xmin, xmax, by=intv),1), mgp=c(2, 3.5, 0), cex.axis=3.5)
axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
mtext("power", side = 2, line = 5, at = 1 , cex = 3)
mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)


d1 = 201; d2= 301
mx = mcm[d1:d2] 
xmin = min(mx) 
xmax = max(mx) 
ymin = 0
ymax = 1
intv=0.1
plot(mx, power2[d1:d2,4], type="l", col=1, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="Heterogeneous with T=10",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
lines(mx, power2[d1:d2,5], type="l", col=2, lwd=5, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
lines(mx, power2[d1:d2,6], type="l", col=4, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
axis(side=1, at=round(seq(xmin, xmax, by=intv),1), mgp=c(2, 3.5, 0), cex.axis=3.5)
axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
mtext("power", side = 2, line = 5, at = 1 , cex = 3)
mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)


mtext("Gaussian errors", side = 3, cex = 4, font = 2,
      line = -5,
      outer = TRUE)


mtext("Non-Gaussian errors", side = 3, cex = 4, font=2,
      line = -200,
      outer = TRUE)


GAUSSIAN = 0;
GARCH = 1;
#### Create empty matrices to store bias, RMSE, etc.
m1_bias = matrix(,dim(NT)[1],2)
m1_rmse = matrix(,dim(NT)[1],2) 
m1_size = matrix(,dim(NT)[1],2)
m1_pw = matrix(,dim(NT)[1],2*pwgrid)

#### Get the respective simulation results
for (j in 1:2) {
  a_id = 1+(j-1)*2
  a = alist[a_id]
  df = paste("exp_u",a_id-1,'_',GAUSSIAN,GARCH,".mat",sep="")
  data = readMat(df);
  mc_results = data$m1.rep.MM
  
  
  ####### distributions of AR(1) coefficients 
  mphi = 0.4
  vphi = a^2/3 
  
  mb = mphi; 
  vb = vphi;
  
  for (ss in 1:dim(NT)[1]){ #sample size
    if (a_id==1) {
      mc_results1 = t(mc_results[((ss-1)*3+1):((ss-1)*3+2),])
    } else {
      mc_results1 = t(mc_results[((ss-1)*3+1):((ss-1)*3+2),,a_id])
    }
    
    #### Calculate bias, RMSE, size and powers for moments
    results_m1 = mc_results1[,1]
    results_m1_sd = mc_results1[,2]
    m1_bias[ss,j] = Bias(results_m1, mb)
    m1_rmse[ss,j] = RMSE(results_m1, mb)
    e1 = cbind(results_m1,results_m1_sd)
    m1_pw[ss,(pwgrid*(j-1)+1):(pwgrid*(j-1)+pwgrid)] = Power(mb,e1,rep) # length = no. alternative values
    m1_size[ss,j] = m1_pw[ss,pwgrid*(j-1)+(pwgrid-1)/2+1]; rm(e1)
  }
}


power1 = t(m1_pw[,1:501]) 
power2 = t(m1_pw[,502:1002]) 

#### T=4
d1 = 201; d2= 301
mx = mcm[d1:d2] 
xmin = min(mx) 
xmax = max(mx) 
ymin = 0
ymax = 1
intv=0.1
plot(mx, power1[d1:d2,1], type="l", col=1, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="Homogeneous with T=4",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
lines(mx, power1[d1:d2,2], type="l", col=2, lwd=5, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
lines(mx, power1[d1:d2,3], type="l", col=4, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
axis(side=1, at=round(seq(xmin, xmax, by=intv),1), mgp=c(2, 3.5, 0), cex.axis=3.5)
axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
mtext("power", side = 2, line = 5, at = 1 , cex = 3)
mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)


d1 = 201; d2= 301
mx = mcm[d1:d2] 
xmin = min(mx) 
xmax = max(mx) 
ymin = 0
ymax = 1
intv=0.1
plot(mx, power2[d1:d2,1], type="l", col=1, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="Heterogeneous with T=4",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
lines(mx, power2[d1:d2,2], type="l", col=2, lwd=5, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
lines(mx, power2[d1:d2,3], type="l", col=4, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
axis(side=1, at=round(seq(xmin, xmax, by=intv),1), mgp=c(2, 3.5, 0), cex.axis=3.5)
axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
mtext("power", side = 2, line = 5, at = 1 , cex = 3)
mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)


### T=10
d1 = 201; d2= 301
mx = mcm[d1:d2] 
xmin = min(mx) 
xmax = max(mx) 
ymin = 0
ymax = 1
intv=0.1
plot(mx, power1[d1:d2,4], type="l", col=1, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="Homogeneous with T=10",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
lines(mx, power1[d1:d2,5], type="l", col=2, lwd=5, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
lines(mx, power1[d1:d2,6], type="l", col=4, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
axis(side=1, at=round(seq(xmin, xmax, by=intv),1), mgp=c(2, 3.5, 0), cex.axis=3.5)
axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
mtext("power", side = 2, line = 5, at = 1 , cex = 3)
mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)


d1 = 201; d2= 301
mx = mcm[d1:d2] 
xmin = min(mx) 
xmax = max(mx) 
ymin = 0
ymax = 1
intv=0.1
plot(mx, power2[d1:d2,4], type="l", col=1, lwd=5, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="Heterogeneous with T=10",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
lines(mx, power2[d1:d2,5], type="l", col=2, lwd=5, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
lines(mx, power2[d1:d2,6], type="l", col=4, lwd=5, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
axis(side=1, at=round(seq(xmin, xmax, by=intv),1), mgp=c(2, 3.5, 0), cex.axis=3.5)
axis(side=2, at=seq(0, 1, by=intv), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
mtext("power", side = 2, line = 5, at = 1 , cex = 3)
mtext("5%", side = 1, line = -5, at = xmax , cex = 2.5)


par(fig = c(0, 1, 0, 1), oma = c(0, 0, 0, 0), mar = c(1, 0, 0, 0), new = TRUE)
plot(0, 0, type = 'l', bty = 'n', xaxt = 'n', yaxt = 'n')
legend('bottom',legend = c("n=100", "n=1,000", "n=5,000"), lty = c(4,2,1),col = c(1,2,4), lwd = 5, xpd = TRUE, horiz = TRUE, cex = 5, seg.len=5, bty = 'n')

dev.off()
##############################################################################

## Table S.11-S.19
##############################################################################
tab_list = c('Table S.11','Table S.12','Table S.13','Table S.14','Table S.15','Table S.16','Table S.17','Table S.18','Table S.19')
rep = 2000; 
Nlist = c(100,1000,5000); Tlist = c(4,6,10)
NT = expand.grid(Nlist,Tlist); NT = cbind(NT[,2],NT[,1]);

GAUSSIAN=1; 
GARCH=0; 

alist = c(0,0.3,0.5);
Mlist = c(1,2,15);

stat = c("bias","rmse","size")
Stat = c("Bias","RMSE","Size")

#### Get the respective simulation results
mphi = 0.4
for (a_id in 1:length(alist)) {
  a = alist[a_id]
  vphi = a^2/3
  mb = mphi; vb = vphi
  
  #### Create empty matrices to store bias, RMSE, etc.
  ################################################################################
  m1_bias = matrix(,dim(NT)[1]*3,3*6)
  m1_rmse = matrix(,dim(NT)[1]*3,3*6) 
  m1_size = matrix(,dim(NT)[1]*3,3*6)
  m1_pw = matrix(,dim(NT)[1]*3,3*pwgrid*6)
  ################################################################################
  
  ### Different degrees of non-stationarity of initialization
  for (m in 1:3) {
    m0 = Mlist[m]
    for (v2 in c(1,2,3)) {
      vl = c(1,3,5)
      v=vl[v2]
      
      ## Load simulation results of an experiment
      ################################################################################
      name = paste("exp_u",a_id-1,"_m",m0,"_v",v,".mat",sep="")
      data = readMat(name); attach(data);
      ################################################################################
      
      for (j in 1:6) {
        name1 = "m1.rep"
        ## Load simulation results of an estimator
        ################################################################################
        if (j==1) {
          name2 = paste(name1,"MM",sep=".")
        }
        if (j==2) {
          name2 = paste(name1,"FDLS",sep=".")
        }
        if (j==3) {
          name2 = paste(name1,"AH",sep=".")
        }
        if (j==4) {
          name2 = paste(name1,"AAH",sep=".")
        }
        if (j==5) {
          name2 = paste(name1,"AB",sep=".")
        }
        if (j==6) {
          name2 = paste(name1,"BB",sep=".")
        }
        mc_results = get(name2);rm(name1,name2)
        ################################################################################
        
        for (ss in 1:dim(NT)[1]){ #sample size
          if (a_id==1) {
            mc_results1 = t(mc_results[((ss-1)*3+1):((ss-1)*3+2),])
          }
          if (a_id %in% c(2,3)) {
            mc_results1 = t(mc_results[((ss-1)*3+1):((ss-1)*3+2),,a_id])
          }
          
          #### Calculate bias, RMSE, size and powers for moments
          ################################################################################
          results_m1 = mc_results1[,1]
          results_m1_sd = mc_results1[,2]
          m1_bias[ss+dim(NT)[1]*(m-1),v2+(j-1)*3] = Bias(results_m1, mb)
          m1_rmse[ss+dim(NT)[1]*(m-1),v2+(j-1)*3] = RMSE(results_m1, mb)
          e1 = cbind(results_m1,results_m1_sd)
          m1_pw[ss+dim(NT)[1]*(m-1),(pwgrid*(v2+(j-1)*3-1)+1):(pwgrid*(v2+(j-1)*3-1)+pwgrid)] = Power(mb,e1,rep) # length = no. alternative values
          m1_size[ss+dim(NT)[1]*(m-1),v2+(j-1)*3] = m1_pw[ss+dim(NT)[1]*(m-1),pwgrid*(v2+(j-1)*3-1)+(pwgrid-1)/2+1]; rm(e1)
          ################################################################################
        }
        
      }
      rm(data)
    }
    
  }
  
  ### Different statistics reported: bias, RMSE, and size (*100)
  for (s in 1:3) {
    name = paste("m1_",stat[s],sep="")
    temp = get(name);rm(name)
    
    #### Set Table Size
    #########################################################################
    nr = length(Tlist); rl = seq(1,nr,by=1); 
    nr2 = length(Nlist); rl2 = seq(1,nr2,by=1); Nlist2 = c("100","1,000","5,000")
    nc = 6
    tab = matrix(,(nr*(nr2+1))*3-1,4+nc*4-1) 
    tab2 = matrix(,(nr*(nr2+1))*3-1,4+nc*4-1) 
    #########################################################################
    
    #### Put numbers into the respective cells
    #########################################################################
    for (r1 in 1:nr) {
      for (r2 in 1:nr2) {
        for (j in 1:6) {
          tab[r2+(r1-1)*(nr2+1),(5+(j-1)*4):(7+(j-1)*4)] = temp[r2+(r1-1)*nr2,(1+(j-1)*3):(3+(j-1)*3)]
          tab[r2+(r1-1)*(nr2+1)+1*(nr*(nr2+1)),(5+(j-1)*4):(7+(j-1)*4)] = temp[r2+(r1-1)*nr2+1*(nr*nr2),(1+(j-1)*3):(3+(j-1)*3)]
          tab[r2+(r1-1)*(nr2+1)+2*(nr*(nr2+1)),(5+(j-1)*4):(7+(j-1)*4)] = temp[r2+(r1-1)*nr2+2*(nr*nr2),(1+(j-1)*3):(3+(j-1)*3)]
        }
      }
    } 
    #########################################################################
    
    #### Change the formats of each row
    #########################################################################
    if (s<3) { # Bias and RMSE
      for (row in c(1:11,13:23,25:35)) {
        v0 = tab[row,]; v1 = v0
        for (i in 1:length(v0)) {
          if (is.na(v0[i]) == 0) {
            v1[i] = format(round(v0[i], 3), nsmall = 3) 
          } else {
            v1[i] = ""
          }
        }
        tab2[row,] = v1; rm(v0,v1)
      }
    }
    if (s==3) { # Size 
      for (row in c(1:11,13:23,25:35)) {
        v0 = tab[row,]; v1 = v0
        for (i in 1:length(v0)) {
          if (is.na(v0[i]) == 0) {
            v1[i] = format(round(v0[i]*100, 1), nsmall = 1)
          } else {
            v1[i] = ""
          }
        }
        tab2[row,] = v1; rm(v0,v1)
      }
    }
    for (r1 in 1:nr) {
      for (r2 in 1:nr2) {
        tab2[r2+(r1-1)*(nr2+1),2] = Tlist[r1] # Tobs
        tab2[r2+(r1-1)*(nr2+1),3] = Nlist2[r2]   # nobs
        
        tab2[r2+(r1-1)*(nr2+1)+1*(nr*(nr2+1)),2] = Tlist[r1]
        tab2[r2+(r1-1)*(nr2+1)+1*(nr*(nr2+1)),3] = Nlist2[r2]  
        
        tab2[r2+(r1-1)*(nr2+1)+2*(nr*(nr2+1)),2] = Tlist[r1]
        tab2[r2+(r1-1)*(nr2+1)+2*(nr*(nr2+1)),3] = Nlist2[r2]   
      }
    } 
    #########################################################################
    
    sn = tab_list[(a_id-1)*3+s]
    addWorksheet(wb, sn)
    #########################################################################
    if (a_id==1) {
      h2 = c("","T","n/kappa^2",rep(c("","1","3","5"),6))
      if (s==1) {
        writeData(wb, sn, x = "Table S.11: Bias of FDAC, FDLS, AH, AAH, AB, and BB estimators of phi_0 = 0.4 in a homogeneous panel AR(1) model for different degrees of non-stationarity of initialization M and kappa^2 = Var(alpha_i)/Var(u_it)", startCol = 1, startRow = 1, colNames = FALSE)
        writeData(wb, sn, x = "Bias", startCol = 5, startRow = 2, colNames = FALSE)
      }
      if (s==2) {
        writeData(wb, sn, x = "Table S.12: RMSE of FDAC, FDLS, AH, AAH, AB, and BB estimators of phi_0 = 0.4 in a homogeneous panel AR(1) model for different degrees of non-stationarity of initialization M and kappa^2 = Var(alpha_i)/Var(u_it)", startCol = 1, startRow = 1, colNames = FALSE)
        writeData(wb, sn, x = "RMSE", startCol = 5, startRow = 2, colNames = FALSE)
      }
      if (s==3) {
        writeData(wb, sn, x = "Table S.13: Size of FDAC, FDLS, AH, AAH, AB, and BB estimators of phi_0 = 0.4 in a homogeneous panel AR(1) model for different degrees of non-stationarity of initialization M and kappa^2 = Var(alpha_i)/Var(u_it)", startCol = 1, startRow = 1, colNames = FALSE)
        writeData(wb, sn, x = "Size (*100)", startCol = 5, startRow = 2, colNames = FALSE)
      }
    }
    if (a_id==2) {
      h2 = c("","T","n/kappa^2",rep(c("","1.03","3.03","5.03"),6))
      if (s==1) {
        writeData(wb, sn, x = "Table S.14: Bias of FDAC, FDLS, AH, AAH, AB, and BB estimators in a heterogeneous panel AR(1) model for different degrees of non-stationarity of initialization M and kappa^2 = Var(phi_i)/Var(u_it) with phi_i = mu_phi + v-i, mu_phi = 0.4, and v_i~IIDU(-0.3,0.3)", startCol = 1, startRow = 1, colNames = FALSE)
        writeData(wb, sn, x = "Bias", startCol = 5, startRow = 2, colNames = FALSE)
      }
      if (s==2) {
        writeData(wb, sn, x = "Table S.15: RMSE of FDAC, FDLS, AH, AAH, AB, and BB estimators in a heterogeneous panel AR(1) model for different degrees of non-stationarity of initialization M and kappa^2 = Var(phi_i)/Var(u_it) with phi_i = mu_phi + v-i, mu_phi = 0.4, and v_i~IIDU(-0.3,0.3)", startCol = 1, startRow = 1, colNames = FALSE)
        writeData(wb, sn, x = "RMSE", startCol = 5, startRow = 2, colNames = FALSE)
      }
      if (s==3) {
        writeData(wb, sn, x = "Table S.16: Size of FDAC, FDLS, AH, AAH, AB, and BB estimators in a heterogeneous panel AR(1) model for different degrees of non-stationarity of initialization M and kappa^2 = Var(phi_i)/Var(u_it) with phi_i = mu_phi + v-i, mu_phi = 0.4, and v_i~IIDU(-0.3,0.3)", startCol = 1, startRow = 1, colNames = FALSE)
        writeData(wb, sn, x = "Size (*100)", startCol = 5, startRow = 2, colNames = FALSE)
      }
    }
    if (a_id==3) {
      h2 = c("","T","n/kappa^2",rep(c("","1.083","3.083","5.083"),6))
      if (s==1) {
        writeData(wb, sn, x = "Table S.17: Bias of FDAC, FDLS, AH, AAH, AB, and BB estimators in a heterogeneous panel AR(1) model for different degrees of non-stationarity of initialization M and kappa^2 = Var(phi_i)/Var(u_it) with phi_i = mu_phi + v-i, mu_phi = 0.4, and v_i~IIDU(-0.5,0.5)", startCol = 1, startRow = 1, colNames = FALSE)
        writeData(wb, sn, x = "Bias", startCol = 5, startRow = 2, colNames = FALSE)
      }
      if (s==2) {
        writeData(wb, sn, x = "Table S.18: RMSE of FDAC, FDLS, AH, AAH, AB, and BB estimators in a heterogeneous panel AR(1) model for different degrees of non-stationarity of initialization M and kappa^2 = Var(phi_i)/Var(u_it) with phi_i = mu_phi + v-i, mu_phi = 0.4, and v_i~IIDU(-0.5,0.5)", startCol = 1, startRow = 1, colNames = FALSE)
        writeData(wb, sn, x = "RMSE", startCol = 5, startRow = 2, colNames = FALSE)
      }
      if (s==3) {
        writeData(wb, sn, x = "Table S.19: Size of FDAC, FDLS, AH, AAH, AB, and BB estimators in a heterogeneous panel AR(1) model for different degrees of non-stationarity of initialization M and kappa^2 = Var(phi_i)/Var(u_it) with phi_i = mu_phi + v-i, mu_phi = 0.4, and v_i~IIDU(-0.5,0.5)", startCol = 1, startRow = 1, colNames = FALSE)
        writeData(wb, sn, x = "Size (*100)", startCol = 5, startRow = 2, colNames = FALSE)
      }
    }
    #########################################################################
    
    tab2[,1] = c(rep("",5),"M=1",rep("",11),"M=2",rep("",11),"M=15",rep("",5))
    h1 = c(rep("",4),"FDAC",rep("",3),"FDLS",rep("",3),"AH",rep("",3),"AAH",rep("",3),"AB",rep("",3),"BB",rep("",2))
    h = rbind(h1,h2,tab2)
    rownames(h) <- NULL
    colnames(h) <- NULL
    writeData(wb,sn, x = h, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)
    mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 1)
    mergeCells(wb, sheet = sn, cols = 5:ncol(h), rows = 2)
    mergeCells(wb, sheet = sn, cols = 5:7, rows = 3)
    mergeCells(wb, sheet = sn, cols = 9:11, rows = 3)
    mergeCells(wb, sheet = sn, cols = 13:15, rows = 3)
    mergeCells(wb, sheet = sn, cols = 17:19, rows = 3)
    mergeCells(wb, sheet = sn, cols = 21:23, rows = 3)
    mergeCells(wb, sheet = sn, cols = 25:27, rows = 3)
    
    addStyle(wb,sn,style = center_style, rows = 2:4, cols = 1:(ncol(h)), gridExpand = TRUE)
    addStyle(wb,sn,style = right, rows = 5:(nrow(h)+2), cols = 2:(ncol(h)), gridExpand = TRUE)
    addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = bbs, rows = 2,cols = 5:ncol(h), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = bbs, rows = 3,cols = c(5:7,9:11,13:15,17:19,21:23,25:27), gridExpand = T,stack=TRUE)
    addStyle(wb,sn,style = bbs, rows = c(4,15,16,27,28),cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)    
    addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = lbs, rows = (nrow(h)+2),cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
  }
}
##############################################################################

# Save the workbook to an Excel file
saveWorkbook(wb, file = "HetroAR_MC_FDAC_vs_HomoGMM_results.xlsx",overwrite = TRUE)
cat("The MC results have been written to the excel file HetroAR_MC_FDAC_vs_HomoGMM_results.xlsx.")
##############################################################################