function [phihat,se]=FDLSestm(Y)

%% input data

Y = Y.'; %Y is (T+1) x n matrix
dy = Y(2:end,:)-Y(1:end-1,:);
[T,n] = size(dy);

% sample moments
mi = zeros(2,n); % sample moments h=0,1

for i =  1:n
    mi(1,i) = mean(dy(1:(T-1),i).*dy(1:(T-1),i)); % average over time
    mi(2,i) = mean(2*dy(2:T,i).*dy(1:(T-1),i)+ dy(1:(T-1),i).*dy(1:(T-1),i)); % average over time
end

% sample moments average across i
  m = mean(mi,2); % h=0,1

% FDLS
  phihat = m(2)/m(1); 
  mms1 = mean((mi(2,:)-phihat.*mi(1,:)).^2); 
  avar = mean(mi(1,:))^(-2)*mms1; % estimated asymptotic variance
  se = (avar/n)^0.5;

return 



