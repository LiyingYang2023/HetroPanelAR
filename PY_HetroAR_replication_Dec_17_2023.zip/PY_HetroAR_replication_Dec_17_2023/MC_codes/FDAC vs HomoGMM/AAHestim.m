function [phihat, se,K]=AAHestim(Y)
%Y is N x T+1
dy=Y(:,1:end-1)-Y(:,2:end);
[N,T]=size(dy);

%% estimations
K=(T-2)*(T-1)/2+(T-2); % number of moment conditions

wqm=ones(T-2,1)/(T-2);
wah=ones((T-2)*(T-1)/2,1)/ ((T-2)*(T-1)/2);
w1=[0.5*wah', 0.5*wqm']';

% define Sample Moment Conditions
%m=m0-phi*m1+pji*m2
m0=zeros(K,1); m0i=zeros(K,N); 
m1=zeros(K,1); m1i=zeros(K,N); 
m2=zeros(K,1); m2i=zeros(K,N); 

k=0;
for s=2:T-1
    for t=s+1:T
        k=k+1;
        % moment dy_i,t-s * (dy_i,t-phi* dy_i,t-1)
        m0i(k,:)=dy(:,t-s).*dy(:,t);
        m1i(k,:)=dy(:,t-s).*dy(:,t-1);
        m0(k,1)=sum(dy(:,t-s).*dy(:,t))/N;
        m1(k,1)=sum(dy(:,t-s).*dy(:,t-1))/N;
    end
end
% now augment with BMM moments

for t=2:T-1
    k=k+1;
    m0i(k,:)=dy(:,t).*dy(:,t-1)+dy(:,t).*dy(:,t)+dy(:,t+1).*dy(:,t);
    m0(k,1)=m0i(k,:)*ones(N,1)/N;
    m1i(k,:)=dy(:,t-1).*dy(:,t-1)+2*dy(:,t).*dy(:,t-1)+dy(:,t).*dy(:,t);
    m1(k,1)=m1i(k,:)*ones(N,1)/N;
    m2i(k,:)=dy(:,t-1).*dy(:,t-1);
    m2(k,1)=m2i(k,:)*ones(N,1)/N;
end


W1=w1*w1';

Dtmnt=(w1'*m1)^2-4*(w1'*m2)*(w1'*m0);
if Dtmnt>=0
    x1=(w1'*m1+Dtmnt^0.5)/2/(w1'*m2);
    x2=(w1'*m1-Dtmnt^0.5)/2/(w1'*m2);
    % now select root
    a1=m0-x1*m1+x1^2*m2;
    a2=m0-x2*m1+x2^2*m2;
    na1=a1'*a1;
    na2=a2'*a2;
    if na1<na2
        phi_1step=x1;
    else
        phi_1step=x2;
    end
end
if Dtmnt<0
    phi_1step=w1'*m1/(w1'*m2)/2;
end



% 2-step estimator

S=zeros(K,K); sm=zeros(K,1);
Sa=zeros(K,K); Sb=zeros(K,K); Sc=zeros(K,K); Sd=zeros(K,K); Se=zeros(K,K);
A=zeros(N,K);
for i=1:N
   a=m0i(:,i)-phi_1step*m1i(:,i)+(phi_1step^2)*m2i(:,i);
   Si= a*a';
   sm=sm+a/N;
   A(i,:)=a';
   S=S+Si;
end
S1=S/N;


W2=pinv(S1-sm*sm');
W=W2;
if abs(phi_1step)<1
    stphi=phi_1step;
else
    stphi=0;
end
os = optimset('LargeScale','off','MaxFunEvals',10^5,'MaxIter',10^5,'TolX',1e-8);
options = optimset('Display','off', 'TolX',1e-6);%

str=evalc('[para,obj,ef, output]=fminunc(@objg_12step,stphi,options,m0,m1,m2, W)');
phi_2step=para;


% now asymptotic variance
D1=-m1+2*phi_1step*m2;
av_1step=pinv(D1'*W1*D1)*D1'*W1*S1*W1'*D1*pinv(D1'*W1*D1);
D2=-m1+2*phi_2step*m2;
av_2step=pinv(D2'*pinv(S1)*D2);
 


%% now report results
se=(av_2step/N)^0.5;
phihat=phi_2step;

return % function


%% declare functions

function obj=objg_12step(phi,m0,m1, m2, W)

% get params from psi
m=m0-phi*m1+phi*phi*m2;

obj=m'*W*m;

return

