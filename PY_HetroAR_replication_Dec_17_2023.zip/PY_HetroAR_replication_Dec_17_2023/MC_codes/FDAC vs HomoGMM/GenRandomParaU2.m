function [para] = GenRandomParaU2(N,mu_phi,a,va)
    phi_n = mu_phi+unifrnd(-a,a,N,1);
    alpha_n=phi_n+normrnd(0,sqrt(va),N,1);
    para = [alpha_n,phi_n];
end