function [u] = GenError(N,Tm,ve,cvs,GAU,GAR)


sigma = sqrt(ve);
sigma_n = repmat(sigma,1,Tm);
% coefficients to generate GARCH effects
cvs_n = repmat(cvs.',N,1); 

u = zeros(N,Tm ); 
e = zeros(N,Tm ); 

if GAU==1 && GAR==0 
    e(:,2:(Tm)) = normrnd(0,1,N,Tm-1);
    h = repmat(sigma,1,(Tm));
    u(:,2:(Tm)) = h(:,2:(Tm)).*e(:,2:(Tm));
end
if GAU==1 && GAR==1
    e(:,2:(Tm)) = normrnd(0,1,N,Tm-1);
    h = zeros(N,(Tm));
    %h(:,1) = 0; % stationary initialization
    for t = 2:(Tm)
        h(:,t) = sqrt(ve-ve.*sum(cvs)+cvs_n(:,1).*h(:,t-1).^2+cvs_n(:,2).*u(:,t-1).^2);
        u(:,t) = h(:,t).*e(:,t);    
    end
end
if GAU==0 && GAR==0
    e(:,2:(Tm)) = 1/2*(chi2rnd(2,N,(Tm-1))-2);
    h = repmat(sigma,1,(Tm));
    u(:,2:(Tm)) = h(:,2:(Tm)).*e(:,2:(Tm));
end
if GAU==0 && GAR==1
    e(:,2:(Tm)) = 1/2*(chi2rnd(2,N,(Tm-1))-2);
    h = zeros(N,(Tm));
    %h(:,1) = sqrt(ve); % stationary initialization
    for t = 2:(Tm)
        h(:,t) = sqrt(ve-ve.*sum(cvs)+cvs_n(:,1).*h(:,t-1).^2+cvs_n(:,2).*u(:,t-1).^2);
        u(:,t) = h(:,t).*e(:,t);    
    end
end

u(:,2:Tm);

end