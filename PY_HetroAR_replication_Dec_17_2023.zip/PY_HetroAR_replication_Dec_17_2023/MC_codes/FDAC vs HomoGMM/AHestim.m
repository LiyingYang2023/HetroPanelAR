function [phihat, se,K]=AHestim(Y)

%Y is N x T+1
dy=Y(:,1:end-1)-Y(:,2:end);
[N,T]=size(dy);
Ts = T+1;

%% estimations
K=(Ts-3)*(Ts-2)/2; % number of moment conditions

% define Sample Moment Conditions
%m=m0-phi*m1
m0=zeros(K,1); m0i=zeros(K,N);
m1=zeros(K,1); m1i=zeros(K,N);
k=0;
dY=dy;
% for s=2:T-1
%     for t=s+1:T
%         k=k+1;
%         % moment dy_i,t-s * (dy_i,t-phi* dy_i,t-1)
%         m0i(k,:)=dy(:,t-s).*dy(:,t);
%         m1i(k,:)=dy(:,t-s).*dy(:,t-1);
%         m0(k,1)=sum(dy(:,t-s).*dy(:,t))/N;
%         m1(k,1)=sum(dy(:,t-s).*dy(:,t-1))/N;
%     end
% end
S=zeros(K,K);
pom=[zeros(Ts-3,1), eye(Ts-3,Ts-4)];
H=eye(Ts-3)*2-pom-pom';

for i=1:N
    % get Zi
       Zi=zeros(Ts-3,K);
       h=1;
       for r=1:Ts-3
            s=r;
            Zi(r,h:h+s-1)=dY(i,1:s);
            h=h+r;
       end
    
    S=S+Zi'*H*Zi/N;
    m1=m1 + (dY(i,2:Ts-2)*Zi/N)';
    m0=m0   + (dY(i,3:Ts-1)*Zi/N)';
    
    m0i(:,i)=dY(i,3:Ts-1)*Zi;
    m1i(:,i)=dY(i,2:Ts-2)*Zi;
end

W1=pinv(S);


% 
% w1=Wo.ah1;
% W1=w1*w1'; %

% 1-step estimator
phi_1step=  m0'*W1*m1 / (m1'*W1*m1);
%phi_1step=w1'*m0/(w1'*m1);

% 2-step estimator
S2=zeros(K,K);
Sa=zeros(K,K); Sb=zeros(K,K); Sc=zeros(K,K);
A=zeros(N,K);
vm=zeros(K,1);
for i=1:N
   a=m0i(:,i)-phi_1step*m1i(:,i);
   Si= a*a';
   A(i,:)=a';
   vm=vm+a/N;
   S2=S2+Si;
   Sia=m0i(:,i)*m0i(:,i)';
   Sib=-m0i(:,i)*m1i(:,i)'-m1i(:,i)*m0i(:,i)';
   Sic=m1i(:,i)*m1i(:,i)';
   Sa=Sa+Sia;
   Sb=Sb+Sib;
   Sc=Sc+Sic;
end
S2=S2/N;
Sa=Sa/N;
Sb=Sb/N;
Sc=Sc/N;
%Salt=Sa+phi_1step*Sb+(phi_1step^2)*Sc;

% if K<N
    W2=pinv(S2-vm*vm');
%   w2=W2*m1/(sum(W2*m1));
    phi_2step=m0'*W2*m1 / (m1'*W2*m1);
% else
%     phi_2step=NaN;
%     W2=NaN(size(S1));
% end


% % rerd - estimate S1
%  S1d=mt_est(A, 0.05, 2);
%  W2d=pinv(S1d);
%  phi_2d=m0'*W2d*m1 / (m1'*W2d*m1);

% % rer2sa
%   p=K/(N^0.5+K-1);
%   wo=pinv(S2)*m1;
%   wos=sum(wo);
%   wo=wo/wos;
%   [~,ind]=min(abs(Wo.phi_range-phi_1step));
%   ws=Wo.ah{ind};
%   wa=(1-p)*wo+p*ws;
%   phi_2stepa= wa'*m0/(wa'*m1); 
% 
%  % rer2sb
%   lambda=K/(N^0.5);
%   [~,ind]=min(abs(Wo.phi_range-phi_1step));
%   ws=Wo.ah{ind};
%   sc=mean(diag(S1'*S1));
%   d=-m1;
%   sc2=sum(pinv(S1)*d);
%   wb=inv(S1'*S1+lambda*sc*eye(K))*(S1'*d/sc2+lambda*sc*ws);
%   phi_2stepb= wb'*m0/(wb'*m1); 
% 
%   
% % CU estimator
% os = optimset('LargeScale','off','MaxFunEvals',10^5,'MaxIter',10^5,'TolX',1e-8);
% options = optimset('Display','off', 'TolX',1e-6);%
% lq = -2;
% uq = 2;
% if abs(phi_1step)<1
%     stphi=phi_1step;
% else
%     stphi=0;
% end
% str=evalc('[para,obj,ef, output]=fminunc(@objg,stphi,options,m0,m1,Sa, Sb, Sc)');
% 
% phi_cu=para;
% 

% now asymptotic variance
D=-m1;
av_1step=pinv(D'*W1*D)*D'*W1*S2*W1'*D*pinv(D'*W1*D);
av_2step=pinv(D'*pinv(S2)*D);
% %av_2dstep=pinv(D'*pinv(S1d)*D);
% Scu=Sa+phi_cu*Sb+(phi_cu^2)*Sc;
% 
% av_2stepa=(wa'*S1*wa)/((wa'*d)^2);
% av_2stepb=(wb'*S1*wb)/((wb'*d)^2);
% 
% av_cu=pinv(D'*pinv(Scu)*D);

%% now report results
se=(av_2step/N)^0.5;
phihat=phi_2step;

return

%% declare functions

function obj=objg(phi,m0,m1, Sa, Sb, Sc)

% get params from psi
m=m0-phi*m1;
S=Sa+phi*Sb+(phi^2)*Sc;

obj=m'*pinv(S)*m;

return
