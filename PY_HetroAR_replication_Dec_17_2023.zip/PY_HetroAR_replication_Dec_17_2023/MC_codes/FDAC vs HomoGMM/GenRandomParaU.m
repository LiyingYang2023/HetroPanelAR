function [para] = GenRandomPara(N,mu_phi,a)
    phi_n = mu_phi+unifrnd(-a,a,N,1);
    alpha_n=phi_n+normrnd(0,1,N,1);
    para = [alpha_n,phi_n];
end