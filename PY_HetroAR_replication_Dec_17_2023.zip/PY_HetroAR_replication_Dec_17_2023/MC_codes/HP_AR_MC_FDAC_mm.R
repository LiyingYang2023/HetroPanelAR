#### FDAC and HetroGMM estimators proposed in Pesaran and Yang (2023) "Hetro. AR panels"
rm(list=ls())
list.of.packages <- c("parallel","parallelly","openxlsx")
new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages)
library(parallel) # mclapply
library(parallelly) # detect cores
library(openxlsx)

rep = 2000 # number of replications in each loop
reps = 1:rep
NumPara = 3
Nlist = c(100,200,500,1000,5000); Tlist = c(4,5,6,8,10); 
Nmax = max(Nlist); Tmax = max(Tlist)
NT = expand.grid(Nlist,Tlist); NT = cbind(NT[,2],NT[,1])
M0=50 
set.seed(123987654) 

# parameters of AR(1) coefficients
mphi_l = c(0.4,0.4,0.62,0.475,0.62) # mean
p3 = c(0.3,0.5,0.2,0,0) 
p4 = c(0,  0,  0.8,0,0)
p5 = c(0,  0,  0.3,0,0)
vphi_l = c(p3[1]^(2/3),p3[2]^(2/3),(p3[3]^2*p5[3]+p4[3]^2*(1-p5[3]))-mphi_l[3]^2) # variance
pm = rbind(mphi_l,vphi_l,p3,p4,p5)

# parameters for GARCH effects
mcvs = cbind(0.6, 0.2) 

#### Data generating process
################################################################################
### Generate initial values and random coefficients
GenRandomPara = function(N,NumPara,case,ka=1) {
  para = array(0,dim=c(N,NumPara))
  ## initial values
  para[,1] = ka*0 # y1_{i} = 0 for all individuals
  p = pm[case,]
  ## AR(1) coefficients
  if (case==1) {
    mphi = 0.4; a = 0.3 # 0.4 + uniform (-0.3, 0.3)
    para[,3] = mphi + runif(N, min=-a, max=a) 
  }
  if (case==2) { 
    mphi = 0.4; a = 0.5 # 0.4 + uniform (-0.5, 0.5)
    para[,3] = mphi + runif(N, min=-a, max=a) 
  }
  if (case==3) {
    lb= 0.2; ub= 0.8; pi= 0.3 # categorical
    para[,3] = matrix(t(matrix(c(rep(lb,pi*N),rep(ub,(1-pi)*N)),N/10,10)),N,1)
  }
  if (case==4) {
    mphi = 0.475 # homogeneous phi_i = phi_0 = 0.475
    para[,3] = rep(mphi,N)
  }
  if (case==5) {
    mphi = 0.620 # homogeneous phi_i = phi_0 = 0.620
    para[,3] = rep(mphi,N)
  }
  ## individual fixed effects
  para[,2] = para[,3]+rnorm(N,0,1) 
  para
}

### Generate errors and a panel of outcome variables
GenError = function(N,T,ve,GAUSSIAN,GARCH){
  u = array(0,dim=c(N,T))
  e = array(0,dim=c(N,T))
  h = array(0,dim=c(N,T))
  
  if (GAUSSIAN == TRUE & GARCH == FALSE){
    e[,2:T] = matrix(rnorm(N*(T-1)),N,T-1)
    h[,2:T] = matrix(sqrt(ve),N,T-1)
    u[,2:T] = h[,2:T]*e[,2:T]
  }
  
  if (GAUSSIAN == TRUE & GARCH == TRUE){
    e[,2:T] = matrix(rnorm(N*(T-1)),N,T-1)
    cvs = t(matrix(mcvs,2,N)) # coefficients of GARCH effects
    h[,1] = sqrt(ve) # stationary initial values for GARCH(1,1)
    for(t in 2:T){
      ### GARCH(1,1)
      h[,t] = sqrt(ve-ve*rowSums(cvs) + cvs[,1]*h[,t-1]^2 + cvs[,2]*u[,t-1]^2)
      u[,t] = h[,t]*e[,t]
    }
  }
  
  if (GAUSSIAN == FALSE & GARCH == FALSE){
    e[,2:T] = matrix((rchisq(N*(T-1),2,ncp=0)-2)/2,N,T-1)
    h[,2:T] = matrix(sqrt(ve),N,T-1)
    u[,2:T] = h[,2:T]*e[,2:T]
  }
  
  if (GAUSSIAN == FALSE & GARCH == TRUE){
    cvs = t(matrix(mcvs,2,N)) # coefficients of GARCH effects
    e[,2:T] = matrix((rchisq(N*(T-1),2,ncp=0)-2)/2,N,T-1)
    h[,1] = sqrt(ve) # stationary initial values for GARCH(1,1)
    for(t in 2:T){
      ### GARCH(1,1)
      h[,t] = sqrt(ve-ve*rowSums(cvs) + cvs[,1]*h[,t-1]^2 + cvs[,2]*u[,t-1]^2)
      u[,t] = h[,t]*e[,t]
    }
  }
  
  return(u[,2:T])
}

### Generate Y
GenRandomY = function(N,T,para,ve,GAUSSIAN,GARCH){
  Y = array(0,dim=c(N,T))
  Y[1:N,1] = para[1:N,1]
  GAUSSIAN = GAUSSIAN
  GARCH = GARCH
  T = T
  errors = GenError(N,T,ve,GAUSSIAN,GARCH) # N*(T-1) matrix
  for(t in 1:(T-1)){
    ### Below: Y_{t+1} = alpha + beta Y_t + sigma 
    Y[1:N,(t+1)] = para[1:N,2] + para[1:N,3] * Y[1:N,t] + errors[1:N,t]
  }
  Y
}
################################################################################

##############################################################################
####### FDAC and HetroGMM estimators of moments of AR(1) coefficients by Pesaran and Yang (2023)
##############################################################################
inv = function(m) class(try(solve(m),silent=T))[1]=="matrix"

Moment_mv = function(paneldata){
  T = dim(paneldata)[2]; N = dim(paneldata)[1]
  y = matrix(t(paneldata),nrow=T,ncol=N)
  Tm = min(dim(y))
  tm = min(dim(y)) -1
  n = max(dim(y))
  dy = y[2:Tm,] - y[1:(Tm-1),]  # first difference of panel data
  
  ######## MM: Individual Moments average over T : (T-h-1)*N matrix 
  lagdyy = 1*(tm>2)+1*(tm>3)+1*(tm>4)+1 # order of h for \Delta y_{it}\Delta y_{i,t-h}
  dyyi1 = matrix(, nrow = 5, ncol = n) # moments of \Delta y_{it}\Delta y_{i,t-h}, h=0,1,...,lagdyy
  dyyi2 = matrix(, nrow = 3, ncol = n) # T-3 h=0,1,2 
  dyyi3 = matrix(, nrow = 4, ncol = n) # T-4 h=0,1,2,3  
  dyyi4 = matrix(, nrow = 5, ncol = n) # T-5 h=0,1,2,3,4 
  
  for (ll in 0:lagdyy){
    dyyi1[(ll+1),] = matrix(t(dy[(1+ll):tm,]*dy[1:(tm-ll),]),nrow=n,ncol=(tm-ll)) %*% matrix(1,nrow = tm-ll,ncol=1) / (tm-ll)# average over t-h-1 
  }
  
  if (tm>=3) {
    dyyi2 = rbind(matrix(matrix(t(dy[3:tm,]^2),nrow=n,ncol=(tm-2)) %*% matrix(1,nrow=tm-2,ncol=1)/(tm-2),nrow=1,ncol=n),
                  matrix(matrix(t(dy[3:tm,]*dy[2:(tm-1),]),nrow=n,ncol=(tm-2)) %*% matrix(1,nrow=tm-2,ncol=1)/(tm-2),nrow=1,ncol=n),
                  matrix(matrix(t(dy[3:tm,]*dy[1:(tm-2),]),nrow=n,ncol=(tm-2)) %*% matrix(1,nrow=tm-2,ncol=1)/(tm-2),nrow=1,ncol=n)) # MM b
    hi1 = matrix(dy[3:tm,]^(2) + dy[3:tm,]*dy[2:(tm-1),],nrow=(tm-2),ncol=n) # GMM (T-3)*n vector
    gi1 = matrix(dy[3:tm,]^(2) + 2*dy[3:tm,]*dy[2:(tm-1),] + dy[3:tm,]*dy[1:(tm-2),],nrow=(tm-2),ncol=n) 
    
    ####### MM Average across i
    dyy1 = dyyi1 %*% matrix(1,nrow=n,ncol=1)/n # h=0,1,2,...,lagdyy
    dyy2 = dyyi2 %*% matrix(1,nrow=n,ncol=1)/n # h=0,1,2
    ####### MM Version a: dyy1 with different T-h-1
    mm1 = (dyy1[1]+2*dyy1[2]+dyy1[3])/(dyy1[1]+dyy1[2]) # Equation (15) 
    mms1 = sum((dyyi1[1,]+2*dyyi1[2,]+dyyi1[3,]-mm1*(dyyi1[1,]+dyyi1[2,]))^2)/n # average across i
    std_mm1 = sqrt((dyy1[1]+dyy1[2])^(-2)*mms1/n) # ((mean(dyyi1[1,]+dyyi1[2,]))^(2)*(mms1^(-1)))^(-1)/n   
    
    
    ####### GMM 
    hnt1 = hi1 %*% matrix(1,nrow=n,ncol=1) / n  # (T-3)*1 average over n rowMeans(hi1)
    gnt1 = gi1 %*% matrix(1,nrow=n,ncol=1) / n  # average over n rowMeans(gi1) 
    gmms1 = (gi1-mm1*hi1) %*% t(gi1-mm1*hi1) /n  # the optimal weight (T-3)*(T-3) matrix for the mean Equation (20)
    if (inv(gmms1) == 1) {
      gmms1 = gmms1
    } else {
      gmms1 = diag(tm-2)/n
    }
    gmm1 =  solve(t(hnt1) %*% solve(gmms1) %*% hnt1) * (t(hnt1) %*% solve(gmms1) %*% gnt1) # 1st moment: Equation (22)
    std_gmm1 = sqrt(solve(t(hnt1) %*% solve(gmms1) %*% hnt1) /n) #Asymptotic variance
  }
  
  if (tm>=4) {
    svmi = matrix(, nrow = 2^2 , ncol=n) # sample variance of moment conditions
    svgi = matrix(, nrow = (tm-2+tm-3)^2 , ncol=n) # sample variance of joint moment conditions: 1st, 2nd
    
    dyyi3 = rbind(matrix(matrix(t(dy[4:tm,]^2),nrow=n,ncol=(tm-3)) %*% matrix(1,nrow=tm-3,ncol=1)/(tm-3),nrow=1,ncol=n), 
                  matrix(matrix(t(dy[4:tm,]*dy[3:(tm-1),]),nrow=n,ncol=(tm-3)) %*% matrix(1,nrow=tm-3,ncol=1)/(tm-3),nrow=1,ncol=n),
                  matrix(matrix(t(dy[4:tm,]*dy[2:(tm-2),]),nrow=n,ncol=(tm-3)) %*% matrix(1,nrow=tm-3,ncol=1)/(tm-3),nrow=1,ncol=n),
                  matrix(matrix(t(dy[4:tm,]*dy[1:(tm-3),]),nrow=n,ncol=(tm-3)) %*% matrix(1,nrow=tm-3,ncol=1)/(tm-3),nrow=1,ncol=n))
    hi2 = matrix(dy[4:tm,]^(2) + dy[4:tm,]*dy[3:(tm-1),],nrow=(tm-3),ncol=n) #  (T-4)*n vector
    gi2 = matrix(dy[4:tm,]^(2) + 2*dy[4:tm,]*dy[3:(tm-1),] + 2*dy[4:tm,]*dy[2:(tm-2),] + dy[4:tm,]*dy[1:(tm-3),],nrow=(tm-3),ncol=n) 
    
    dyy3 = dyyi3 %*% matrix(1,nrow=n,ncol=1)/ n # h=0,1,2,3
    ### MM: 2nd
    mm2 = (dyy1[1]+2*dyy1[2]+2*dyy1[3]+dyy1[4])/(dyy1[1]+dyy1[2]) # Equation (16) 
    mms2 = mean((dyyi1[1,]+2*dyyi1[2,]+2*dyyi1[3,]+dyyi1[4,]-mm2*(dyyi1[1,]+dyyi1[2,]))^2)
    std_mm2 = sqrt((dyy1[1]+dyy1[2])^(-2)*mms2 /n)  #1-(rho[1]+2*mm1*rho[1]+mm2*rho[1])/(1-rho[1]) - mm2 
    mmv = mm2-mm1^2 # plug-in estimator of variance
    
    mc = rbind(mm1 * (dyyi1[1,]+dyyi1[2,]) - (dyyi1[1,]+2*dyyi1[2,]+dyyi1[3,]), mm2*(dyyi1[1,]+dyyi1[2,]) - (dyyi1[1,]+2*dyyi1[2,]+2*dyyi1[3,]+dyyi1[4,])) # n*2 matrix
    index = 1
    for (i in 1:2){
      for (j in 1:2) {
        svmi[index,] = mc[i,] * mc[j,]
        index = index +1
      }
    }
    rm(mc)
    jmms2 = matrix(c(rowMeans(svmi)),nrow = 2 ,ncol = 2) # with the mmb plugged in  
    dmm2 = matrix(c(-2*mm1,1),nrow = 2,ncol = 1)
    jhm2 = matrix(c((dyy1[1]+dyy1[2]),0,0,(dyy1[1]+dyy1[2])),nrow=2,ncol=2)
    
    if (inv(jhm2) == 1) {
      jhm2 = jhm2} else {
        jhm2 = diag(2)
      }
    std_mmv = sqrt(t(dmm2) %*% solve(jhm2) %*% (jmms2) %*% solve(jhm2) %*% dmm2 /n  )
    
    ### GMM : 2nd
    hnt2 = rowMeans(hi2)
    gnt2 = rowMeans(gi2)
    gmms2 = (gi2-mm2*hi2) %*% t(gi2-mm2*hi2) /n  # the optimal weight (T-4)*(T-4) matrix for the mean Equation (31)
    if (inv(gmms2) == 1) {
      gmms2 = gmms2} else {
        gmms2 = diag(tm-3)
      }
    gmm2 =  solve(t(hnt2) %*% solve(gmms2) %*% hnt2) * (t(hnt2) %*% solve(gmms2) %*% gnt2) # 2nd moment: Equation (29)
    gmmv = gmm2 - gmm1^2
    zeroh1 = matrix(rep(0,length(hi1[,i])), nrow=length(hi1[,i]),ncol=1)
    zeroh2 = matrix(rep(0,length(hi2[,i])), nrow=length(hi2[,i]),ncol=1)
    zerom1 = matrix(rep(0, (tm-2)*(tm-3)),nrow=tm-2,ncol=tm-3)
    zerom2 = matrix(rep(0, (tm-2)*(tm-3)),nrow=tm-3,ncol=tm-2)
    
    mc = rbind(kronecker(gmm1,hi1)-gi1, kronecker(gmm2,hi2)-gi2) # (T-3+T-4)*2 matrix
    index = 1
    for (i in 1:(2*tm-5)){
      for (j in 1:(2*tm-5)) {
        svgi[index,] = mc[i,] * mc[j,]
        index = index +1
      }
    }
    rm(mc)
    jgmms2 = matrix(c(rowMeans(svgi)),nrow = 2*tm-5 ,ncol = 2*tm-5) # covariance matrix of joint moments
    jhg2 =  rbind(cbind(hnt1,zeroh1),cbind(zeroh2,hnt2)) # （2*tm-5) times 2 matrix
    
    gmma2 = rbind(cbind(solve(gmms1),zerom1),cbind(zerom2,solve(gmms2))) # weight matrix
    gmmcv2 = solve(t(jhg2) %*% gmma2 %*% jhg2) %*% t(jhg2) %*% gmma2 %*% jgmms2 %*% t(gmma2) %*% jhg2 %*% solve(t(jhg2) %*% t(gmma2) %*% jhg2)
    dgmm2 = matrix(c(-2*gmm1,1),nrow = 2,ncol = 1)
    
    std_gmm2 = sqrt((t(hnt2) %*% solve(gmms2) %*% hnt2)^(-1)/n)
    std_gmmv =  sqrt(t(dgmm2) %*% gmmcv2  %*% dgmm2 /n)
    
  }
  
  if (tm>=5) {
    dyyi4 = rbind(matrix(matrix(t(dy[5:tm,]^2),nrow=n,ncol=(tm-4)) %*% matrix(1,nrow=tm-4,ncol=1)/(tm-4),nrow=1,ncol=n),
                  matrix(matrix(t(dy[5:tm,]*dy[4:(tm-1),]),nrow=n,ncol=(tm-4)) %*% matrix(1,nrow=tm-4,ncol=1)/(tm-4),nrow=1,ncol=n),
                  matrix(matrix(t(dy[5:tm,]*dy[3:(tm-2),]),nrow=n,ncol=(tm-4)) %*% matrix(1,nrow=tm-4,ncol=1)/(tm-4),nrow=1,ncol=n),
                  matrix(matrix(t(dy[5:tm,]*dy[2:(tm-3),]),nrow=n,ncol=(tm-4)) %*% matrix(1,nrow=tm-4,ncol=1)/(tm-4),nrow=1,ncol=n),
                  matrix(matrix(t(dy[5:tm,]*dy[1:(tm-4),]),nrow=n,ncol=(tm-4)) %*% matrix(1,nrow=tm-4,ncol=1)/(tm-4),nrow=1,ncol=n))
    hi3 = matrix(dy[5:tm,]^(2) + dy[5:tm,]*dy[4:(tm-1),],nrow=(tm-4),ncol=n) #  (T-5)*n vector
    gi3 = matrix(dy[5:tm,]^(2) + 2*dy[5:tm,]*dy[4:(tm-1),] + 2*dy[5:tm,]*dy[3:(tm-2),] + 2*dy[5:tm,]*dy[2:(tm-3),] + dy[5:tm,]*dy[1:(tm-4),],nrow=(tm-4),ncol=n) # 
    
    dyy4 = rowMeans(dyyi4) # h=0,1,2,3,4
    ### MM
    mm3 = (dyy1[1]+2*dyy1[2]+2*dyy1[3]+2*dyy1[4]+dyy1[5])/(dyy1[1]+dyy1[2]) # 
    mms3 = mean((dyyi1[1,]+2*dyyi1[2,]+2*dyyi1[3,]+2*dyyi1[4,]+dyyi1[5,]-mm3*(dyyi1[1,]+dyyi1[2,]))^2)
    std_mm3 = sqrt((dyy1[1]+dyy1[2])^(-2)*mms3 /n)  #1-(rho[1]+2*mm1*rho[1]+mm2*rho[1])/(1-rho[1]) - mm2 
    
    
    ### GMM: 3rd
    hnt3 = rowMeans(hi3)
    gnt3 = rowMeans(gi3)
    gmms3 = (gi3-mm3*hi3) %*% t(gi3-mm3*hi3) /n  # the optimal weight (T-5)*(T-5) matrix for the mean Equation (31)
    if (inv(gmms3) == 1) {
      gmms3 = gmms3} else {
        gmms3 = diag(tm-4)
      }
    gmm3 =  solve(t(hnt3) %*% solve(gmms3) %*% hnt3) * (t(hnt3) %*% solve(gmms3) %*% gnt3) # 2nd moment: Equation (29)
    std_gmm3 = sqrt((t(hnt3) %*% solve(gmms3) %*% hnt3)^(-1)/n)
  }
  
  if (tm==3){
    return(cbind(mm1,std_mm1,gmm1,std_gmm1))
  }
  if (tm==4) {
    return(cbind(mm1,std_mm1,gmm1,std_gmm1,
                 mm2,std_mm2,gmm2,std_gmm2,
                 mmv,std_mmv,gmmv,std_gmmv))
  }
  if (tm>4){
    return(cbind(mm1,std_mm1,gmm1,std_gmm1,
                 mm2,std_mm2,gmm2,std_gmm2,
                 mmv,std_mmv,gmmv,std_gmmv,
                 mm3,std_mm3,gmm3,std_gmm3))
  }
}
##############################################################################

MonteCarloSim = function(r,N,Tobs){
  panel0 = matrix(data_all[,r],Nmax,Tmax); 
  panel1 = panel0[1:N,1:Tobs]
  Moment_mv(panel1)
}

for (GAUSSIAN in c(0,1)) {
 for (GARCH in c(0,1)) {
   for (case in 1:3) {
     start_time = Sys.time()
     
     #### Generate samples
     ##################################################################################################
     data_all = matrix(,Nmax*Tmax,rep); 
     for (r in 1:rep ) {
       ve = 0.5+ 0.5*rchisq(Nmax,1,ncp=0) # cross-sectional hetero variance of errors
       para = GenRandomPara(Nmax,NumPara,case,ka=1) 
       paneldata = GenRandomY(Nmax,(Tmax+M0+2),para,ve,GAUSSIAN,GARCH)
       paneldata = paneldata[,(M0+2+1):(M0+2+Tmax)]
       data_all[,r] = matrix(paneldata,Nmax*Tmax,1);rm(paneldata)
     }
     rm(para,ve)
     ##################################################################################################
     
     for (Tobs in Tlist) {
       for (N in Nlist) {
         numCores = availableCores()
         mc_results = mclapply(reps,MonteCarloSim,N=N,Tobs=Tobs,mc.preschedule = TRUE, mc.cores = numCores)
         
         tm = Tobs-1
         if (tm==3){
           mm_estimates = t(matrix(unlist(mc_results),4,rep))
           results_m1 = mm_estimates[,1]
           results_m1_sd = mm_estimates[,2]
         } # length = 4
         if (tm==4) {
           mm_estimates = t(matrix(unlist(mc_results),12,rep))
           results_m1 = mm_estimates[,1:2]
           results_m1_sd = mm_estimates[,3:4]
           results_m2 = mm_estimates[,5:6]
           results_m2_sd = mm_estimates[,7:8]
           results_var = mm_estimates[,9:10]
           results_var_sd = mm_estimates[,11:12]
         } # length = 4*3 = 12
         if (tm>4){
           mm_estimates = t(matrix(unlist(mc_results),16,rep))
           results_m1 = mm_estimates[,1:2]
           results_m1_sd = mm_estimates[,3:4]
           results_m2 = mm_estimates[,5:6]
           results_m2_sd = mm_estimates[,7:8]
           results_var = mm_estimates[,9:10]
           results_var_sd = mm_estimates[,11:12]
           results_m3 = mm_estimates[,13:14]
           results_m3_sd = mm_estimates[,15:16]
         }
         rm(mc_results);rm(list=ls(pattern="results*")); 
         ###############################################################
         name = paste("mm",case,sep="_c")
         Nid = which(Nlist==N); Tid = which(Tlist==Tobs)
         s = (Tid-1)*length(Nlist)+Nid;
         if (s<10) {
           name = paste(name,s,sep="_0")
         } else {
           name = paste(name,s,sep="_") 
         }
         assign(name,mm_estimates);rm(name,mm_estimates)
         ###############################################################
         
       }
     }
     rm(data_all)
     end_time = Sys.time()
     time = end_time - start_time
     fn = paste("exp_fdac_mm_c",case,"_",GAUSSIAN,GARCH,".RData",sep="")
     save.image(file=fn)
   }
  } 
}

# Report tables
##############################################################################
rm(list=ls())
### Define Functions Calculate Statistics: (Bias, RMSE, T_test & Power, Coverage)
################################################################################
Bias = function(ests,truev) {
  ests = as.matrix(ests)
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  colMeans(ests - truematrix)
}

RMSE = function(ests,truev) {
  ests = as.matrix(ests)
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  sqrt(colMeans((ests - truematrix)^2))
}

T_test = function(truev,estsd,rep){
  ests = as.matrix(estsd[1:rep])
  sds = as.matrix(estsd[(rep+1):(2*rep)])
  truematrix = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  colMeans(abs((ests-truematrix)/sds)>qnorm(p = 0.975))
}

pwlb=-2.5; pwrb=2.5; pwintv=0.01;
pwgrid = length(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv)))
Power = function(truev,estsd,rep){
  h1 = as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv)) # values of alternatives (v0-0.5,v0+0.5) length = 101
  powers = sapply(h1,function(x) T_test(x,estsd,rep))
  powers
}

Coverage = function(truev,estsd,rep){
  ests = as.matrix(estsd[1:rep])
  sds = as.matrix(estsd[(rep+1):(2*rep)])
  truem = matrix(truev,nrow=nrow(ests),ncol=ncol(ests))
  cvr = abs(truem - ests) < qnorm(0.975,0,1)*sds # within the 95% CI excluding 2.5% from each tail
  mean(cvr)
}
##############################################################################

# Create a style for center-aligning the numbers
##############################################################################
center_style <- createStyle(halign = "center")
right <- createStyle(halign = "right")
left <- createStyle(halign = "left")
bbs <- createStyle(border = "bottom",borderStyle="thin")
lbs <- createStyle(border = "bottom",borderStyle="double")
tbs <- createStyle(border = "top",borderStyle="double")
wrap_text_style <- createStyle(wrapText = TRUE)

pwlb=-2.5; pwrb=2.5; pwintv=0.01;
pwgrid = length(as.matrix(seq(as.numeric(0+pwlb),as.numeric(0+pwrb),by=pwintv)))
k=2;
##############################################################################


# Create a new workbook
wb <- createWorkbook()

## Tables S.1 and S.2: Compare FDAC and HetroGMM estimators of mean and variance
##############################################################################
# Load simulation results
fn1 = "exp_fdac_mm_c2_11.RData"
fn2 = "exp_fdac_mm_c3_11.RData"
en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en))
temp2 = tryCatch(load(fn2),error=function(e) print(en))
case_list = c(2,3);
Nlist = c(100,200,500,1000,5000); Tlist = c(4,5,6,8,10)
NT = expand.grid(Nlist,Tlist); NT = cbind(NT[,2],NT[,1])

if ( temp1[1]!=1 & temp2[1]!=1) {
  m1_bias = matrix(,2*dim(NT)[1],2)
  m1_rmse = matrix(,2*dim(NT)[1],2) 
  m1_size = matrix(,2*dim(NT)[1],2)
  m1_pw = matrix(,2*dim(NT)[1],2*pwgrid)
  
  var_bias = matrix(,2*dim(NT)[1],2)
  var_rmse = matrix(,2*dim(NT)[1],2) 
  var_size = matrix(,2*dim(NT)[1],2)  
  var_pw = matrix(,2*dim(NT)[1],2*pwgrid)
  
  for (cid in 1:2) {
    
    case = case_list[cid]
    mb = mphi_l[case]
    vb = vphi_l[case]
    #### Get the respective simulation results
    for (k in 1:dim(NT)[1]){ 
      Tobs = NT[k,1]; N = NT[k,2];
      name = paste("mm",case,sep="_c")
      Nid = which(Nlist==N); Tid = which(Tlist==Tobs)
      s = (Tid-1)*length(Nlist)+Nid;
      if (s<10) {
        name = paste(name,s,sep="_0")
      } else {
        name = paste(name,s,sep="_") 
      }
      mc_results1 = get(name);rm(name)
      for (j in 1:2) { # FDAC and HetroGMM estimators
        if (Tobs>3) { # Mean
          results_m1 = mc_results1[,c(1,3)]
          results_m1_sd = mc_results1[,c(2,4)]
          m1_bias[(cid-1)*dim(NT)[1]+k,j] = Bias(results_m1[,j], mb)
          m1_rmse[(cid-1)*dim(NT)[1]+k,j] = RMSE(results_m1[,j], mb)
          e1 = cbind(results_m1[,j],results_m1_sd[,j])
          m1_pw[(cid-1)*dim(NT)[1]+k,(pwgrid*(j-1)+1):(pwgrid*(j-1)+pwgrid)] = Power(mb,e1,rep) # length = no. alternative values
          m1_size[(cid-1)*dim(NT)[1]+k,j] = m1_pw[(cid-1)*dim(NT)[1]+k,pwgrid*(j-1)+(pwgrid-1)/2+1]; rm(e1) 
        }
        if (Tobs>4) { # Variance
          results_var = mc_results1[,c(9,11)]
          results_var_sd = mc_results1[,c(10,12)]
          var_bias[(cid-1)*dim(NT)[1]+k,j] = Bias(results_var[,j], vb)
          var_rmse[(cid-1)*dim(NT)[1]+k,j] = RMSE(results_var[,j], vb)
          v1 = cbind(results_var[,j],results_var_sd[,j])
          var_pw[(cid-1)*dim(NT)[1]+k,(pwgrid*(j-1)+1):(pwgrid*(j-1)+pwgrid)] = Power(vb,v1,rep) # length = no. alternative values
          var_size[(cid-1)*dim(NT)[1]+k,j] = var_pw[(cid-1)*dim(NT)[1]+k,pwgrid*(j-1)+(pwgrid-1)/2+1]; rm(v1)
        }
      }
    }
  }
  
  #### Table S.1 E(phi_i)
  #########################################################################
  sn = "Table S.1"
  addWorksheet(wb, sn)
  writeData(wb, sn, x = "Table S.1: Bias, RMSE, and size of FDAC and HetroGMM estimators of E(phi_i) in a heterogeneous panel AR(1) model with Gaussian errors and GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
  writeData(wb, sn, x = "(a) Uniform E(phi_i) = 0.4 with a = 0.5", startCol = 4, startRow = 2, colNames = FALSE)
  writeData(wb, sn, x = "(b) Categorical E(phi_i) = 0.62", startCol = 13, startRow = 2, colNames = FALSE)
  
  Nlist = c(100,200,500,1000,5000); Tlist = c(4,5,6,8,10)
  NT = expand.grid(Nlist,Tlist); NT = cbind(NT[,2],NT[,1])
  nr2 = dim(NT)[1]; rl2 = seq(1,nr2,by=1); 
  Tlist2 = c("4","5","6","8","10"); Nlist2 = rep(c('100','200','500','1,000','5,000'),5)
  nc = 2
  tab = matrix(,nr2+1,2+(nc+1)*3*2) 
  tab2 = matrix(,nr2+1,2+(nc+1)*3*2) 
  
  #### Put numbers into the respective cells
  for (r2 in 1:nr2) {
    tab2[r2,1] = NT[r2,1]
    tab2[r2,2] = Nlist2[r2]    
    tab[r2,(3+1):(3+nc)] = m1_bias[r2,]
    tab[r2,(3+nc+1+1):(3+nc+1+nc)] = m1_rmse[r2,]
    tab[r2,(3+nc+1+nc+1+1):(3+nc+1+nc+1+nc)] = m1_size[r2,]
    
    tab[r2,(6+3*nc+1):(6+3*nc+nc)] = m1_bias[r2+nr2*1,]
    tab[r2,(6+3*nc+nc+1+1):(6+3*nc+nc+1+nc)] = m1_rmse[r2+nr2*1,]
    tab[r2,(6+3*nc+nc+1+nc+1+1):(6+3*nc+nc+1+nc+1+nc)] = m1_size[r2+nr2*1,]
  }
  
  #### Change the formats of each column
  for (col in c(4:5,7:8,13:14,15:17)) {   # bias, RMSE
    v0 = tab[,col]; v1 = v0
    for (i in 1:length(v0)) {
      if (is.na(v0[i]) == 0) {
        v1[i] = format(round(v0[i], 3), nsmall = 3) 
      } else {
        v1[i] = ""
      }
    }
    tab2[,col] = v1; rm(v0,v1)
  }
  for (col in c(10:11,19:20)) {   # size (*100)
    v0 = tab[,col]; v1 = v0
    for (i in 1:length(v0)) {
      if (is.na(v0[i]) == 0) {
        v1[i] = format(round(v0[i]*100, 1), nsmall = 1) 
      } else {
        v1[i] = ""
      }
    }
    tab2[,col] = v1; rm(v0,v1)
  }
  
  h = tab2
  h1 = c("","","","Bias","","","RMSE","","","Size (*100)","","","Bias","","","RMSE","","","Size (*100)","")
  h2 = c("T","n","",rep(c('FDAC',"HetroGMM",""),5),"FDAC","HetroGMM")
  rv0 = matrix(,1,20)
  h = rbind(h1,h2,h[1:5,],rv0,h[6:10,],rv0,h[11:15,],rv0,h[15:20,],rv0,h[21:25,])
  rownames(h) <- NULL
  colnames(h) <- NULL
  writeData(wb,sn, x = h, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)
  mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 1)
  mergeCells(wb, sheet = sn, cols = 4:11, rows = 2)
  mergeCells(wb, sheet = sn, cols = 13:20, rows = 2)
  mergeCells(wb, sheet = sn, cols = 4:5, rows = 3)
  mergeCells(wb, sheet = sn, cols = 7:8, rows = 3)
  mergeCells(wb, sheet = sn, cols = 10:11, rows = 3)
  mergeCells(wb, sheet = sn, cols = 13:14, rows = 3)
  mergeCells(wb, sheet = sn, cols = 16:17, rows = 3)
  mergeCells(wb, sheet = sn, cols = 19:20, rows = 3)
  
  addStyle(wb,sn,style = center_style, rows = 2:4,cols = 1:(ncol(h)), gridExpand = T)
  addStyle(wb,sn,style = right, rows = 5:(nrow(h)+2),cols = 1:(ncol(h)), gridExpand = T)
  addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = T,stack=T)
  addStyle(wb,sn,style = bbs, rows = 2,cols = c(4:11,13:20), gridExpand = T,stack=T)
  addStyle(wb,sn,style = bbs, rows = 3,cols = c(4:5,7:8,10:11,13:14,16:17,19:20), gridExpand = T,stack=T)
  addStyle(wb,sn,style = bbs, rows = 4,cols = 1:(ncol(h)), gridExpand = T,stack=T)  
  addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = T,stack=T)
  addStyle(wb,sn,style = lbs, rows = (nrow(h)+2),cols = 1:(ncol(h)), gridExpand = T,stack=T)
  #########################################################################
  rm(tab,tab2)
  
  #### Table S.2 Var(phi_i)
  #########################################################################
  sn = "Table S.2"
  addWorksheet(wb, sn)
  writeData(wb, sn, x = "Table S.2: Bias, RMSE, and size of FDAC and HetroGMM estimators of Var(phi_i) in a heterogeneous panel AR(1) model with Gaussian errors and GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
  writeData(wb, sn, x = "(a) Uniform Var(phi_i) = 0.083 with a = 0.5", startCol = 4, startRow = 2, colNames = FALSE)
  writeData(wb, sn, x = "(b) Categorical Var(phi_i) = 0.076", startCol = 13, startRow = 2, colNames = FALSE)
  
  Nlist = c(100,200,500,1000,5000); Tlist = c(4,5,6,8,10)
  NT = expand.grid(Nlist,Tlist); NT = cbind(NT[,2],NT[,1])
  nr2 = dim(NT)[1]-5; rl2 = seq(1,nr2,by=1); 
  Nlist2 = rep(c('100','200','500','1,000','5,000'),4)
  nc = 2
  tab = matrix(,nr2,2+(nc+1)*3*2) 
  tab2 = matrix(,nr2,2+(nc+1)*3*2) 
  
  #### Put numbers into the respective cells
  for (r2 in 1:nr2) {
    tab2[r2,1] = NT[5+r2,1]
    tab2[r2,2] = Nlist2[r2]    
    tab[r2,(3+1):(3+nc)] = var_bias[5+r2,]
    tab[r2,(3+nc+1+1):(3+nc+1+nc)] = var_rmse[5+r2,]
    tab[r2,(3+nc+1+nc+1+1):(3+nc+1+nc+1+nc)] = var_size[5+r2,]
    
    tab[r2,(6+3*nc+1):(6+3*nc+nc)] = var_bias[5+r2+(nr2+5)*1,]
    tab[r2,(6+3*nc+nc+1+1):(6+3*nc+nc+1+nc)] = var_rmse[5+r2+(nr2+5)*1,]
    tab[r2,(6+3*nc+nc+1+nc+1+1):(6+3*nc+nc+1+nc+1+nc)] = var_size[5+r2+(nr2+5)*1,]
  }
  
  #### Change the formats of each column
  for (col in c(4:5,7:8,13:14,15:17)) {   # bias, RMSE
    v0 = tab[,col]; v1 = v0
    for (i in 1:length(v0)) {
      if (is.na(v0[i]) == 0) {
        v1[i] = format(round(v0[i], 3), nsmall = 3) 
      } else {
        v1[i] = ""
      }
    }
    tab2[,col] = v1; rm(v0,v1)
  }
  for (col in c(10:11,19:20)) {   # size (*100)
    v0 = tab[,col]; v1 = v0
    for (i in 1:length(v0)) {
      if (is.na(v0[i]) == 0) {
        v1[i] = format(round(v0[i]*100, 1), nsmall = 1) 
      } else {
        v1[i] = ""
      }
    }
    tab2[,col] = v1; rm(v0,v1)
  }
  
  h = tab2
  h1 = c("","","","Bias","","","RMSE","","","Size (*100)","","","Bias","","","RMSE","","","Size (*100)","")
  h2 = c("T","n","",rep(c('FDAC',"HetroGMM",""),5),"FDAC","HetroGMM")
  rv0 = matrix(,1,20)
  h = rbind(h1,h2,h[1:5,],rv0,h[6:10,],rv0,h[11:15,],rv0,h[15:20,])
  rownames(h) <- NULL
  colnames(h) <- NULL
  writeData(wb,sn, x = h, startCol = 1, startRow = 3,colNames = FALSE, rowNames = FALSE)
  mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 1)
  mergeCells(wb, sheet = sn, cols = 4:11, rows = 2)
  mergeCells(wb, sheet = sn, cols = 13:20, rows = 2)
  mergeCells(wb, sheet = sn, cols = 4:5, rows = 3)
  mergeCells(wb, sheet = sn, cols = 7:8, rows = 3)
  mergeCells(wb, sheet = sn, cols = 10:11, rows = 3)
  mergeCells(wb, sheet = sn, cols = 13:14, rows = 3)
  mergeCells(wb, sheet = sn, cols = 16:17, rows = 3)
  mergeCells(wb, sheet = sn, cols = 19:20, rows = 3)
  
  addStyle(wb,sn,style = center_style, rows = 2:4,cols = 1:(ncol(h)), gridExpand = T)
  addStyle(wb,sn,style = right, rows = 5:(nrow(h)+2),cols = 1:(ncol(h)), gridExpand = T)
  addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = T,stack=T)
  addStyle(wb,sn,style = bbs, rows = 2,cols = c(4:11,13:20), gridExpand = T,stack=T)
  addStyle(wb,sn,style = bbs, rows = 3,cols = c(4:5,7:8,10:11,13:14,16:17,19:20), gridExpand = T,stack=T)
  addStyle(wb,sn,style = bbs, rows = 4,cols = 1:(ncol(h)), gridExpand = T,stack=T)  
  addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = T,stack=T)
  addStyle(wb,sn,style = lbs, rows = (nrow(h)+2),cols = 1:(ncol(h)), gridExpand = T,stack=T)
  #########################################################################
  rm(tab,tab2)
  
  #### Figure S.1-S.4 E(phi_i) and Var(phi_i)
  #########################################################################
  for (id in c(1,2)) {
    case = case_list[id]
    # E(phi_i)
    #####################################################################################
    powermm1 = t(m1_pw[(1+(id-1)*dim(NT)[1]):(id*dim(NT)[1]),1:501]) # FDAC
    powergmm1 = t(m1_pw[(1+(id-1)*dim(NT)[1]):(id*dim(NT)[1]),502:1002]) # HetroGMM
    if (case==2) { 
      name = "Figure S.1.png"
    } 
    if (case==3) {
      name = "Figure S.3.png"
    }
    #### Define x axis by alternative values
    d1 = 151; d2 = 351
    truev = mphi_l[case]
    mcm = as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv))
    mx = mcm[d1:d2] 
    xmin = mx[1]
    xmax = mx[length(mx)]
    ymin = 0
    ymax = 1
    
    png(name, units="in", width=30, height=28, res=45)
    par(mai=c(2,1.5,1.5,1),xpd=TRUE, mfrow=c(3,2),oma=c(2,3,2,2)) # (b,l,t,r)
    
    #### T=4
    plot(mx, powermm1[d1:d2,1], type="l", col=1, lwd=4, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="FDAC (T=5)",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
    lines(mx, powermm1[d1:d2,4], type="l", col=2, lwd=4, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    lines(mx, powermm1[d1:d2,5], type="l", col=4, lwd=4, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3.5, 0), cex.axis=3.5)
    axis(side=2, at=seq(0, 1, by=0.2), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
    arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
    mtext("power", side = 2, line = 5, at = 1 , cex = 3)
    mtext("5%", side = 1, line = -5, at = 1.5 , cex = 2.5)
    
    plot(mx, powergmm1[d1:d2,1], type="l", col=1, lwd=4, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="HetroGMM (T=5)",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
    lines(mx, powergmm1[d1:d2,4], type="l", col=2, lwd=4, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    lines(mx, powergmm1[d1:d2,5], type="l", col=4, lwd=4, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3.5, 0), cex.axis=3.5)
    axis(side=2, at=seq(0, 1, by=0.2), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
    arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
    mtext("power", side = 2, line = 5, at = 1 , cex = 3)
    mtext("5%", side = 1, line = -5, at = 1.5 , cex = 2.5)
    
    ### T=6
    plot(mx, powermm1[d1:d2,11], type="l", col=1, lwd=4, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="FDAC (T=6)",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
    lines(mx, powermm1[d1:d2,14], type="l", col=2, lwd=4, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    lines(mx, powermm1[d1:d2,15], type="l", col=4, lwd=4, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3.5, 0), cex.axis=3.5)
    axis(side=2, at=seq(0, 1, by=0.2), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
    arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
    mtext("power", side = 2, line = 5, at = 1 , cex = 3)
    mtext("5%", side = 1, line = -5, at = 1.5 , cex = 2.5)
    
    plot(mx, powergmm1[d1:d2,11], type="l", col=1, lwd=4, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="HetroGMM (T=6)",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
    lines(mx, powergmm1[d1:d2,14], type="l", col=2, lwd=4, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    lines(mx, powergmm1[d1:d2,15], type="l", col=4, lwd=4, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3.5, 0), cex.axis=3.5)
    axis(side=2, at=seq(0, 1, by=0.2), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
    arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
    mtext("power", side = 2, line = 5, at = 1 , cex = 3)
    mtext("5%", side = 1, line = -5, at = 1.5 , cex = 2.5)
    
    ### T=10
    plot(mx, powermm1[d1:d2,21], type="l", col=1, lwd=4, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="FDAC (T=10)",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
    lines(mx, powermm1[d1:d2,24], type="l", col=2, lwd=4, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    lines(mx, powermm1[d1:d2,25], type="l", col=4, lwd=4, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3.5, 0), cex.axis=3.5)
    axis(side=2, at=seq(0, 1, by=0.2), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
    arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
    mtext("power", side = 2, line = 5, at = 1 , cex = 3)
    mtext("5%", side = 1, line = -5, at = 1.5 , cex = 2.5)
    
    plot(mx, powergmm1[d1:d2,21], type="l", col=1, lwd=4, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="HetroGMM (T=10)",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
    lines(mx, powergmm1[d1:d2,24], type="l", col=2, lwd=4, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    lines(mx, powergmm1[d1:d2,25], type="l", col=4, lwd=4, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3.5, 0), cex.axis=3.5)
    axis(side=2, at=seq(0, 1, by=0.2), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
    arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
    mtext("power", side = 2, line = 5, at = 1 , cex = 3)
    mtext("5%", side = 1, line = -5, at = 1.5 , cex = 2.5)
    
    par(fig = c(0, 1, 0, 1), oma = c(0, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)
    plot(0, 0, type = 'l', bty = 'n', xaxt = 'n', yaxt = 'n')
    legend('bottom',legend = c("n=100", "n=1,000", "n=5,000"), lty = c(4,2,1),col = c(1,2,4), lwd = 5, xpd = TRUE, horiz = TRUE, cex = 4, seg.len=5, bty = 'n')
    
    
    dev.off()
    #####################################################################################
    
    # Var(phi_i)
    #####################################################################################
    powermmv = t(var_pw[(1+(id-1)*dim(NT)[1]):(id*dim(NT)[1]),1:501]) # FDAC
    powergmmv = t(var_pw[(1+(id-1)*dim(NT)[1]):(id*dim(NT)[1]),502:1002]) # HetroGMM
    if (case==2) { 
      name = "Figure S.2.png"
    } 
    if (case==3) {
      name = "Figure S.4.png"
    }
    truev = vphi_l[case]
    mcm = as.matrix(seq(as.numeric(truev+pwlb),as.numeric(truev+pwrb),by=pwintv))
    d1=161; d2 = 361
    mx = mcm[d1:d2] 
    xmin = -0.9
    xmax = 1.1
    ymin = 0
    ymax = 1
    
    png(name, units="in", width=30, height=28, res=45)
    par(mai=c(2,1.5,1.5,1),xpd=TRUE, mfrow=c(3,2),oma=c(2,3,2,2)) # (b,l,t,r)
    
    #### T=5
    plot(mx, powermmv[d1:d2,6], type="l", col=1, lwd=4, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="FDAC (T=5)",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
    lines(mx, powermmv[d1:d2,9], type="l", col=2, lwd=4, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    lines(mx, powermmv[d1:d2,10], type="l", col=4, lwd=4, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3.5, 0), cex.axis=3.5)
    axis(side=2, at=seq(0, 1, by=0.2), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
    arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
    mtext("power", side = 2, line = 5, at = 1 , cex = 3)
    mtext("5%", side = 1, line = -5, at = 1.5 , cex = 2.5)
    
    plot(mx, powergmmv[d1:d2,6], type="l", col=1, lwd=4, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="HetroGMM (T=5)",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
    lines(mx, powergmmv[d1:d2,8], type="l", col=2, lwd=4, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    lines(mx, powergmmv[d1:d2,19], type="l", col=4, lwd=4, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3.5, 0), cex.axis=3.5)
    axis(side=2, at=seq(0, 1, by=0.2), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
    arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
    mtext("power", side = 2, line = 5, at = 1 , cex = 3)
    mtext("5%", side = 1, line = -5, at = 1.5 , cex = 2.5)
    
    ### T=6
    plot(mx, powermmv[d1:d2,11], type="l", col=1, lwd=4, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="FDAC (T=6)",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
    lines(mx, powermmv[d1:d2,14], type="l", col=2, lwd=4, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    lines(mx, powermmv[d1:d2,15], type="l", col=4, lwd=4, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3.5, 0), cex.axis=3.5)
    axis(side=2, at=seq(0, 1, by=0.2), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
    arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
    mtext("power", side = 2, line = 5, at = 1 , cex = 3)
    mtext("5%", side = 1, line = -5, at = 1.5 , cex = 2.5)

    plot(mx, powergmmv[d1:d2,11], type="l", col=1, lwd=4, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="HetroGMM (T=6)",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
    lines(mx, powergmmv[d1:d2,14], type="l", col=2, lwd=4, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    lines(mx, powergmmv[d1:d2,15], type="l", col=4, lwd=4, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3.5, 0), cex.axis=3.5)
    axis(side=2, at=seq(0, 1, by=0.2), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
    arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
    mtext("power", side = 2, line = 5, at = 1 , cex = 3)
    mtext("5%", side = 1, line = -5, at = 1.5 , cex = 2.5)
    
    ### T=10
    plot(mx, powermmv[d1:d2,21], type="l", col=1, lwd=4, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="FDAC (T=10)",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
    lines(mx, powermmv[d1:d2,24], type="l", col=2, lwd=4, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    lines(mx, powermmv[d1:d2,25], type="l", col=4, lwd=4, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3.5, 0), cex.axis=3.5)
    axis(side=2, at=seq(0, 1, by=0.2), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
    arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
    mtext("power", side = 2, line = 5, at = 1 , cex = 3)
    mtext("5%", side = 1, line = -5, at = 1.5 , cex = 2.5)
    
    plot(mx, powergmmv[d1:d2,21], type="l", col=1, lwd=4, lty=4,xlim=c(xmin, xmax), ylim=c(ymin, ymax), xaxs="i",yaxs="i",ylab="",xlab="", main="HetroGMM (T=10)",cex.lab=4,  axes = F, cex.main=4.5, cex.sub=4)
    lines(mx, powergmmv[d1:d2,24], type="l", col=2, lwd=4, lty=2,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    lines(mx, powergmmv[d1:d2,25], type="l", col=4, lwd=4, lty=1,xlim=c(xmin, xmax), ylim=c(ymin, ymax))
    axis(side=1, at=seq(xmin, xmax, by=0.2), mgp=c(2, 3.5, 0), cex.axis=3.5)
    axis(side=2, at=seq(0, 1, by=0.2), mgp=c(4, 2, 0), cex.axis=3.5)######## Visualization
    arrows(truev,-0.02, truev, 0.03, length = 0,lty =1,lwd=3) # denote the true value
    arrows(xmin,0.05,xmax,0.05, length = 0,lty = 4, lwd=3) # denote a line of 5% probability
    mtext("power", side = 2, line = 5, at = 1 , cex = 3)
    mtext("5%", side = 1, line = -5, at = 1.5 , cex = 2.5)

    par(fig = c(0, 1, 0, 1), oma = c(0, 0, 0, 0), mar = c(0, 0, 0, 0), new = TRUE)
    plot(0, 0, type = 'l', bty = 'n', xaxt = 'n', yaxt = 'n')
    legend('bottom',legend = c("n=100", "n=1,000", "n=5,000"), lty = c(4,2,1),col = c(1,2,4), lwd = 5, xpd = TRUE, horiz = TRUE, cex = 4, seg.len=5, bty = 'n')
    
    dev.off()
    #####################################################################################
  }
  #########################################################################
} else {
  cat("The MC results of Tables S.1-S.2 and Figures S.1-S.4 are not found.")
}
##############################################################################

## Tables S.20-S.21, S.22-S.23, S.24-S.25, and S.26-S.27
##############################################################################
# Load simulation results
g_list = expand.grid(c(0,1),c(1,0))[,c(2,1)]
sn1 = c('Table S.20','Table S.22','Table S.24','Table S.26')
sn2 = c('Table S.21','Table S.23','Table S.25','Table S.27')

for (idx in 1:dim(g_list)[1]) {
  GAUSSIAN = g_list[idx,1]
  GARCH = g_list[idx,2]
  
  fn1 = paste("exp_fdac_mm_c1_",GAUSSIAN,GARCH,".RData",sep="")
  fn2 = paste("exp_fdac_mm_c2_",GAUSSIAN,GARCH,".RData",sep="")
  fn3 = paste("exp_fdac_mm_c3_",GAUSSIAN,GARCH,".RData",sep="")
  en = 1; temp1 = tryCatch(load(fn1),error=function(e) print(en))
  temp2 = tryCatch(load(fn2),error=function(e) print(en))
  temp3 = tryCatch(load(fn3),error=function(e) print(en))
  case_list = c(1,2,3); nc = length(case_list)
  
  if ( temp1[1]!=1 & temp2[1]!=1 & temp3[1]!=1) {
    m1_bias = matrix(,nc*dim(NT)[1],1)
    m1_rmse = matrix(,nc*dim(NT)[1],1) 
    m1_size = matrix(,nc*dim(NT)[1],1)
    m1_pw = matrix(,nc*dim(NT)[1],1*pwgrid)
    
    var_bias = matrix(,nc*dim(NT)[1],1)
    var_rmse = matrix(,nc*dim(NT)[1],1) 
    var_size = matrix(,nc*dim(NT)[1],1)  
    var_pw = matrix(,nc*dim(NT)[1],1*pwgrid)
    
    for (cid in c(1:3)) {
      case = case_list[cid]
      mb = mphi_l[case]
      vb = vphi_l[case]
      #### Get the respective simulation results
      for (k in 1:dim(NT)[1]){ 
        Tobs = NT[k,1]; N = NT[k,2];
        name = paste("mm",case,sep="_c")
        Nid = which(Nlist==N); Tid = which(Tlist==Tobs)
        s = (Tid-1)*length(Nlist)+Nid;
        if (s<10) {
          name = paste(name,s,sep="_0")
        } else {
          name = paste(name,s,sep="_") 
        }
        mc_results1 = get(name);rm(name)
        for (j in 1) { # FDAC estimator
          if (Tobs-1>2) { # Mean
            results_m1 = mc_results1[,c(1)]
            results_m1_sd = mc_results1[,c(2)]
            m1_bias[(cid-1)*dim(NT)[1]+k,j] = Bias(results_m1, mb)
            m1_rmse[(cid-1)*dim(NT)[1]+k,j] = RMSE(results_m1, mb)
            e1 = cbind(results_m1,results_m1_sd)
            m1_pw[(cid-1)*dim(NT)[1]+k,(pwgrid*(j-1)+1):(pwgrid*(j-1)+pwgrid)] = Power(mb,e1,rep) # length = no. alternative values
            m1_size[(cid-1)*dim(NT)[1]+k,j] = m1_pw[(cid-1)*dim(NT)[1]+k,pwgrid*(j-1)+(pwgrid-1)/2+1]; rm(e1) 
          }
          if (Tobs-1>3) { # Variance
            results_var = mc_results1[,c(9)]
            results_var_sd = mc_results1[,c(10)]
            var_bias[(cid-1)*dim(NT)[1]+k,j] = Bias(results_var, vb)
            var_rmse[(cid-1)*dim(NT)[1]+k,j] = RMSE(results_var, vb)
            v1 = cbind(results_var,results_var_sd)
            var_pw[(cid-1)*dim(NT)[1]+k,(pwgrid*(j-1)+1):(pwgrid*(j-1)+pwgrid)] = Power(vb,v1,rep) # length = no. alternative values
            var_size[(cid-1)*dim(NT)[1]+k,j] = var_pw[(cid-1)*dim(NT)[1]+k,pwgrid*(j-1)+(pwgrid-1)/2+1]; rm(v1)
          }
        }
      }
    }
    
    #### Tables of E(phi_i)
    #########################################################################
    sn = sn1[idx]
    addWorksheet(wb, sn)
    if (idx == 1) {
      writeData(wb, sn, x = "Table S.20: Bias, RMSE, and size of FDAC estimator of E(phi_i) in a heterogeneous panel AR(1) model with Gaussian errors", startCol = 1, startRow = 1, colNames = FALSE)
    }
    if (idx == 2) {
      writeData(wb, sn, x = "Table S.22: Bias, RMSE, and size of FDAC estimator of E(phi_i) in a heterogeneous panel AR(1) model with Gaussian errors and GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
    }
    if (idx == 3) {
      writeData(wb, sn, x = "Table S.24: Bias, RMSE, and size of FDAC estimator of E(phi_i) in a heterogeneous panel AR(1) model with non-Gaussian errors", startCol = 1, startRow = 1, colNames = FALSE)
    }
    if (idx == 4) {
      writeData(wb, sn, x = "Table S.26: Bias, RMSE, and size of FDAC estimator of E(phi_i) in a heterogeneous panel AR(1) model with non-Gaussian errors and GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
    }
    
    Nlist = c(100,200,500,1000,5000); Tlist = c(4,5,6,8,10)
    NT = expand.grid(Nlist,Tlist); NT = cbind(NT[,2],NT[,1])
    tab = matrix(,nc*(length(Tlist)+2)-1,3*(length(Nlist)+1)) 
    tab2 = matrix(,nc*(length(Tlist)+2)-1,3*(length(Nlist)+1)) 
    
    #### Put numbers into the respective cells
    for (r1 in 1:nc) {
      for (r2 in 1:length(Tlist)) {
        tab2[1+r2+(r1-1)*(length(Tlist)+2),1] = Tlist[r2]
      }
      tab[(2+(r1-1)*(length(Tlist)+2)):(1+length(Tlist)+(r1-1)*(length(Tlist)+2)),(1+1):(1+length(Nlist))] = matrix(m1_bias[(1+(r1-1)*(dim(NT)[1])):((r1)*(dim(NT)[1])),1],length(Tlist),length(Nlist))
      tab[(2+(r1-1)*(length(Tlist)+2)):(1+length(Tlist)+(r1-1)*(length(Tlist)+2)),(2+length(Nlist)+1):(2+2*length(Nlist))] = matrix(m1_rmse[(1+(r1-1)*(dim(NT)[1])):((r1)*(dim(NT)[1])),1],length(Tlist),length(Nlist))
      tab[(2+(r1-1)*(length(Tlist)+2)):(1+length(Tlist)+(r1-1)*(length(Tlist)+2)),(3+2*length(Nlist)+1):(3+3*length(Nlist))] = matrix(m1_size[(1+(r1-1)*(dim(NT)[1])):((r1)*(dim(NT)[1])),1],length(Tlist),length(Nlist))
    }
    
    #### Change the formats of each column
    for (col in c(2:6,8:12)) {   # bias, RMSE
      v0 = tab[,col]; v1 = v0
      for (i in 1:length(v0)) {
        if (is.na(v0[i]) == 0) {
          v1[i] = format(round(v0[i], 3), nsmall = 3) 
        } else {
          v1[i] = ""
        }
      }
      tab2[,col] = v1; rm(v0,v1)
    }
    for (col in c(14:18)) {   # size (*100)
      v0 = tab[,col]; v1 = v0
      for (i in 1:length(v0)) {
        if (is.na(v0[i]) == 0) {
          v1[i] = format(round(v0[i]*100, 1), nsmall = 1) 
        } else {
          v1[i] = ""
        }
      }
      tab2[,col] = v1; rm(v0,v1)
    }
    
    h = tab2
    h1 = c("","Bias",rep("",4),"","RMSE",rep("",4),"","Size (*100)",rep("",4))
    h2 = c("T/n",rep(c("100","200","500","1,000","5,000",""),2),"100","200","500","1,000","5,000")
    h = rbind(h1,h2,h)
    rownames(h) <- NULL
    colnames(h) <- NULL
    writeData(wb,sn, x = h, startCol = 1, startRow = 2,colNames = FALSE, rowNames = FALSE)
    writeData(wb, sn, x = "phi_i = mu_phi + v_i and v_i~IIDU(-a,a) with mu_phi = 0.4 and a = 0.3", startCol = 1, startRow = 4, colNames = FALSE)
    writeData(wb, sn, x = "phi_i = mu_phi + v_i and v_i~IIDU(-a,a) with mu_phi = 0.4 and a = 0.5", startCol = 1, startRow = 11, colNames = FALSE)
    writeData(wb, sn, x = "Pr(phi_i = 0.2) = 0.3 and Pr(phi_i = 0.8) = 0.7 with mu_phi = 0.62", startCol = 1, startRow = 18, colNames = FALSE)
    mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 1)
    mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 4)
    mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 11)
    mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 18)
    mergeCells(wb, sheet = sn, cols = 2:6, rows = 2)
    mergeCells(wb, sheet = sn, cols = 8:12, rows = 2)
    mergeCells(wb, sheet = sn, cols = 14:18, rows = 2)

    addStyle(wb,sn,style = center_style, rows = 2:3,cols = 1:(ncol(h)), gridExpand = T)
    addStyle(wb,sn,style = right, rows = c(5:10,12:17,19:23),cols = 1:(ncol(h)), gridExpand = T)
    addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = T,stack=T)
    addStyle(wb,sn,style = bbs, rows = 2,cols = c(2:6,8:12,14:18), gridExpand = T,stack=T)
    addStyle(wb,sn,style = bbs, rows = c(3,4,11,18),cols = 1:(ncol(h)), gridExpand = T,stack=T)  
    addStyle(wb,sn,style = lbs, rows = (nrow(h)+1),cols = 1:(ncol(h)), gridExpand = T,stack=T)
    #########################################################################
    rm(tab,tab2)
    
    #### Tables of Var(phi_i)
    #########################################################################
    sn = sn2[idx]
    addWorksheet(wb, sn)
    if (idx == 1) {
      writeData(wb, sn, x = "Table S.21: Bias, RMSE, and size of FDAC estimator of Var(phi_i) in a heterogeneous panel AR(1) model with Gaussian errors", startCol = 1, startRow = 1, colNames = FALSE)
    }
    if (idx == 2) {
      writeData(wb, sn, x = "Table S.23: Bias, RMSE, and size of FDAC estimator of Var(phi_i) in a heterogeneous panel AR(1) model with Gaussian errors and GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
    }
    if (idx == 3) {
      writeData(wb, sn, x = "Table S.25: Bias, RMSE, and size of FDAC estimator of Var(phi_i) in a heterogeneous panel AR(1) model with non-Gaussian errors", startCol = 1, startRow = 1, colNames = FALSE)
    }
    if (idx == 4) {
      writeData(wb, sn, x = "Table S.27: Bias, RMSE, and size of FDAC estimator of Var(phi_i) in a heterogeneous panel AR(1) model with non-Gaussian errors and GARCH effects", startCol = 1, startRow = 1, colNames = FALSE)
    }
    
    Nlist = c(100,200,500,1000,5000); Tlist = c(4,5,6,8,10)
    NT = expand.grid(Nlist,Tlist); NT = cbind(NT[,2],NT[,1])
    tab = matrix(,nc*(length(Tlist)-1+2)-1,3*(length(Nlist)+1)) 
    tab2 = matrix(,nc*(length(Tlist)-1+2)-1,3*(length(Nlist)+1)) 
    
    #### Put numbers into the respective cells
    for (r1 in 1:nc) {
      for (r2 in 1:(length(Tlist)-1)) {
        tab2[1+r2+(r1-1)*(length(Tlist)-1+2),1] = Tlist[r2+1]
      }
      tab[(2+(r1-1)*(length(Tlist)-1+2)):(1+length(Tlist)-1+(r1-1)*(length(Tlist)-1+2)),(1+1):(1+length(Nlist))] = matrix(var_bias[(6+(r1-1)*(dim(NT)[1])):((r1)*(dim(NT)[1])),1],length(Tlist)-1,length(Nlist))
      tab[(2+(r1-1)*(length(Tlist)-1+2)):(1+length(Tlist)-1+(r1-1)*(length(Tlist)-1+2)),(2+length(Nlist)+1):(2+2*length(Nlist))] = matrix(var_rmse[(6+(r1-1)*(dim(NT)[1])):((r1)*(dim(NT)[1])),1],length(Tlist)-1,length(Nlist))
      tab[(2+(r1-1)*(length(Tlist)-1+2)):(1+length(Tlist)-1+(r1-1)*(length(Tlist)-1+2)),(3+2*length(Nlist)+1):(3+3*length(Nlist))] = matrix(var_size[(6+(r1-1)*(dim(NT)[1])):((r1)*(dim(NT)[1])),1],length(Tlist)-1,length(Nlist))
    }
    
    #### Change the formats of each column
    for (col in c(2:6,8:12)) {   # bias, RMSE
      v0 = tab[,col]; v1 = v0
      for (i in 1:length(v0)) {
        if (is.na(v0[i]) == 0) {
          v1[i] = format(round(v0[i], 3), nsmall = 3) 
        } else {
          v1[i] = ""
        }
      }
      tab2[,col] = v1; rm(v0,v1)
    }
    for (col in c(14:18)) {   # size (*100)
      v0 = tab[,col]; v1 = v0
      for (i in 1:length(v0)) {
        if (is.na(v0[i]) == 0) {
          v1[i] = format(round(v0[i]*100, 1), nsmall = 1) 
        } else {
          v1[i] = ""
        }
      }
      tab2[,col] = v1; rm(v0,v1)
    }
    
    h = tab2
    h1 = c("","Bias",rep("",4),"","RMSE",rep("",4),"","Size (*100)",rep("",4))
    h2 = c("T/n",rep(c("100","200","500","1,000","5,000",""),2),"100","200","500","1,000","5,000")
    h = rbind(h1,h2,h)
    rownames(h) <- NULL
    colnames(h) <- NULL
    writeData(wb,sn, x = h, startCol = 1, startRow = 2,colNames = FALSE, rowNames = FALSE)
    writeData(wb, sn, x = "Var(phi_i) = 0.03 where phi_i = mu_phi + v_i and v_i~IIDU(-a,a) with mu_phi = 0.4 and a = 0.3", startCol = 1, startRow = 4, colNames = FALSE)
    writeData(wb, sn, x = "Var(phi_i) = 0.083 where phi_i = mu_phi + v_i and v_i~IIDU(-a,a) with mu_phi = 0.4 and a = 0.5", startCol = 1, startRow = 10, colNames = FALSE)
    writeData(wb, sn, x = "Var(phi_i) = 0.076 where Pr(phi_i = 0.2) = 0.3 and Pr(phi_i = 0.8) = 0.7", startCol = 1, startRow = 16, colNames = FALSE)
    mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 1)
    mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 4)
    mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 10)
    mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 16)
    mergeCells(wb, sheet = sn, cols = 2:6, rows = 2)
    mergeCells(wb, sheet = sn, cols = 8:12, rows = 2)
    mergeCells(wb, sheet = sn, cols = 14:18, rows = 2)
    
    addStyle(wb,sn,style = center_style, rows = 2:3,cols = 1:(ncol(h)), gridExpand = T)
    addStyle(wb,sn,style = right, rows = c(5:9,11:15,17:21),cols = 1:(ncol(h)), gridExpand = T)
    addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = T,stack=T)
    addStyle(wb,sn,style = bbs, rows = 2,cols = c(2:6,8:12,14:18), gridExpand = T,stack=T)
    addStyle(wb,sn,style = bbs, rows = c(3,4,10,16),cols = 1:(ncol(h)), gridExpand = T,stack=T)  
    addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = T,stack=T)
    addStyle(wb,sn,style = lbs, rows = (nrow(h)+1),cols = 1:(ncol(h)), gridExpand = T,stack=T)
    #########################################################################
    rm(tab,tab2)
    
  } else {
    cat(paste("The MC results of ",sn1[idx]," and ",sn2[idx]," are not found.",sep=""))
  }
  
}
##############################################################################

# Save the workbook to an Excel file
saveWorkbook(wb, file = "HetroAR_MC_FDAC_moments.xlsx",overwrite = TRUE)
cat("The MC results have been written to the excel file HetroAR_MC_FDAC_moments.xlsx.")














