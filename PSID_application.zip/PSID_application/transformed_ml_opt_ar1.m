function [theta,fval,exitflag,output,lambda,grad,hessian]=transformed_ml_opt_ar1(n,T,dy,Phi,Omegastar,theta0,lq,uq)
 
% maximum likelihood routine. see the program transformed_ml.m
 
options = optimset('Display','off','GradObj','on','Hessian','user-supplied','Algorithm','trust-region-reflective'); % Turn off Display
 
[theta,fval,exitflag,output,lambda,grad,hessian]=fmincon(@likelihood_ar1,theta0,[],[],[],[],lq,uq,[],options); 
 
function [likelihood,g,H]=likelihood_ar1(theta)
 
    phi   = theta(1:2,1);
    omega = theta(3,1);
    sigma = theta(4,1);
    
    Omegastar(1,1) = omega;
    inOmegastar = pinv(Omegastar);
 
    lik1 = (n*T/2)*log(sigma) + (n/2)*log(1+T*(omega-1));
 
    for i=1:n
    DWi = [1,   0;
           zeros(T-1,1), dy(1:T-1,i)];    
    Dui =  dy(:,i) - DWi*phi;
     lik1 = lik1 + 0.5* Dui'*inOmegastar* Dui/sigma;
    end
 
likelihood = lik1;
g = -first_derivative_ar1(n,T,dy,Phi,phi,omega,sigma,inOmegastar);
H = -second_derivative_ar1(n,T,dy,Phi,phi,omega,sigma,inOmegastar);
 
end
end
