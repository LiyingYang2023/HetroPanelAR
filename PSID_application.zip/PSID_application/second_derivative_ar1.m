function [secder]=second_derivative_ar1(n,T,dy,Phi,phi,omega,sig2_u,inOmegastar)
 
% vector of second derivatives of the trasformed log-likelihood in Hsiao et
% al 2002. see transformed_ml.m
 
g = 1+T*(omega-1);
secder = zeros(4,4);
 
for i=1:n
    DWi = [1,   0;
           zeros(T-1,1), dy(1:T-1,i)];    
    Dui =  dy(:,i) - DWi*phi;
    secder(1:2,1:2) = secder(1:2,1:2) + (1/sig2_u)*DWi'*inOmegastar*DWi;
    secder(3,3)     = secder(3,3)     + (T/(sig2_u*g^3))*Dui'*Phi*Dui;
    secder(4,4)     = secder(4,4)     + (1/sig2_u^3)*Dui'*inOmegastar*Dui;
    secder(1:2,3)   = secder(1:2,3)   + (1/(sig2_u*g^2))*DWi'*Phi*Dui;
    secder(1:2,4)   = secder(1:2,4)   + (1/(sig2_u*g^2))*DWi'*inOmegastar*Dui;
    secder(3,4)     = secder(3,4)     + (1/(2*sig2_u^2*g^2))*Dui'*Phi*Dui;
 end
 
  secder=-secder;
  
  secder(3,3)   = secder(3,3) + (n*T^2)/(2*g^2);
  secder(4,4)   = secder(4,4) + (n*T)/(2*sig2_u^2);
  secder(3,1:2) = secder(1:2,3)';
  secder(4,1:2) = secder(1:2,4)';
  secder(4,3)   = secder(3,4);
  

