## Source Files for the Empirical Application
# Functions

K = function(u){
  # 0.75 * (1-u^2) * (u > -1) * (u < 1)
  dnorm(u)
}

### Square Integrated Kernel
K22 = function(res){
  ulist = (-1*res):res / res
  sum( K(ulist)^2 / (2*res+1) * 2 )
}

### Function Row Product
RowProd = function(U){
  nc = ncol(U)
  ones = as.matrix(array(1,nc))
  u = log(U) %*% ones
  exp(u)
}

### Function Multivariate Normal Random Number Generator
rmultnorm = function(n, mu, vmat, tol=1e-07){
  p = ncol(vmat)
  if (length(mu)!=p)
    stop("mu vector is the wrong length")
  if (max(abs(vmat - t(vmat))) > tol)
    stop("vmat not symmetric")
  vs = svd(vmat)
  vsqrt = t(vs$v %*% (t(vs$u) * sqrt(vs$d)))
  ans = matrix(rnorm(n * p), nrow=n) %*% vsqrt
  ans = sweep(ans, 2, mu, "+")
  dimnames(ans) = list(NULL, dimnames(vmat)[[2]])
  return(ans)
}

### Function Multivariate Normal Density
dmultnorm = function(X,M,V){
  dim = ncol(X)
  d = exp( -0.5 * ( t(X-M)%*%solve(V)%*%(X-M) ) )
  d / ( (2*3.1415)^dim * abs(det(V)) )^.5
}

### Function Generate Random Parameters (Y1,Alpha,Beta,Sigma)
GenRandomPara = function(N,NumPara,M,S,r){
  V = S %*% t(S)
  R = array(r,dim=c(NumPara,NumPara)) + diag(1-r,NumPara,NumPara)
  V = V * R
  para = array(0,dim=c(N,NumPara))
  for(i in 1:N){
    para[i,1:NumPara] = rmultnorm(1, M, vmat=V)
  }
  para
}

### Function Generate Random Processes Y
GenRandomY = function(N,T,para,sigma){
  Y = array(0,dim=c(N,T))
  Y[1:N,1] = para[1:N,1]
  epsilon = rnorm(N*(T-1))
  epsilon = matrix(epsilon,N,T-1)
  for(t in 1:(T-1)){
    ### Below: Y_{t+1} = alpha + beta Y_t + sigma 
    Y[1:N,(t+1)] = para[1:N,2] + para[1:N,3] * Y[1:N,t] + sigma * epsilon[1:N,t]
  }
  Y
}

### Function Estimate Parameters for Time Series (Takes ROW Vector of Series Y)
GetParaHat = function(Y){
  Y = t( as.matrix(Y) )
  T = ncol(as.matrix(Y))
  Xmat = t( rbind(1, Y[1:(T-1)]) )
  Ymat = t( Y[2:T] )
  
  alpha_beta = solve(t(Xmat)%*%Xmat) %*% t(Xmat)%*%t(Ymat)
  sigma = (t(t(Ymat)-Xmat%*%alpha_beta) %*% (t(Ymat)-Xmat%*%alpha_beta) / T )^.5
  rbind(alpha_beta,log(sigma))
}

### Function Generate A Sample of (alpha hat, beta hat, log sigma hat)
GenSample = function(N,T,NumPara,M,S,r){
  para = GenRandomPara(N,NumPara,M,S,r)
  Y = GenRandomY(N,T,para)
  
  para_hat = array(0,dim=c(N,NumPara-1))
  for(i in 1:N){
    para_hat[i,1:(NumPara-1)] = t( GetParaHat(Y[i,1:T]) )
  }
  cbind(para[1:N,1] , para_hat)
}

### Function List of Parameters over Which to Integrate
GetList = function(NumPara, MinInt, MaxInt, ResInt){
  length = ResInt^NumPara
  list = array(0,dim=c(length,NumPara))
  idx_list = array(0,dim=c(length,NumPara))
  count = 1:(length) - 1
  for(i in 1:NumPara){
    idx_list[1:length,i] = count-floor(count/ResInt)*ResInt
    count = floor(count/ResInt)
  }
  idx_list = idx_list + 1
  # single_list = (1:ResInt - 0.5) * (MaxInt-MinInt)/ResInt + MinInt
  for(i in 1:NumPara){
    single_list = (1:ResInt - 0.5) * (MaxInt[i]-MinInt[i])/ResInt + MinInt[i]
    list[1:length,i] = single_list[idx_list[1:length,i]]
  }
  list
}

### Function Calculate Integral Operator (para_list - N matrix)
IntOperator = function(N,T,int_para_list,paneldata,sigma){
  list_length = nrow(int_para_list)
  alpha_list = int_para_list[1:list_length,1]
  beta_list = int_para_list[1:list_length,2]
  OperF = array(1,dim=c(list_length,N))
  
  for(i in 1:N){
    for(j in 2:T){
      OperF[1:list_length,i] = OperF[1:list_length,i] * dnorm( (paneldata[i,j] - alpha_list - beta_list * paneldata[i,j-1]) / sigma ) / sigma
    }
  }
  OperF
}

### Function Calculate Likelihood Integrand (para_list vector)
Integrand = function(int_para_list,MSR_hat,NumPara){
  # NumPara = 3
  list_length = nrow(int_para_list)
  M_hat = MSR_hat[1:NumPara]
  S_hat = MSR_hat[(NumPara+1):(2*NumPara)]
  R_hat = array(1,dim=c(NumPara,NumPara))
  V_hat = S_hat %*% t(S_hat)
  idx = 1
  for(i in 2:NumPara){
    for(j in 1:(i-1)){
      R_hat[i,j] = MSR_hat[2*NumPara+idx]
      R_hat[j,i] = R_hat[i,j]
      idx = idx + 1
    }
  }
  V_hat = V_hat * R_hat
  
  d_list = array(0,list_length)
  for(i in 1:list_length){
    d_list[i] = dmultnorm(as.matrix(int_para_list[i,1:NumPara]),M_hat,V_hat)
  }
  d_list
}

### Function Calculate Negative Log Likelihood
#NegativeLogLikelihood = function(MSR_hat,N,T,int_para_list,paneldata,Y1,y1,h,paneldata_w,paneldata_k,paneldata_ys){
NegativeLogLikelihood = function(MSR_hat,N,T,int_para_list,paneldata,Y1,y1,h){
  NumPara = ncol(int_para_list)
  Likelihood_Integrand = Integrand(int_para_list,MSR_hat,NumPara)
  ### Below is A Non_Weighted Likelihoods across i ###
  #OperF = IntOperator(N,T,int_para_list,paneldata,MSR_hat[6],paneldata_w,0,0,paneldata_k,0,0,paneldata_ys,0,0)
  OperF = IntOperator(N,T,int_para_list,paneldata,MSR_hat[6])
  OperF = t(OperF)
  Likelihood = OperF %*% as.matrix(Likelihood_Integrand)
  penalty = 100000000*sum((MSR_hat[3:4]<0)*(MSR_hat[3:4]^2)) + 0.001*sum(MSR_hat[3:4]^(-2)) + 100000000*(MSR_hat[5]^2>1)*((MSR_hat[5]-1)^2) + 1*MSR_hat[5]^2## PENALTY
  ### Below is A Weighted Sum of Log Likelihoods across i ###
  -1 * t(log(Likelihood)) %*% as.matrix( K((Y1- y1)/h) ) / N / h + penalty
}

### Function Calculate Agent-Wise Negative Log Likelihood
#AgentWiseNegativeLogLikelihood = function(MSR_hat,N,T,int_para_list,paneldata,Y1,y1,h,paneldata_w,paneldata_k,paneldata_ys){
AgentWiseNegativeLogLikelihood = function(MSR_hat,N,T,int_para_list,paneldata,Y1,y1,h){
  NumPara = ncol(int_para_list)
  Likelihood_Integrand = Integrand(int_para_list,MSR_hat,NumPara)
  ### Below is A Non_Weighted Likelihoods across i ###
  #OperF = IntOperator(N,T,int_para_list,paneldata,MSR_hat[6],paneldata_w,0,0,paneldata_k,0,0,paneldata_ys,0,0)
  OperF = IntOperator(N,T,int_para_list,paneldata,MSR_hat[6])
  OperF = t(OperF)
  Likelihood = OperF %*% as.matrix(Likelihood_Integrand)
  ### Below is to Avoid Infinite Log Likelihood
  # Likelihood = Likelihood + 0.0000000001
  ### Below is A Weighted Sum of Log Likelihoods across i ###
  -1 * (log(Likelihood)) * sqrt( as.matrix( K((Y1- y1)/h) ) / N / h )
}

tic <- function() {
  assign(".time1", Sys.time(), envir = .GlobalEnv)
}

toc <- function() {
  print(Sys.time() - get(".time1", envir = .GlobalEnv))
}

