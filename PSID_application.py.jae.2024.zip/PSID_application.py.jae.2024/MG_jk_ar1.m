function [coeff_mg,se_mg,coeff_mgjk,se_mgjk,coeff_mg2] = MG_jk_ar1(Y)
%% input data
%Y is (T+1) x n matrix
%Y = Y_ALL;
[T,n] = size(Y);
h = floor(T/2)-1; % numbers of obs in non-overlapping half panels
y = Y((T-2*h+1):T,:); % 2*h vector of outcome variable 
x = Y((T-2*h):T-1,:); % lagged variable
y1 = Y(T-h+1:T,:); % 1st half panel
x1 = Y(T-h:T-1,:);
y2 = Y(T-2*h:T-h-1,:); % 2nd half panel
x2 = Y(T-2*h-1:T-h-2,:); 

%% MG estimator based on OLS estimators
qt = diag(ones(1,2*h))- ones(2*h)./(2*h); 
hati_T = diag(x.'* qt * y)./ diag(x.'* qt * x); % column vector: individual LS estimators
qh = diag(ones(1,h))- ones(h)./(h); 
hati_h1 = diag(x1.'* qh * y1)./ diag(x1.'* qh * x1); % column vector
hati_h2 = diag(x2.'* qh * y2)./ diag(x2.'* qh * x2); % column vector
hati_jk1 = 2*hati_T-1/2*(hati_h1+hati_h2); % individual JK estimators 


%% report results
coeff_mg = mean(hati_T); 
coeff_mg2 = 1/n *(hati_T - mean(hati_T).* ones(n,1)).' * (hati_T - mean(hati_T).* ones(n,1));
se_mg = (1/n *(hati_T - mean(hati_T).* ones(n,1)).' * (hati_T - mean(hati_T).* ones(n,1))/n).^0.5;
coeff_mgjk = mean(hati_jk1);
se_mgjk = (1/n * (hati_jk1 - mean(hati_jk1).* ones(n,1)).' * (hati_jk1 - mean(hati_jk1).* ones(n,1))/n).^0.5;


