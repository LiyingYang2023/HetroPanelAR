###### An application of heterogeneous panel AR(1) model of income processes using the PSID data
###### Pesaran and Yang (2024) "Hetro Panel AR" 

rm(list=ls())

## Please change the path to the directory where "Hetro_AR_PSID_msw_functions.R" and data files are stored . 
# setwd('~/Downloads') 

source("Hetro_AR_PSID_msw_functions.R")

cat("\014") 

tic()

## Please install the following packages. 
# list.of.packages <- c("parallel","parallelly","openxlsx","R.matlab")
# new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
# if(length(new.packages)) install.packages(new.packages)

library(parallel) # mclapply
library(parallelly) # detect cores
library(openxlsx)
library(R.matlab)

numCores <- detectCores() - 1

cl <- makeCluster(numCores/2)

################################################################################

### Compute MSE estimates of mu_phi = E(phi_i) and Var(phi_i)
################################################################################
sub = c("PSID2_educ_76_80.mat","PSID2_educ_81_85.mat","PSID2_educ_86_90.mat","PSID2_educ_91_95.mat","PSID2_educ_76_85.mat","PSID2_educ_81_90.mat","PSID2_educ_86_95.mat")
# 4 (sub-)panels for 7 periods
est_beta_m1 = matrix(NA, 2*7, 5) 
est_beta_var = matrix(NA, 2*7, 5)

for (ids in 1:7) {
  mat = readMat(sub[ids])
  panel0 = t(mat[["Y.ALL"]])
  panel1 = t(mat[["Y.HSD"]])
  panel2 = t(mat[["Y.HSG"]])
  panel3 = t(mat[["Y.CLG"]])
  
  for (p in c(0,1,2,3)) {
    name = paste("panel",p,sep="")
    paneldata = get(name)
    
    ####################################################################
    N = nrow(paneldata)
    T = ncol(paneldata)
    
    k=1
    NumPara = 3
    ResInt = 10
    h = 1.06 * sd(paneldata[,1]) * length(paneldata[,1])^(-1/5)
    
    sav  = cbind(2)#0.5,1,2)   #Alpha
    sbv  = cbind(0.5)#0.1,0.25,0.5) #Beta
    mbv  = cbind(0.4)#,0.5)   #Beta
    sab = expand.grid(sav,sbv,mbv) 
    my1 = 10    #Y_1
    ma  = 5  #Alpha
    mb = sab[1,3]
    M = c(my1,ma,mb)
    sy1 = 1   #Y_1
    sa = sab[1,1]
    sb = sab[1,2]
    S = c(sy1,sa,sb)
    corr   = 0.5   #Correlation Coefficient
    sigma = 0.5
    
    MinInt = c( ma-sa, mb-sb)    # para_means - 2* para_stdvs
    MaxInt = c( ma+sa, mb+sb)    # para_means + 2* para_stdvs
    
    int_para_list = GetList(NumPara-1, MinInt, MaxInt, ResInt)
    
    Y1= paneldata[1:N,1]
    y1list = Y1
    numy1list = length(y1list)
    Nkernel = nrow(paneldata)
    Tkernel = ncol(paneldata)
    estimate_list = array(0, dim=c(nrow(as.matrix(y1list)),6))
    stderr_list = array(0, dim=c(nrow(as.matrix(y1list)),6))
    idx = 1
    
    localest = function(y1, paneldata){
      source("Hetro_AR_PSID_educ_functions.R")
      
      N = nrow(paneldata)
      T = ncol(paneldata)
      
      k=1
      NumPara = 3
      ResInt = 10
      h = 1.06 * sd(paneldata[,1]) * length(paneldata[,1])^(-1/5)
      
      sav  = cbind(2)#0.5,1,2)   #Alpha
      sbv  = cbind(0.5)#0.1,0.25,0.5) #Beta
      mbv  = cbind(0.4)#,0.5)   #Beta
      sab = expand.grid(sav,sbv,mbv) 
      my1 = 10    #Y_1
      ma  = 5  #Alpha
      mb = sab[1,3]
      M = c(my1,ma,mb)
      sy1 = 1   #Y_1
      sa = sab[1,1]
      sb = sab[1,2]
      S = c(sy1,sa,sb)
      corr   = 0.5   #Correlation Coefficient
      sigma = 0.5
      
      MinInt = c( ma-sa, mb-sb)    # para_means - 2* para_stdvs
      MaxInt = c( ma+sa, mb+sb)    # para_means + 2* para_stdvs
      
      int_para_list = GetList(NumPara-1, MinInt, MaxInt, ResInt)
      
      Y1= paneldata[1:N,1]
      y1list = Y1
      numy1list = length(y1list)
      Nkernel = nrow(paneldata)
      Tkernel = ncol(paneldata)
      estimate_list = array(0, dim=c(nrow(as.matrix(y1list)),6))
      stderr_list = array(0, dim=c(nrow(as.matrix(y1list)),6))
      idx = 1
      
      ### Initial Values of Estimates (conditional on Y_1 = y1) #####################
      M_hat = c(ma,mb) # NumPara=3 Conditional on Y_1=y1
      S_hat = c(sa,sb) # NumPara=3 Conditional on Y_1=y1
      R_hat = c(-corr) # NumPara*(NumPara)/2 = 1
      Sigma_hat = c(sigma)
      MSR_hat = rbind(as.matrix(M_hat),as.matrix(S_hat),as.matrix(R_hat),as.matrix(Sigma_hat))
      
      #results <- nlm(NegativeLogLikelihood,MSR_hat,N,T,int_para_list,paneldata,Y1,y1,h,paneldata_w,paneldata_k,paneldata_ys,hessian=TRUE) #,iterlim=MaxGaussNewtonIterations)
      results <- nlm(NegativeLogLikelihood,MSR_hat,Nkernel,Tkernel,int_para_list,paneldata,Y1,y1,h,hessian=TRUE) #,iterlim=MaxGaussNewtonIterations)
      est = results$estimate
      return(est)
    }
    
    clusterExport(cl, varlist = c("Y1", "localest", "paneldata"))
    
    estimate_list <- t(parSapply(cl, Y1, localest, paneldata))
    
    hatma = matrix(NA, ncol= dim(sab)[1], nrow=2)
    hatmb = matrix(NA, ncol= dim(sab)[1], nrow=2)
    hatva = matrix(NA, ncol= dim(sab)[1], nrow=2)
    hatvb = matrix(NA, ncol= dim(sab)[1], nrow=2)
    
    estimate_list = cbind(estimate_list,estimate_list[,1:2]^2)
    estimate_list = cbind(estimate_list,estimate_list[,3:4]^2)
    # COMPUTE THE MEAN PARAMETER ESTIAMTES #
    mean_para = colSums(estimate_list) / numy1list
    dev_para = estimate_list - t(array(mean_para,dim=c(10,numy1list)))
    # COMPUTE THE VARIANCE COVARIANCE MATRIX OF PARAMETER ESTIAMTES #
    var_para = t(dev_para)%*%dev_para / numy1list
    
    # STD ERR OF MEAN(ALPHA) #
    stderr_mean_alpha = var_para[1,1]^.5
    # STD ERR OF MEAN(BETA) #
    stderr_mean_beta = var_para[2,2]^.5
    
    # VARIANCE MATRICES FOR VARIOUS MOMENTS OF ALPHA AND BETA #
    S_alpha = array(0,dim=c(3,3))
    S_beta = array(0,dim=c(3,3))
    S_alpha[1,1] = cov(estimate_list[,3],estimate_list[,3])
    S_alpha[1,2] = cov(estimate_list[,3],estimate_list[,1]^2)
    S_alpha[1,3] = cov(estimate_list[,3],estimate_list[,1])
    S_alpha[2,1] = cov(estimate_list[,1]^2,estimate_list[,3])
    S_alpha[2,2] = cov(estimate_list[,1]^2,estimate_list[,1]^2)
    S_alpha[2,3] = cov(estimate_list[,1]^2,estimate_list[,1])
    S_alpha[3,1] = cov(estimate_list[,1],estimate_list[,3])
    S_alpha[3,2] = cov(estimate_list[,1],estimate_list[,1]^2)
    S_alpha[3,3] = cov(estimate_list[,1],estimate_list[,1])
    S_beta[1,1] = cov(estimate_list[,4],estimate_list[,4])
    S_beta[1,2] = cov(estimate_list[,4],estimate_list[,2]^2)
    S_beta[1,3] = cov(estimate_list[,4],estimate_list[,2])
    S_beta[2,1] = cov(estimate_list[,2]^2,estimate_list[,4])
    S_beta[2,2] = cov(estimate_list[,2]^2,estimate_list[,2]^2)
    S_beta[2,3] = cov(estimate_list[,2]^2,estimate_list[,2])
    S_beta[3,1] = cov(estimate_list[,2],estimate_list[,4])
    S_beta[3,2] = cov(estimate_list[,2],estimate_list[,2]^2)
    S_beta[3,3] = cov(estimate_list[,2],estimate_list[,2])
    stderr_sqrtvar_alpha = sqrt( c(1,1,2) %*% S_alpha %*% c(1,1,2) / (mean_para[9]+mean_para[7]-mean_para[1]^2) / 4 / N )
    stderr_sqrtvar_beta = sqrt( c(1,1,2) %*% S_beta %*% c(1,1,2) / (mean_para[10]+mean_para[8]-mean_para[2]^2) / 4 / N )
    
    # DISPLAY OUTPUT OF MEAN AND VARIANCE #
    hatma[,k] = cbind(mean_para[1], stderr_mean_alpha)
    hatva[,k] = cbind((mean_para[9]+mean_para[7]-mean_para[1]^2), stderr_sqrtvar_alpha*2*(mean_para[9]+mean_para[7]-mean_para[1]^2)^.5)
    hatmb[,k] = cbind(mean_para[2], stderr_mean_beta)
    hatvb[,k] = cbind((mean_para[10]+mean_para[8]-mean_para[2]^2), stderr_sqrtvar_beta*2*(mean_para[10]+mean_para[8]-mean_para[2]^2)^.5)
    
    ####################################################################
    est_beta_m1[(1+(ids-1)*2):(2+(ids-1)*2),(p+1+1*(p>0))] = hatmb
    est_beta_var[(1+(ids-1)*2):(2+(ids-1)*2),(p+1+1*(p>0))] = hatvb
    nam = paste("localest_",ids,"_p", p, sep = ""); assign(nam, estimate_list)
    nam = paste("mean_para_",ids,"_p",p, sep = ""); assign(nam, mean_para)  
    nam = paste("S_alpha_",ids,"_p",p,sep = ""); assign(nam, S_alpha) 
    nam = paste("S_beta_",ids,"_p",p,sep = ""); assign(nam, S_beta)  
    nam = paste("beta",ids,"_p",p,sep = "");
    rm(nam); rm(mean_para,var_para,S_alpha,S_beta,stderr_mean_alpha,stderr_mean_beta,estimate_list)
    rm(mb,sa,sb)
  }
  nam = paste("est_beta_m1_",ids,sep = ""); assign(nam,est_beta_m1)
  nam = paste("est_beta_var_",ids,sep = ""); assign(nam,est_beta_var)
}

save(list = c('est_beta_m1','est_beta_var'), file = 'HetroAR_PSID_educ_msw.RData')
################################################################################

stopCluster(cl)

toc()
