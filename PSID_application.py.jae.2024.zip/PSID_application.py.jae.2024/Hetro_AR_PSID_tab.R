###### An application of heterogeneous panel AR(1) model of income processes using the PSID data
###### Pesaran and Yang (2024) "Hetro Panel AR"
rm(list=ls())

## Please change the path to the directory where the estimation outcomes are stores. 
# setwd('~/Downloads') 

## Please install the following packages. 
# list.of.packages <- c("openxlsx","R.matlab")
# new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
# if(length(new.packages)) install.packages(new.packages)

library(openxlsx)
library(R.matlab)


### Tabulate estimation results: Tables 1, S.19-S.23
##############################################################################
# Create a style for center-aligning the numbers
center_style <- createStyle(halign = "center")
right <- createStyle(halign = "right")
left <- createStyle(halign = "left")
bbs <- createStyle(border = "bottom",borderStyle="thin")
lbs <- createStyle(border = "bottom",borderStyle="double")
tbs <- createStyle(border = "top",borderStyle="double")
wrap_text_style <- createStyle(wrapText = TRUE)

wb <- createWorkbook()
list = c('Table 1','Table S.19','Table S.20','Table S.21','Table S.22','Table S.23')

# Load estimation results of FDAC and HomoGMM estimators
en = -99999; temp1 = tryCatch(readMat('PSID2_educ.mat'),error=function(e) print(en))

# Load estimation results of the MSW estimators
temp2 = tryCatch(load('Hetro_AR_PSID_msw.RData'),error=function(e) print(en))


if ( is.list(temp1) == TRUE ) {
  df = readMat('PSID2_educ.mat') 
  
  if (temp2[1] == en) {
    est_beta_m1 = matrix(,2*7,5) 
    est_beta_var = matrix(,2*7,5)
    print("The file 'Hetro_AR_PSID_msw.RData' of MSW estimation results are not found.")
  } 
  
  # Tabulate estimation results of E(phi_i)
  for (id in c(1,2,3)) {
    sn = list[id]
    addWorksheet(wb, sn)
    if (id==1) {
      writeData(wb, sn, x = "Table 1: Estimates of mean persistence (mu_phi = E(phi_i)) of log real earnings in a panel AR(1) model with a common linear trend using PSID data over 1991-1995 and 1986-1995", startCol = 1, startRow = 1, colNames = FALSE)
      pid = c(4,7); h1 = c("","1991-1995, T=5",rep("",5),"1986-1995, T=10",rep("",4))
    }
    if (id==2) {
      writeData(wb, sn, x = "Table S.19: Estimates of mean persistence (mu_phi = E(phi_i)) of log real earnings in a panel AR(1) model with a common linear trend using the PSID data over the sub-periods 1976-1980, 1981-1985 and 1986-1990", startCol = 1, startRow = 1, colNames = FALSE)
      pid = c(1,2,3); h1 = c("","1976-1980, T=5",rep("",5),"1981-1985, T=5",rep("",5),"1986-1990, T=5",rep("",4))
    }
    if (id==3) {
      writeData(wb, sn, x = "Table S.20: Estimates of mean persistence (mu_phi = E(phi_i)) of log real earnings in a panel AR(1) model with a common linear trend using the PSID data over the sub-periods 1976-1985 and 1981-1990", startCol = 1, startRow = 1, colNames = FALSE)
      pid = c(5,6); h1 = c("","1976-1985, T=10",rep("",5),"1981-1990, T=10",rep("",4))
    }
    
    tab = matrix(,16,length(pid)*(5+1)-1)
    tab2 = matrix(,16,length(pid)*(5+1)-1)
    for (j in 1:length(pid)) {
      s = pid[j]
      tab[,(1+(j-1)*6):(5+(j-1)*6)] = df$m1[,,s];
      tab[12:13,(1+(j-1)*6):(5+(j-1)*6)] = est_beta_m1[(1+(s-1)*2):(2+(s-1)*2),];
    }
    tab2[which(is.na(tab)==F)] = sprintf("%.3f", tab[which(is.na(tab)==F)] )
    for (i in c(3,5,7,11,13)) { # Format of S.E.
      for (j in 1:ncol(tab2)) {
        if (is.na(tab2[i,j])==F) {
          tab2[i,j] = paste0("(",tab2[i,j],")",sep="")
        }
      }
    }
    for (i in c(16)) { # Format of n
      for (j in 1:ncol(tab2)) {
        if (is.na(tab2[i,j])==F) {
          tab2[i,j] = sprintf("%.0f",tab[i,j])
        }
      }
    }
    if (length(pid)==2) {
      tab2[1,] = rep("",11)  
      tab2[8,] = rep("",11)
      tab2[9,] = rep("",11)  
      tab2[14,] = rep("",11)  
    } else {
      tab2[1,] = rep("",17)  
      tab2[8,] = rep("",17)
      tab2[9,] = rep("",17)  
      tab2[14,] = rep("",17)  
      tab2[,14] = rep("",16)   
    }
    tab2[,2] = rep("",16)  
    tab2[,8] = rep("",16)    
    c1 = c("Homogeneous slopes","AAH","","AB","","BB","","","Heterogeneous slopes","FDAC","","MSW","","","Common linear trend","n")
    tab3 = cbind(c1,tab2)
    h2 = rep(c("","All","","Category by education","",""),2)
    h3 = rep(c("","categories","","HSD","HSG","CLG"),2)
    if (length(pid)>2) {
      h2 = rep(c("","All","","Category by education","",""),3)
      h3 = rep(c("","categories","","HSD","HSG","CLG"),3)
    }
    h = rbind(h1,h2,h3,tab3)
    
    rownames(h) <- NULL
    colnames(h) <- NULL
    writeData(wb,sn, x = h, startCol = 1, startRow = 2,colNames = FALSE, rowNames = FALSE)
    mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 1)
    mergeCells(wb, sheet = sn, cols = 2:6, rows = 2)
    mergeCells(wb, sheet = sn, cols = 8:12, rows = 2)
    mergeCells(wb, sheet = sn, cols = 4:6, rows = 3)
    mergeCells(wb, sheet = sn, cols = 10:12, rows = 3)
    if (length(pid)>2) {
      mergeCells(wb, sheet = sn, cols = 14:18, rows = 2)    
      mergeCells(wb, sheet = sn, cols = 16:18, rows = 3)    
    }
    
    addStyle(wb,sn,style = center_style, rows = 6:(nrow(h)+1), cols = 2:(ncol(h)), gridExpand = TRUE)
    addStyle(wb,sn,style = center_style, rows = 2:4, cols = 1:(ncol(h)), gridExpand = TRUE)
    addStyle(wb,sn,style = center_style, rows = 2:(nrow(h)+1), cols = 1, gridExpand = TRUE)  
    addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = bbs, rows = 2,cols = c(2:6,8:12), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = bbs, rows = 3,cols = c(4:6,10:12), gridExpand = TRUE,stack=TRUE)
    if (length(pid)>2) {
      addStyle(wb,sn,style = bbs, rows = 2,cols = c(14:18), gridExpand = TRUE,stack=TRUE)  
      addStyle(wb,sn,style = bbs, rows = 3,cols = c(16:18), gridExpand = TRUE,stack=TRUE)
    }
    addStyle(wb,sn,style = bbs, rows = c(4,19),cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = lbs, rows = (nrow(h)+1),cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)  
    
    rm(tab,tab2,tab3,h)
  }
  
  # Tabulate estimation results of Var(phi_i)
  for (id in c(4,5,6)) {
    sn = list[id]
    addWorksheet(wb, sn)
    if (id==4) {
      writeData(wb, sn, x = "Table S.21: Estimates of variance of heterogeneous persistence (sigma_phi^2) of log real earnings in a panel AR(1) model with a common linear trend using the PSID data over the sub-periods 1991-1995 and 1986-1995", startCol = 1, startRow = 1, colNames = FALSE)
      pid = c(4,7); h1 = c("","1991-1995, T=5",rep("",5),"1986-1995, T=10",rep("",4))
    }
    if (id==5) {
      writeData(wb, sn, x = "Table S.22: Estimates of variance of heterogeneous persistence (sigma_phi^2) of log real earnings in a panel AR(1) model with a common linear trend using the PSID data over the sub-periods 1976-1985 and 1981-1990", startCol = 1, startRow = 1, colNames = FALSE)
      pid = c(5,6); h1 = c("","1976-1985, T=10",rep("",5),"1981-1990, T=10",rep("",4))
    }
    if (id==6) {
      writeData(wb, sn, x = "Table S.23: Estimates of variance of heterogeneous persistence (sigma_phi^2) of log real earnings in a panel AR(1) model with a common linear trend using the PSID data over the sub-periods 1976-1980, 1981-1985, and 1986-1990", startCol = 1, startRow = 1, colNames = FALSE)
      pid = c(1,2,3); h1 = c("","1976-1980, T=5",rep("",5),"1981-1985, T=5",rep("",5),"1986-1990, T=5",rep("",4))
    }
    
    tab = matrix(,5,length(pid)*(5+1)-1)
    tab2 = matrix(,5,length(pid)*(5+1)-1)
    for (j in 1:length(pid)) {
      s = pid[j]
      tab[,(1+(j-1)*6):(5+(j-1)*6)] = df$var[,,s];
      tab[3:4,(1+(j-1)*6):(5+(j-1)*6)] = est_beta_var[(1+(s-1)*2):(2+(s-1)*2),];
    }
    tab2[which(is.na(tab)==F)] = sprintf("%.3f", tab[which(is.na(tab)==F)] )
    for (i in c(2,4)) { # Format of S.E.
      for (j in 1:ncol(tab2)) {
        if (is.na(tab2[i,j])==F) {
          tab2[i,j] = paste0("(",tab2[i,j],")",sep="")
        }
      }
    }
    for (i in c(5)) { # Format of n
      for (j in 1:ncol(tab2)) {
        if (is.na(tab2[i,j])==F) {
          tab2[i,j] = sprintf("%.0f",tab[i,j])
        }
      }
    }
    if (length(pid)>2) {
      tab2[,14] = rep("",5)   
    }
    tab2[,2] = rep("",5)  
    tab2[,8] = rep("",5)   
    c1 = c("FDAC","","MSW","","n")
    tab3 = cbind(c1,tab2)
    if (length(pid)==2) {
      h2 = rep(c("","All","","Category by education","",""),2)
      h3 = rep(c("","categories","","HSD","HSG","CLG"),2)
    } else {
      h2 = rep(c("","All","","Category by education","",""),3)
      h3 = rep(c("","categories","","HSD","HSG","CLG"),3)
    }
    h = rbind(h1,h2,h3,tab3)
    rownames(h) <- NULL
    colnames(h) <- NULL
    writeData(wb,sn, x = h, startCol = 1, startRow = 2,colNames = FALSE, rowNames = FALSE)
    mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 1)
    mergeCells(wb, sheet = sn, cols = 2:6, rows = 2)
    mergeCells(wb, sheet = sn, cols = 8:12, rows = 2)
    mergeCells(wb, sheet = sn, cols = 4:6, rows = 3)
    mergeCells(wb, sheet = sn, cols = 10:12, rows = 3)
    if (length(pid)>2) {
      mergeCells(wb, sheet = sn, cols = 14:18, rows = 2)    
      mergeCells(wb, sheet = sn, cols = 16:18, rows = 3)    
    }
    
    addStyle(wb,sn,style = center_style, rows = 6:(nrow(h)+1), cols = 2:(ncol(h)), gridExpand = TRUE)
    addStyle(wb,sn,style = center_style, rows = 2:5, cols = 1:(ncol(h)), gridExpand = TRUE)
    addStyle(wb,sn,style = center_style, rows = 2:(nrow(h)+1), cols = 1, gridExpand = TRUE)  
    addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = bbs, rows = 2,cols = c(2:6,8:12), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = bbs, rows = 3,cols = c(4:6,10:12), gridExpand = TRUE,stack=TRUE)
    if (length(pid)>2) {
      addStyle(wb,sn,style = bbs, rows = 2,cols = c(14:18), gridExpand = TRUE,stack=TRUE)  
      addStyle(wb,sn,style = bbs, rows = 3,cols = c(16:18), gridExpand = TRUE,stack=TRUE)
    }
    addStyle(wb,sn,style = bbs, rows = c(4,8),cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    addStyle(wb,sn,style = lbs, rows = (nrow(h)+1),cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
    
    rm(tab,tab2,tab3,h)
  }
  
  saveWorkbook(wb, file = "HetroAR_PSID_educ_results.xlsx",overwrite = TRUE)
  cat("The MC results have been written to the excel file HetroAR_PSID_educ_results.xlsx.")
} else {
  print("The file 'PSID2_educ.mat' of FDAC and HomoGMM estimation results are not found.")
}
##############################################################################
