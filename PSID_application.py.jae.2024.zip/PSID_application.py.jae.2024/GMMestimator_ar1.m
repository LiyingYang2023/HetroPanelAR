function [ coef_GMM_DIF1, coef_GMM_DIF2, coef_GMM_SYS1, coef_GMM_SYS2, var_GMM_DIF1, var_GMM_DIF2, var_GMM_SYS1, var_GMM_SYS2, GMM_DIF_ML ] = GMMestimator_ar1(Y_NT, T, N )

option = optimset('TolCon',0.001,'TolFun',0.0001,'MaxFunEvals', 2000,'LargeScale', 'off','Display','off');

y  = Y_NT(2:T+1,:) ;
y1 = Y_NT(1:T,:) ;

% [T, N] = size(y);
T1=T-1;
T2=T-2;

m_DIF1 = T*(T-1)/2 ;
m_DIF2 = (T1*2 - 1) ;
m_SYS1 = m_DIF1 + (T-1);
m_SYS2 = m_DIF2 + (T-1);
m_ML = 3;
% disp([m_DIF m_SYS]);

D = [-eye(T1) zeros(T1,1)] + [zeros(T1,1) eye(T1) ];
DD = D*D';
L = [zeros(T1,1) eye(T1)];

Zy_DIF1 = zeros(m_DIF1,1);  ZX_DIF1 = zeros(m_DIF1,1);  ZZ_DIF1 = zeros(m_DIF1,m_DIF1);      
Zy_DIF2 = zeros(m_DIF2,1);  ZX_DIF2 = zeros(m_DIF2,1);  ZZ_DIF2 = zeros(m_DIF2,m_DIF2);     
Zy_SYS1 = zeros(m_SYS1,1);  ZX_SYS1 = zeros(m_SYS1,1);  ZZ_SYS1 = zeros(m_SYS1,m_SYS1);    
Zy_SYS2 = zeros(m_SYS2,1);  ZX_SYS2 = zeros(m_SYS2,1);  ZZ_SYS2 = zeros(m_SYS2,m_SYS2);  
Zy_ML = zeros(m_ML,1);  ZX_ML = zeros(m_ML,1);  ZZ_ML = zeros(m_ML,m_ML);  

Dy_N = zeros(T1,1,N);    DX_N = zeros(T1,1,N);
Sy_N = zeros(2*T1,1,N);  SX_N = zeros(2*T1,1,N);
Z_DIF1_N  = zeros(T1,m_DIF1,N);       Z_DIF2_N  = zeros(T1,m_DIF2,N);
Z_SYS1_N  = zeros(2*T1,m_SYS1,N);     Z_SYS2_N  = zeros(2*T1,m_SYS2,N); 
Dy = D*y;   Dy1 = D*y1;  
Ly = L*y;   Ly1 = L*y1;  
for i=1:N;
    Dyi = Dy(:,i);   DXi = [Dy1(:,i) ];
    Lyi = Ly(:,i);   LXi = [Ly1(:,i) ];
    Syi = [Dyi; Lyi];   SXi =  [DXi; LXi];
    Dy_N(:,:,i) = Dyi;  DX_N(:,:,i) = DXi;
    Sy_N(:,:,i) = Syi;  SX_N(:,:,i) = SXi;

    Zi_DIF10 = 0;
    Zi_DIF20 = 0;
    Zi_LEV0 = 0;
   
    for t=1:T1
        if t==1; lag=1; end
        if t>=2; lag=2; end
        Zi_DIF10 = blkdiag(Zi_DIF10, [y1(1:t,i)' ]); 
        Zi_DIF20 = blkdiag(Zi_DIF20, [y1(t-lag+1:t,i)' ] ); 
        Zi_LEV0  = blkdiag(Zi_LEV0, [Dy1(t,i)' ]); 
    end

    
    Zi_DIF1 = Zi_DIF10(2:end,2:end) ;
    Zi_DIF2 = Zi_DIF20(2:end,2:end) ;
    Zi_LEV  = Zi_LEV0(2:end,2:end);
    Zi_SYS1 = blkdiag(Zi_DIF1, Zi_LEV);
    Zi_SYS2 = blkdiag(Zi_DIF2, Zi_LEV);
    Z_DIF1_N(:,:,i) = Zi_DIF1;
    Z_DIF2_N(:,:,i) = Zi_DIF2;
    Z_SYS1_N(:,:,i) = Zi_SYS1;
    Z_SYS2_N(:,:,i) = Zi_SYS2;
    
    Zi_ML = [y1(1:T1,i)  [0 ; y1(1:T-2,i) ] [0; 0; y1(1:T-3,i) ] ];
    
    Zy_DIF1 = Zy_DIF1 + Zi_DIF1'*Dyi;    ZX_DIF1 = ZX_DIF1 + Zi_DIF1'*DXi;    ZZ_DIF1 = ZZ_DIF1 + Zi_DIF1'*DD*Zi_DIF1;       
    Zy_DIF2 = Zy_DIF2 + Zi_DIF2'*Dyi;    ZX_DIF2 = ZX_DIF2 + Zi_DIF2'*DXi;    ZZ_DIF2 = ZZ_DIF2 + Zi_DIF2'*DD*Zi_DIF2;       
    Zy_SYS1 = Zy_SYS1 + Zi_SYS1'*Syi;    ZX_SYS1 = ZX_SYS1 + Zi_SYS1'*SXi;    ZZ_SYS1 = ZZ_SYS1 + blkdiag(Zi_DIF1'*DD*Zi_DIF1, Zi_LEV'*Zi_LEV);
    Zy_SYS2 = Zy_SYS2 + Zi_SYS2'*Syi;    ZX_SYS2 = ZX_SYS2 + Zi_SYS2'*SXi;    ZZ_SYS2 = ZZ_SYS2 + blkdiag(Zi_DIF2'*DD*Zi_DIF2, Zi_LEV'*Zi_LEV);
    Zy_ML = Zy_ML + Zi_ML'*Dyi;    ZX_ML = ZX_ML + Zi_ML'*DXi;    ZZ_ML = ZZ_ML + Zi_ML'*DD*Zi_ML;

end;
ZX_DIF1 = ZX_DIF1/N;    ZX_DIF2 = ZX_DIF2/N;    ZX_SYS1 = ZX_SYS1/N;    ZX_SYS2 = ZX_SYS2/N;
Zy_DIF1 = Zy_DIF1/N;    Zy_DIF2 = Zy_DIF2/N;    Zy_SYS1 = Zy_SYS1/N;    Zy_SYS2 = Zy_SYS2/N;
ZZ_DIF1 = ZZ_DIF1/N;    ZZ_DIF2 = ZZ_DIF2/N;    ZZ_SYS1 = ZZ_SYS1/N;    ZZ_SYS2 = ZZ_SYS2/N;

% 1step GMM
if m_DIF1 < N; invZZ_DIF1 = inv(ZZ_DIF1); GMM_DIF1_1step = (ZX_DIF1'*invZZ_DIF1*ZX_DIF1)\(ZX_DIF1'*invZZ_DIF1*Zy_DIF1);
else GMM_DIF1_1step = NaN(1,1); 
end

if m_DIF2 < N; invZZ_DIF2 = inv(ZZ_DIF2); GMM_DIF2_1step = (ZX_DIF2'*invZZ_DIF2*ZX_DIF2)\(ZX_DIF2'*invZZ_DIF2*Zy_DIF2);
else GMM_DIF2_1step = NaN(1,1); 
end

if m_SYS1 < N; invZZ_SYS1 = inv(ZZ_SYS1); GMM_SYS1_1step = (ZX_SYS1'*invZZ_SYS1*ZX_SYS1)\(ZX_SYS1'*invZZ_SYS1*Zy_SYS1);
else GMM_SYS1_1step = NaN(1,1); 
end

if m_SYS2 < N; invZZ_SYS2 = inv(ZZ_SYS2); GMM_SYS2_1step = (ZX_SYS2'*invZZ_SYS2*ZX_SYS2)\(ZX_SYS2'*invZZ_SYS2*Zy_SYS2);
else GMM_SYS2_1step = NaN(1,1); 
end

% GMM using 3 IVs
invZZ_ML = inv(ZZ_ML);
GMM_DIF_ML = (ZX_ML'*invZZ_ML*ZX_ML)\(ZX_ML'*invZZ_ML*Zy_ML);
% GMM_DIF_ML=GMM_DIF2_1step;

% 2step GMM
Zu_DIF1_1step_N = zeros(N,m_DIF1);
Zu_DIF2_1step_N = zeros(N,m_DIF2);
Zu_SYS1_1step_N = zeros(N,m_SYS1);
Zu_SYS2_1step_N = zeros(N,m_SYS2);

for i=1:N
    Dyi = Dy_N(:,:,i) ;    DXi = DX_N(:,:,i) ;
    Syi = Sy_N(:,:,i) ;    SXi = SX_N(:,:,i) ;
    Zi_DIF1 = Z_DIF1_N(:,:,i);
    Zi_DIF2 = Z_DIF2_N(:,:,i);
    Zi_SYS1 = Z_SYS1_N(:,:,i);
    Zi_SYS2 = Z_SYS2_N(:,:,i);
    
    ui_DIF1_1step = Dyi - DXi*GMM_DIF1_1step;
    ui_DIF2_1step = Dyi - DXi*GMM_DIF2_1step;
    ui_SYS1_1step = Syi - SXi*GMM_SYS1_1step;
    ui_SYS2_1step = Syi - SXi*GMM_SYS2_1step;
    
    Zu_DIF1_1step_N(i,:) = (Zi_DIF1'*ui_DIF1_1step)';
    Zu_DIF2_1step_N(i,:) = (Zi_DIF2'*ui_DIF2_1step)';
    Zu_SYS1_1step_N(i,:) = (Zi_SYS1'*ui_SYS1_1step)';
    Zu_SYS2_1step_N(i,:) = (Zi_SYS2'*ui_SYS2_1step)';

end
Zu_DIF1_1step = mean(Zu_DIF1_1step_N)';   
Zu_DIF2_1step = mean(Zu_DIF2_1step_N)';   
Zu_SYS1_1step = mean(Zu_SYS1_1step_N)';   
Zu_SYS2_1step = mean(Zu_SYS2_1step_N)';   
Ome_DIF1_1step = Zu_DIF1_1step_N'*Zu_DIF1_1step_N/N - Zu_DIF1_1step*Zu_DIF1_1step';
Ome_DIF2_1step = Zu_DIF2_1step_N'*Zu_DIF2_1step_N/N - Zu_DIF2_1step*Zu_DIF2_1step';
Ome_SYS1_1step = Zu_SYS1_1step_N'*Zu_SYS1_1step_N/N - Zu_SYS1_1step*Zu_SYS1_1step';
Ome_SYS2_1step = Zu_SYS2_1step_N'*Zu_SYS2_1step_N/N - Zu_SYS2_1step*Zu_SYS2_1step';


if m_DIF1 < N; invOme_DIF1_1step = inv(Ome_DIF1_1step); 
GMM_DIF1_2step = (ZX_DIF1'*invOme_DIF1_1step*ZX_DIF1)\(ZX_DIF1'*invOme_DIF1_1step*Zy_DIF1);
else GMM_DIF1_2step =NaN(1,1); end


if m_DIF2 < N; invOme_DIF2_1step = inv(Ome_DIF2_1step); 
GMM_DIF2_2step = (ZX_DIF2'*invOme_DIF2_1step*ZX_DIF2)\(ZX_DIF2'*invOme_DIF2_1step*Zy_DIF2);
else GMM_DIF2_2step =NaN(1,1); 
end

if m_SYS1 < N; invOme_SYS1_1step = inv(Ome_SYS1_1step); 
GMM_SYS1_2step = (ZX_SYS1'*invOme_SYS1_1step*ZX_SYS1)\(ZX_SYS1'*invOme_SYS1_1step*Zy_SYS1);
else GMM_SYS1_2step =NaN(1,1); 
end

if m_SYS2 < N; invOme_SYS2_1step = inv(Ome_SYS2_1step); GMM_SYS2_2step = (ZX_SYS2'*invOme_SYS2_1step*ZX_SYS2)\(ZX_SYS2'*invOme_SYS2_1step*Zy_SYS2);
else GMM_SYS2_2step =NaN(1,1); 
end




if m_DIF1 < N;  [GMM_DIF1_CUE,fval,exitflag,output,grad,Hhat_DIF1]   = fminunc( @(beta)Obj_CUE( beta, Dy_N, DX_N, Z_DIF1_N ), GMM_DIF1_1step, option); else GMM_DIF1_CUE = NaN(1,1); end
if m_DIF2 < N;  [GMM_DIF2_CUE,fval,exitflag,output,grad,Hhat_DIF2]   = fminunc( @(beta)Obj_CUE( beta, Dy_N, DX_N, Z_DIF2_N ), GMM_DIF2_1step, option); else GMM_DIF2_CUE = NaN(1,1); end
if m_SYS1 < N;  [GMM_SYS1_CUE,fval,exitflag,output,grad,Hhat_SYS1]   = fminunc( @(beta)Obj_CUE( beta, Sy_N, SX_N, Z_SYS1_N ), GMM_SYS1_1step, option); else GMM_SYS1_CUE = NaN(1,1); end
if m_SYS2 < N;  [GMM_SYS2_CUE,fval,exitflag,output,grad,Hhat_SYS2]   = fminunc( @(beta)Obj_CUE( beta, Sy_N, SX_N, Z_SYS2_N ), GMM_SYS2_1step, option); else GMM_SYS2_CUE = NaN(1,1); end

% GMM_DIF_CUE   = GMM_DIF_2step;
% GMM_SYS_CUE   = GMM_SYS_2step;


coef_GMM_DIF1 = [GMM_DIF1_1step   GMM_DIF1_2step   GMM_DIF1_CUE];
coef_GMM_DIF2 = [GMM_DIF2_1step   GMM_DIF2_2step   GMM_DIF2_CUE];
coef_GMM_SYS1 = [GMM_SYS1_1step   GMM_SYS1_2step   GMM_SYS1_CUE];
coef_GMM_SYS2 = [GMM_SYS2_1step   GMM_SYS2_2step   GMM_SYS2_CUE];

% compute standard errors
Zu_DIF1_2step_N = zeros(N,m_DIF1);    Zu_DIF2_2step_N = zeros(N,m_DIF2);
Zu_SYS1_2step_N = zeros(N,m_SYS1);    Zu_SYS2_2step_N = zeros(N,m_SYS2);
Zu_DIF1_CUE_N = zeros(N,m_DIF1);      Zu_DIF2_CUE_N = zeros(N,m_DIF2);
Zu_SYS1_CUE_N = zeros(N,m_SYS1);      Zu_SYS2_CUE_N = zeros(N,m_SYS2);
dW_DIF1 = zeros(m_DIF1,m_DIF1,1);     dW_DIF2 = zeros(m_DIF2,m_DIF2,1);
dW_SYS1 = zeros(m_SYS1,m_SYS1,1);     dW_SYS2 = zeros(m_SYS2,m_SYS2,1);

ZXuZ_DIF1 = zeros(m_DIF1, m_DIF1,1);    ZXuZ_DIF2 = zeros(m_DIF2, m_DIF2,1);
ZXuZ_SYS1 = zeros(m_SYS1, m_SYS1,1);    ZXuZ_SYS2 = zeros(m_SYS2, m_SYS2,1);    


for i=1:N
    Dyi = Dy_N(:,:,i) ;    DXi = DX_N(:,:,i) ;
    Syi = Sy_N(:,:,i) ;    SXi = SX_N(:,:,i) ;
    ui_DIF1_1step = Dyi - DXi*GMM_DIF1_1step;
    ui_DIF2_1step = Dyi - DXi*GMM_DIF2_1step;
    ui_SYS1_1step = Syi - SXi*GMM_SYS1_1step;
    ui_SYS2_1step = Syi - SXi*GMM_SYS2_1step;

    ui_DIF1_2step = Dyi - DXi*GMM_DIF1_2step;
    ui_DIF2_2step = Dyi - DXi*GMM_DIF2_2step;
    ui_SYS1_2step = Syi - SXi*GMM_SYS1_2step;
    ui_SYS2_2step = Syi - SXi*GMM_SYS2_2step;

    ui_DIF1_CUE = Dyi - DXi*GMM_DIF1_CUE;
    ui_DIF2_CUE = Dyi - DXi*GMM_DIF2_CUE;
    ui_SYS1_CUE = Syi - SXi*GMM_SYS1_CUE;
    ui_SYS2_CUE = Syi - SXi*GMM_SYS2_CUE;
    Zi_DIF1 = Z_DIF1_N(:,:,i);    
    Zi_DIF2 = Z_DIF2_N(:,:,i);    
    Zi_SYS1 = Z_SYS1_N(:,:,i);    
    Zi_SYS2 = Z_SYS2_N(:,:,i);    
    Zu_DIF1_2step_N(i,:) = (Zi_DIF1'*ui_DIF1_2step)';
    Zu_DIF2_2step_N(i,:) = (Zi_DIF2'*ui_DIF2_2step)';
    Zu_SYS1_2step_N(i,:) = (Zi_SYS1'*ui_SYS1_2step)';
    Zu_SYS2_2step_N(i,:) = (Zi_SYS2'*ui_SYS2_2step)';

    Zu_DIF1_CUE_N(i,:) = (Zi_DIF1'*ui_DIF1_CUE)';
    Zu_DIF2_CUE_N(i,:) = (Zi_DIF2'*ui_DIF2_CUE)';
    Zu_SYS1_CUE_N(i,:) = (Zi_SYS1'*ui_SYS1_CUE)';
    Zu_SYS2_CUE_N(i,:) = (Zi_SYS2'*ui_SYS2_CUE)';

    dW_DIF1(:,:,1) = dW_DIF1(:,:,1) + Zi_DIF1'*(DXi(:,1)*ui_DIF1_1step' + ui_DIF1_1step*DXi(:,1)')*Zi_DIF1;
    dW_DIF2(:,:,1) = dW_DIF2(:,:,1) + Zi_DIF2'*(DXi(:,1)*ui_DIF2_1step' + ui_DIF2_1step*DXi(:,1)')*Zi_DIF2;

    dW_SYS1(:,:,1) = dW_SYS1(:,:,1) + Zi_SYS1'*(SXi(:,1)*ui_SYS1_1step' + ui_SYS1_1step*SXi(:,1)')*Zi_SYS1;
    dW_SYS2(:,:,1) = dW_SYS2(:,:,1) + Zi_SYS2'*(SXi(:,1)*ui_SYS2_1step' + ui_SYS2_1step*SXi(:,1)')*Zi_SYS2;

   ZXuZ_DIF1(:,:,1) = ZXuZ_DIF1(:,:,1) + Zi_DIF1'*DXi(:,1)*ui_DIF1_CUE'*Zi_DIF1;
   ZXuZ_DIF2(:,:,1) = ZXuZ_DIF2(:,:,1) + Zi_DIF2'*DXi(:,1)*ui_DIF2_CUE'*Zi_DIF2 ;
   ZXuZ_SYS1(:,:,1) = ZXuZ_SYS1(:,:,1) + Zi_SYS1'*SXi(:,1)*ui_SYS1_CUE'*Zi_SYS1 ;
   ZXuZ_SYS2(:,:,1) = ZXuZ_SYS2(:,:,1) + Zi_SYS2'*SXi(:,1)*ui_SYS2_CUE'*Zi_SYS2 ;


end
Zu_DIF1_2step = mean(Zu_DIF1_CUE_N)';   
Zu_DIF2_2step = mean(Zu_DIF2_CUE_N)';   
Zu_SYS1_2step = mean(Zu_SYS1_CUE_N)';   
Zu_SYS2_2step = mean(Zu_SYS2_CUE_N)';   

Zu_DIF1_CUE = mean(Zu_DIF1_CUE_N)';   
Zu_DIF2_CUE = mean(Zu_DIF2_CUE_N)';   
Zu_SYS1_CUE = mean(Zu_SYS1_CUE_N)';   
Zu_SYS2_CUE = mean(Zu_SYS2_CUE_N)';   
Ome_DIF1_CUE = Zu_DIF1_CUE_N'*Zu_DIF1_CUE_N/N - Zu_DIF1_CUE*Zu_DIF1_CUE';
Ome_DIF2_CUE = Zu_DIF2_CUE_N'*Zu_DIF2_CUE_N/N - Zu_DIF2_CUE*Zu_DIF2_CUE';
Ome_SYS1_CUE = Zu_SYS1_CUE_N'*Zu_SYS1_CUE_N/N - Zu_SYS1_CUE*Zu_SYS1_CUE';
Ome_SYS2_CUE = Zu_SYS2_CUE_N'*Zu_SYS2_CUE_N/N - Zu_SYS2_CUE*Zu_SYS2_CUE';

dW_DIF1 = -dW_DIF1/N;
dW_DIF2 = -dW_DIF2/N;
dW_SYS1 = -dW_SYS1/N;
dW_SYS2 = -dW_SYS2/N;

ZXuZ_DIF1 = ZXuZ_DIF1/N;    ZXuZ_DIF2 = ZXuZ_DIF2/N;
ZXuZ_SYS1 = ZXuZ_SYS1/N;    ZXuZ_SYS2 = ZXuZ_SYS2/N;

K=0;
if m_DIF1 < N; 
invOme_DIF1_CUE = inv(Ome_DIF1_CUE);
D_DIF1_2step = zeros(K+1,1);
D_DIF1_CUE = zeros(m_DIF1,1);
for j=1:K+1
    D_DIF1_2step = [D_DIF1_2step, -(inv(ZX_DIF1'*invOme_DIF1_1step*ZX_DIF1)*(ZX_DIF1'*invOme_DIF1_1step*dW_DIF1(:,:,j)*invOme_DIF1_1step*Zu_DIF1_2step))];
    D_DIF1_CUE   = [D_DIF1_CUE, -ZX_DIF1(:,j) + ZXuZ_DIF1(:,:,j)*invOme_DIF1_CUE*Zu_DIF1_CUE];
end
D_DIF1_2step = D_DIF1_2step(:,2:end);
D_DIF1_CUE   = D_DIF1_CUE(:,2:end);
var_DIF1_1step = (1/N)*inv(ZX_DIF1'*invZZ_DIF1*ZX_DIF1)*(ZX_DIF1'*invZZ_DIF1*Ome_DIF1_1step*invZZ_DIF1*ZX_DIF1)*inv(ZX_DIF1'*invZZ_DIF1*ZX_DIF1);
var_DIF1_2step = (1/N)*inv(ZX_DIF1'*invOme_DIF1_1step*ZX_DIF1) ;
var_DIF1_2step_W = var_DIF1_2step + D_DIF1_2step*var_DIF1_2step + var_DIF1_2step*D_DIF1_2step' + D_DIF1_2step*var_DIF1_1step*D_DIF1_2step';
var_DIF1_CUE = (1/N)*inv(ZX_DIF1'*invOme_DIF1_CUE*ZX_DIF1) ;
var_DIF1_CUE_NW = (1/N)*inv(Hhat_DIF1/(2*N))*(D_DIF1_CUE'*invOme_DIF1_CUE*D_DIF1_CUE)*inv(Hhat_DIF1/(2*N));

else
    var_DIF1_1step   = NaN(K+1,K+1);     var_DIF1_2step   = NaN(K+1,K+1);     var_DIF1_2step_W = NaN(K+1,K+1); 
    var_DIF1_CUE     = NaN(K+1,K+1);     var_DIF1_CUE_NW  = NaN(K+1,K+1); 
end

if m_DIF2 < N; 
invOme_DIF2_CUE = inv(Ome_DIF2_CUE);
D_DIF2_2step = zeros(K+1,1);
D_DIF2_CUE = zeros(m_DIF2,1);
for j=1:K+1
    D_DIF2_2step = [D_DIF2_2step, -(inv(ZX_DIF2'*invOme_DIF2_1step*ZX_DIF2)*(ZX_DIF2'*invOme_DIF2_1step*dW_DIF2(:,:,j)*invOme_DIF2_1step*Zu_DIF2_2step))];
    D_DIF2_CUE   = [D_DIF2_CUE, -ZX_DIF2(:,j) + ZXuZ_DIF2(:,:,j)*invOme_DIF2_CUE*Zu_DIF2_CUE];
end
D_DIF2_2step = D_DIF2_2step(:,2:end);
D_DIF2_CUE   = D_DIF2_CUE(:,2:end);
var_DIF2_1step = (1/N)*inv(ZX_DIF2'*invZZ_DIF2*ZX_DIF2)*(ZX_DIF2'*invZZ_DIF2*Ome_DIF2_1step*invZZ_DIF2*ZX_DIF2)*inv(ZX_DIF2'*invZZ_DIF2*ZX_DIF2);
var_DIF2_2step = (1/N)*inv(ZX_DIF2'*invOme_DIF2_1step*ZX_DIF2) ;
var_DIF2_2step_W = var_DIF2_2step + D_DIF2_2step*var_DIF2_2step + var_DIF2_2step*D_DIF2_2step' + D_DIF2_2step*var_DIF2_1step*D_DIF2_2step';
var_DIF2_CUE = (1/N)*inv(ZX_DIF2'*invOme_DIF2_CUE*ZX_DIF2) ;
var_DIF2_CUE_NW = (1/N)*inv(Hhat_DIF2/(2*N))*(D_DIF2_CUE'*invOme_DIF2_CUE*D_DIF2_CUE)*inv(Hhat_DIF2/(2*N));
else
    var_DIF2_1step   = NaN(K+1,K+1);     var_DIF2_2step   = NaN(K+1,K+1);     var_DIF2_2step_W = NaN(K+1,K+1); 
    var_DIF2_CUE     = NaN(K+1,K+1);     var_DIF2_CUE_NW  = NaN(K+1,K+1); 
end

if m_SYS1 < N; 
invOme_SYS1_CUE = inv(Ome_SYS1_CUE);
D_SYS1_2step = zeros(K+1,1);
D_SYS1_CUE = zeros(m_SYS1,1);
for j=1:K+1
    D_SYS1_2step = [D_SYS1_2step, -(inv(ZX_SYS1'*invOme_SYS1_1step*ZX_SYS1)*(ZX_SYS1'*invOme_SYS1_1step*dW_SYS1(:,:,j)*invOme_SYS1_1step*Zu_SYS1_2step))];
    D_SYS1_CUE   = [D_SYS1_CUE, -ZX_SYS1(:,j) + ZXuZ_SYS1(:,:,j)*invOme_SYS1_CUE*Zu_SYS1_CUE];
end
D_SYS1_2step = D_SYS1_2step(:,2:end);
D_SYS1_CUE   = D_SYS1_CUE(:,2:end);
var_SYS1_1step = (1/N)*inv(ZX_SYS1'*invZZ_SYS1*ZX_SYS1)*(ZX_SYS1'*invZZ_SYS1*Ome_SYS1_1step*invZZ_SYS1*ZX_SYS1)*inv(ZX_SYS1'*invZZ_SYS1*ZX_SYS1);
var_SYS1_2step = (1/N)*inv(ZX_SYS1'*invOme_SYS1_1step*ZX_SYS1) ;
var_SYS1_2step_W = var_SYS1_2step + D_SYS1_2step*var_SYS1_2step + var_SYS1_2step*D_SYS1_2step' + D_SYS1_2step*var_SYS1_1step*D_SYS1_2step';
var_SYS1_CUE = (1/N)*inv(ZX_SYS1'*invOme_SYS1_CUE*ZX_SYS1) ;
var_SYS1_CUE_NW = (1/N)*inv(Hhat_SYS1/(2*N))*(D_SYS1_CUE'*invOme_SYS1_CUE*D_SYS1_CUE)*inv(Hhat_SYS1/(2*N));

else
    var_SYS1_1step   = NaN(K+1,K+1);     var_SYS1_2step   = NaN(K+1,K+1);     var_SYS1_2step_W = NaN(K+1,K+1); 
    var_SYS1_CUE     = NaN(K+1,K+1);     var_SYS1_CUE_NW  = NaN(K+1,K+1); 
end

if m_SYS2 < N; 
invOme_SYS2_CUE = inv(Ome_SYS2_CUE);
D_SYS2_2step = zeros(K+1,1);
D_SYS2_CUE = zeros(m_SYS2,1);
for j=1:K+1
    D_SYS2_2step = [D_SYS2_2step, -(inv(ZX_SYS2'*invOme_SYS2_1step*ZX_SYS2)*(ZX_SYS2'*invOme_SYS2_1step*dW_SYS2(:,:,j)*invOme_SYS2_1step*Zu_SYS2_2step))];
    D_SYS2_CUE   = [D_SYS2_CUE, -ZX_SYS2(:,j) + ZXuZ_SYS2(:,:,j)*invOme_SYS2_CUE*Zu_SYS2_CUE];
end
D_SYS2_2step = D_SYS2_2step(:,2:end);
D_SYS2_CUE   = D_SYS2_CUE(:,2:end);
var_SYS2_1step = (1/N)*inv(ZX_SYS2'*invZZ_SYS2*ZX_SYS2)*(ZX_SYS2'*invZZ_SYS2*Ome_SYS2_1step*invZZ_SYS2*ZX_SYS2)*inv(ZX_SYS2'*invZZ_SYS2*ZX_SYS2);
var_SYS2_2step = (1/N)*inv(ZX_SYS2'*invOme_SYS2_1step*ZX_SYS2) ;
var_SYS2_2step_W = var_SYS2_2step + D_SYS2_2step*var_SYS2_2step + var_SYS2_2step*D_SYS2_2step' + D_SYS2_2step*var_SYS2_1step*D_SYS2_2step';
var_SYS2_CUE = (1/N)*inv(ZX_SYS2'*invOme_SYS2_CUE*ZX_SYS2) ;
var_SYS2_CUE_NW = (1/N)*inv(Hhat_SYS2/(2*N))*(D_SYS2_CUE'*invOme_SYS2_CUE*D_SYS2_CUE)*inv(Hhat_SYS2/(2*N));
else
    var_SYS2_1step   = NaN(K+1,K+1);     var_SYS2_2step   = NaN(K+1,K+1);     var_SYS2_2step_W = NaN(K+1,K+1); 
    var_SYS2_CUE     = NaN(K+1,K+1);     var_SYS2_CUE_NW  = NaN(K+1,K+1); 
end

var_GMM_DIF1 = cat(3, var_DIF1_1step, var_DIF1_2step,  var_DIF1_2step_W, var_DIF1_CUE,  var_DIF1_CUE_NW  );
var_GMM_DIF2 = cat(3, var_DIF2_1step, var_DIF2_2step,  var_DIF2_2step_W, var_DIF2_CUE,  var_DIF2_CUE_NW  );
var_GMM_SYS1 = cat(3, var_SYS1_1step, var_SYS1_2step,  var_SYS1_2step_W, var_SYS1_CUE,  var_SYS1_CUE_NW);
var_GMM_SYS2 = cat(3, var_SYS2_1step, var_SYS2_2step,  var_SYS2_2step_W, var_SYS2_CUE,  var_SYS2_CUE_NW);




end

