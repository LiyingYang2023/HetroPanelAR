function [H,pv ]=Hausman_test(a, va, b, vb)
% under null b is more efficient than a
%% Hausman test

ab=a-b;
if va>vb
H=ab'*pinv(va-vb)*ab;
%cv=chi2inv(0.95,1);
pv=1-chi2cdf(H,1);
else
  H=NaN; pv  =NaN;
end

return % function

