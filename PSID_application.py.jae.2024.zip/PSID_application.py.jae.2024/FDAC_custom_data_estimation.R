rm(list=ls())

## Please install the following packages. 
# list.of.packages <- c("openxlsx")
# new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
# if(length(new.packages)) install.packages(new.packages)
library(openxlsx)

## Please load your custom balanced panel data set and transform it into an N by Tobs matrix named "paneldata". 
## N: the number of cross-sectional units
## Tobs: the number of time periods
# paneldata = matrix(NA,N,Tobs); Tobs = dim(paneldata)[2] ## Please modify this line according to the custom data set.

## Functions
##############################################################################
inv = function(m) class(try(solve(m),silent=T))[1]=="matrix"

Moment_mv = function(paneldata){
  T = dim(paneldata)[2]; N = dim(paneldata)[1]
  y = matrix(t(paneldata),nrow=T,ncol=N)
  Tm = min(dim(y))
  tm = min(dim(y)) -1
  n = max(dim(y))
  dy = y[2:Tm,] - y[1:(Tm-1),]  # first difference of panel data
  
  ######## MM: Individual Moments average over T : (T-h-1)*N matrix 
  lagdyy = 1*(tm>2)+1*(tm>3)+1*(tm>4)+1 # order of h for \Delta y_{it}\Delta y_{i,t-h}
  dyyi1 = matrix(, nrow = 5, ncol = n) # moments of \Delta y_{it}\Delta y_{i,t-h}, h=0,1,...,lagdyy
  dyyi2 = matrix(, nrow = 3, ncol = n) # T-3 h=0,1,2 
  dyyi3 = matrix(, nrow = 4, ncol = n) # T-4 h=0,1,2,3  
  dyyi4 = matrix(, nrow = 5, ncol = n) # T-5 h=0,1,2,3,4 
  
  for (ll in 0:lagdyy){
    dyyi1[(ll+1),] = matrix(t(dy[(1+ll):tm,]*dy[1:(tm-ll),]),nrow=n,ncol=(tm-ll)) %*% matrix(1,nrow = tm-ll,ncol=1) / (tm-ll)# average over t-h-1 
  }
  
  if (tm>=3) {
    dyyi2 = rbind(matrix(matrix(t(dy[3:tm,]^2),nrow=n,ncol=(tm-2)) %*% matrix(1,nrow=tm-2,ncol=1)/(tm-2),nrow=1,ncol=n),
                  matrix(matrix(t(dy[3:tm,]*dy[2:(tm-1),]),nrow=n,ncol=(tm-2)) %*% matrix(1,nrow=tm-2,ncol=1)/(tm-2),nrow=1,ncol=n),
                  matrix(matrix(t(dy[3:tm,]*dy[1:(tm-2),]),nrow=n,ncol=(tm-2)) %*% matrix(1,nrow=tm-2,ncol=1)/(tm-2),nrow=1,ncol=n)) # MM b
    hi1 = matrix(dy[3:tm,]^(2) + dy[3:tm,]*dy[2:(tm-1),],nrow=(tm-2),ncol=n) # GMM (T-3)*n vector
    gi1 = matrix(dy[3:tm,]^(2) + 2*dy[3:tm,]*dy[2:(tm-1),] + dy[3:tm,]*dy[1:(tm-2),],nrow=(tm-2),ncol=n) 
    
    ####### MM Average across i
    dyy1 = dyyi1 %*% matrix(1,nrow=n,ncol=1)/n # h=0,1,2,...,lagdyy
    dyy2 = dyyi2 %*% matrix(1,nrow=n,ncol=1)/n # h=0,1,2
    ####### MM Version a: dyy1 with different T-h-1
    mm1 = (dyy1[1]+2*dyy1[2]+dyy1[3])/(dyy1[1]+dyy1[2]) # Equation (15) 
    mms1 = sum((dyyi1[1,]+2*dyyi1[2,]+dyyi1[3,]-mm1*(dyyi1[1,]+dyyi1[2,]))^2)/n # average across i
    std_mm1 = sqrt((dyy1[1]+dyy1[2])^(-2)*mms1/n) # ((mean(dyyi1[1,]+dyyi1[2,]))^(2)*(mms1^(-1)))^(-1)/n   
    
    ####### GMM 
    hnt1 = hi1 %*% matrix(1,nrow=n,ncol=1) / n  # (T-3)*1 average over n rowMeans(hi1)
    gnt1 = gi1 %*% matrix(1,nrow=n,ncol=1) / n  # average over n rowMeans(gi1) 
    gmms1 = (gi1-mm1*hi1) %*% t(gi1-mm1*hi1) /n  # the optimal weight (T-3)*(T-3) matrix for the mean Equation (20)
    if (inv(gmms1) == 1) {
      gmms1 = gmms1
    } else {
      gmms1 = diag(tm-2)/n
    }
    gmm1 =  solve(t(hnt1) %*% solve(gmms1) %*% hnt1) * (t(hnt1) %*% solve(gmms1) %*% gnt1) # 1st moment: Equation (22)
    std_gmm1 = sqrt(solve(t(hnt1) %*% solve(gmms1) %*% hnt1) /n) #Asymptotic variance
  }
  
  if (tm>=4) {
    svmi = matrix(, nrow = 2^2 , ncol=n) # sample variance of moment conditions
    svgi = matrix(, nrow = (tm-2+tm-3)^2 , ncol=n) # sample variance of joint moment conditions: 1st, 2nd
    
    dyyi3 = rbind(matrix(matrix(t(dy[4:tm,]^2),nrow=n,ncol=(tm-3)) %*% matrix(1,nrow=tm-3,ncol=1)/(tm-3),nrow=1,ncol=n), 
                  matrix(matrix(t(dy[4:tm,]*dy[3:(tm-1),]),nrow=n,ncol=(tm-3)) %*% matrix(1,nrow=tm-3,ncol=1)/(tm-3),nrow=1,ncol=n),
                  matrix(matrix(t(dy[4:tm,]*dy[2:(tm-2),]),nrow=n,ncol=(tm-3)) %*% matrix(1,nrow=tm-3,ncol=1)/(tm-3),nrow=1,ncol=n),
                  matrix(matrix(t(dy[4:tm,]*dy[1:(tm-3),]),nrow=n,ncol=(tm-3)) %*% matrix(1,nrow=tm-3,ncol=1)/(tm-3),nrow=1,ncol=n))
    hi2 = matrix(dy[4:tm,]^(2) + dy[4:tm,]*dy[3:(tm-1),],nrow=(tm-3),ncol=n) #  (T-4)*n vector
    gi2 = matrix(dy[4:tm,]^(2) + 2*dy[4:tm,]*dy[3:(tm-1),] + 2*dy[4:tm,]*dy[2:(tm-2),] + dy[4:tm,]*dy[1:(tm-3),],nrow=(tm-3),ncol=n) 
    
    dyy3 = dyyi3 %*% matrix(1,nrow=n,ncol=1)/ n # h=0,1,2,3
    ### MM: 2nd
    mm2 = (dyy1[1]+2*dyy1[2]+2*dyy1[3]+dyy1[4])/(dyy1[1]+dyy1[2]) # Equation (16) 
    mms2 = mean((dyyi1[1,]+2*dyyi1[2,]+2*dyyi1[3,]+dyyi1[4,]-mm2*(dyyi1[1,]+dyyi1[2,]))^2)
    std_mm2 = sqrt((dyy1[1]+dyy1[2])^(-2)*mms2 /n)  #1-(rho[1]+2*mm1*rho[1]+mm2*rho[1])/(1-rho[1]) - mm2 
    mmv = mm2-mm1^2 # plug-in estimator of variance
    
    mc = rbind(mm1 * (dyyi1[1,]+dyyi1[2,]) - (dyyi1[1,]+2*dyyi1[2,]+dyyi1[3,]), mm2*(dyyi1[1,]+dyyi1[2,]) - (dyyi1[1,]+2*dyyi1[2,]+2*dyyi1[3,]+dyyi1[4,])) # n*2 matrix
    index = 1
    for (i in 1:2){
      for (j in 1:2) {
        svmi[index,] = mc[i,] * mc[j,]
        index = index +1
      }
    }
    rm(mc)
    jmms2 = matrix(c(rowMeans(svmi)),nrow = 2 ,ncol = 2) # with the mmb plugged in  
    dmm2 = matrix(c(-2*mm1,1),nrow = 2,ncol = 1)
    jhm2 = matrix(c((dyy1[1]+dyy1[2]),0,0,(dyy1[1]+dyy1[2])),nrow=2,ncol=2)
    
    if (inv(jhm2) == 1) {
      jhm2 = jhm2} else {
        jhm2 = diag(2)
      }
    std_mmv = sqrt(t(dmm2) %*% solve(jhm2) %*% (jmms2) %*% solve(jhm2) %*% dmm2 /n  )
    
    ### GMM : 2nd
    hnt2 = rowMeans(hi2)
    gnt2 = rowMeans(gi2)
    gmms2 = (gi2-mm2*hi2) %*% t(gi2-mm2*hi2) /n  # the optimal weight (T-4)*(T-4) matrix for the mean Equation (31)
    if (inv(gmms2) == 1) {
      gmms2 = gmms2} else {
        gmms2 = diag(tm-3)
      }
    gmm2 =  solve(t(hnt2) %*% solve(gmms2) %*% hnt2) * (t(hnt2) %*% solve(gmms2) %*% gnt2) # 2nd moment: Equation (29)
    gmmv = gmm2 - gmm1^2
    zeroh1 = matrix(rep(0,length(hi1[,i])), nrow=length(hi1[,i]),ncol=1)
    zeroh2 = matrix(rep(0,length(hi2[,i])), nrow=length(hi2[,i]),ncol=1)
    zerom1 = matrix(rep(0, (tm-2)*(tm-3)),nrow=tm-2,ncol=tm-3)
    zerom2 = matrix(rep(0, (tm-2)*(tm-3)),nrow=tm-3,ncol=tm-2)
    
    mc = rbind(kronecker(gmm1,hi1)-gi1, kronecker(gmm2,hi2)-gi2) # (T-3+T-4)*2 matrix
    index = 1
    for (i in 1:(2*tm-5)){
      for (j in 1:(2*tm-5)) {
        svgi[index,] = mc[i,] * mc[j,]
        index = index +1
      }
    }
    rm(mc)
    jgmms2 = matrix(c(rowMeans(svgi)),nrow = 2*tm-5 ,ncol = 2*tm-5) # covariance matrix of joint moments
    jhg2 =  rbind(cbind(hnt1,zeroh1),cbind(zeroh2,hnt2)) # （2*tm-5) times 2 matrix
    
    gmma2 = rbind(cbind(solve(gmms1),zerom1),cbind(zerom2,solve(gmms2))) # weight matrix
    gmmcv2 = solve(t(jhg2) %*% gmma2 %*% jhg2) %*% t(jhg2) %*% gmma2 %*% jgmms2 %*% t(gmma2) %*% jhg2 %*% solve(t(jhg2) %*% t(gmma2) %*% jhg2)
    dgmm2 = matrix(c(-2*gmm1,1),nrow = 2,ncol = 1)
    
    std_gmm2 = sqrt((t(hnt2) %*% solve(gmms2) %*% hnt2)^(-1)/n)
    std_gmmv =  sqrt(t(dgmm2) %*% gmmcv2  %*% dgmm2 /n)
    
  }
  
  if (tm>=5) {
    dyyi4 = rbind(matrix(matrix(t(dy[5:tm,]^2),nrow=n,ncol=(tm-4)) %*% matrix(1,nrow=tm-4,ncol=1)/(tm-4),nrow=1,ncol=n),
                  matrix(matrix(t(dy[5:tm,]*dy[4:(tm-1),]),nrow=n,ncol=(tm-4)) %*% matrix(1,nrow=tm-4,ncol=1)/(tm-4),nrow=1,ncol=n),
                  matrix(matrix(t(dy[5:tm,]*dy[3:(tm-2),]),nrow=n,ncol=(tm-4)) %*% matrix(1,nrow=tm-4,ncol=1)/(tm-4),nrow=1,ncol=n),
                  matrix(matrix(t(dy[5:tm,]*dy[2:(tm-3),]),nrow=n,ncol=(tm-4)) %*% matrix(1,nrow=tm-4,ncol=1)/(tm-4),nrow=1,ncol=n),
                  matrix(matrix(t(dy[5:tm,]*dy[1:(tm-4),]),nrow=n,ncol=(tm-4)) %*% matrix(1,nrow=tm-4,ncol=1)/(tm-4),nrow=1,ncol=n))
    hi3 = matrix(dy[5:tm,]^(2) + dy[5:tm,]*dy[4:(tm-1),],nrow=(tm-4),ncol=n) #  (T-5)*n vector
    gi3 = matrix(dy[5:tm,]^(2) + 2*dy[5:tm,]*dy[4:(tm-1),] + 2*dy[5:tm,]*dy[3:(tm-2),] + 2*dy[5:tm,]*dy[2:(tm-3),] + dy[5:tm,]*dy[1:(tm-4),],nrow=(tm-4),ncol=n) # 
    
    dyy4 = rowMeans(dyyi4) # h=0,1,2,3,4
    ### MM
    mm3 = (dyy1[1]+2*dyy1[2]+2*dyy1[3]+2*dyy1[4]+dyy1[5])/(dyy1[1]+dyy1[2]) # 
    mms3 = mean((dyyi1[1,]+2*dyyi1[2,]+2*dyyi1[3,]+2*dyyi1[4,]+dyyi1[5,]-mm3*(dyyi1[1,]+dyyi1[2,]))^2)
    std_mm3 = sqrt((dyy1[1]+dyy1[2])^(-2)*mms3 /n)  #1-(rho[1]+2*mm1*rho[1]+mm2*rho[1])/(1-rho[1]) - mm2 
    
    
    ### GMM: 3rd
    hnt3 = rowMeans(hi3)
    gnt3 = rowMeans(gi3)
    gmms3 = (gi3-mm3*hi3) %*% t(gi3-mm3*hi3) /n  # the optimal weight (T-5)*(T-5) matrix for the mean Equation (31)
    if (inv(gmms3) == 1) {
      gmms3 = gmms3} else {
        gmms3 = diag(tm-4)
      }
    gmm3 =  solve(t(hnt3) %*% solve(gmms3) %*% hnt3) * (t(hnt3) %*% solve(gmms3) %*% gnt3) # 2nd moment: Equation (29)
    std_gmm3 = sqrt((t(hnt3) %*% solve(gmms3) %*% hnt3)^(-1)/n)
  }
  
  if (tm==3){
    return(cbind(mm1,std_mm1,gmm1,std_gmm1))
  }
  if (tm==4) {
    return(cbind(mm1,std_mm1,gmm1,std_gmm1,
                 mm2,std_mm2,gmm2,std_gmm2,
                 mmv,std_mmv,gmmv,std_gmmv))
  }
  if (tm>4){
    return(cbind(mm1,std_mm1,gmm1,std_gmm1,
                 mm2,std_mm2,gmm2,std_gmm2,
                 mmv,std_mmv,gmmv,std_gmmv,
                 mm3,std_mm3,gmm3,std_gmm3))
  }
}

center_style <- createStyle(halign = "center")
right <- createStyle(halign = "right")
left <- createStyle(halign = "left")
bbs <- createStyle(border = "bottom",borderStyle="thin")
lbs <- createStyle(border = "bottom",borderStyle="double")
tbs <- createStyle(border = "top",borderStyle="double")
wrap_text_style <- createStyle(wrapText = TRUE)
##############################################################################

## Estimation
FDAC_results = Moment_mv(paneldata)

## Create a new workbook
wb <- createWorkbook()
sn = "FDAC estimation results"
addWorksheet(wb, sn)

writeData(wb, sn, x = "Table: FDAC estimation results of moments of heterogeneous autoregressive coefficients", startCol = 1, startRow = 1, colNames = FALSE)

tab = matrix(NA, 3, 5)

if (Tobs<4) {
  print("The FDAC estimator does not apply when the number of time periods is smaller than 4.")
} else if (Tobs==4) {
  tab[2:3,3] = FDAC_results[1:2]
  print("The FDAC estimation results are reported in an EXCEL file named FDAC_results.xlsx. The FDAC estimator for the variance of the heterogeneous autoregressive coefficients does not apply when the number of time periods is smaller than 5.")
} else if (Tobs>4) {
  print("The FDAC estimation results are reported in an EXCEL file named FDAC_results.xlsx.")
  tab[2:3,3] = FDAC_results[1:2]
  if (FDAC_results[9]>=0.0001) {
    tab[2:3,5] = FDAC_results[9:10]
  }
  if (FDAC_results[9]<0.0001) {
   print("The FDAC estimator for the variance of the heterogeneous autoregressive coefficients does not apply as the estimate is negative or close to zero.") 
  }
}

tab2 = tab
tab2[which(is.na(tab)==F)] = sprintf("%.3f", tab[which(is.na(tab)==F)] )
for (i in c(3)) { # Format of S.E.
  for (j in 1:ncol(tab2)) {
    if (is.na(tab2[i,j])==F) {
      tab2[i,j] = paste0("(",tab2[i,j],")",sep="")
    }
  }
}
tab2[,1] = c("","FDAC","")
tab2[1,] = c("","","Mean","","Variance")
h = tab2
rownames(h) <- NULL
colnames(h) <- NULL
writeData(wb,sn, x = h, startCol = 1, startRow = 2,colNames = FALSE, rowNames = FALSE)
writeData(wb,sn, x = "Notes: The number in brackets denotes estimated standard errors. ",
          startCol = 1, startRow = dim(h)[1]+2, colNames = FALSE)

mergeCells(wb, sheet = sn, cols = 1:ncol(h), rows = 1)

addStyle(wb,sn,style = center_style, rows = 2:3, cols = 2:(ncol(h)), gridExpand = TRUE)
addStyle(wb,sn,style = wrap_text_style, rows = 1,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
addStyle(wb,sn,style = bbs, rows = 2, cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
addStyle(wb,sn,style = tbs, rows = 2,cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)
addStyle(wb,sn,style = lbs, rows = (nrow(h)+1),cols = 1:(ncol(h)), gridExpand = TRUE,stack=TRUE)  

saveWorkbook(wb, file = "FDAC_results.xlsx",overwrite = TRUE)











